import { notifyExpiringListings } from "@/lib/expiry";
import { safeEqual } from "@/lib/http";
import { sendScheduledTelegram } from "@/lib/telegram";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const secret = new URL(request.url).searchParams.get("secret") || "";
  const expected = process.env.CRON_SECRET || "";
  if (!expected || !secret || !safeEqual(secret, expected)) {
    return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  }
  const expiry = await notifyExpiringListings();
  const result = await sendScheduledTelegram();
  if (!result.ok) return NextResponse.json({ error: result.error, expiry }, { status: 400 });
  return NextResponse.json({ ...result, expiry });
}
