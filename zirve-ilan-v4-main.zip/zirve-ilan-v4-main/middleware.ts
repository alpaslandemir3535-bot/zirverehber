import { adminFromToken } from "@/lib/admins";
import { ADMIN_COOKIE, OWNER_COOKIE } from "@/lib/session-token";
import { ownerFromToken } from "@/lib/users";
import { cities } from "@/lib/cities";
import { NextResponse, type NextRequest } from "next/server";
import {
  cityPagePath,
  ilanOrigin,
  isCityEscortPath,
  isLocalHost,
  isSearchBot,
  rehberOrigin,
  rehberUrl,
  resolveSite,
  vitrinListingsUrl,
} from "@/lib/site";
import { browserCity, knownCity, visitorCityName } from "@/lib/visitor-city";

export const runtime = "nodejs";

const TIKTOK_COOKIE = "zirve_tt";
// TikTok penceresi konum izni sormaz. Kayıtlı il yoksa IP'den il bulunur ve o sayfaya
// gidilir. Cihaz konumu sonradan gelirse sayfa onu esas alır.
const TIKTOK_UA = /TikTok|musical_ly|BytedanceWebview|ByteLocale/i;

function isTikTokBrowser(request: NextRequest) {
  return TIKTOK_UA.test(request.headers.get("user-agent") || "");
}

function isTikTokRequest(request: NextRequest) {
  if (request.cookies.get(TIKTOK_COOKIE)?.value === "1") return true;
  const referer = request.headers.get("referer") || "";
  try {
    const host = new URL(referer).hostname.toLowerCase();
    if (host === "tiktok.com" || host.endsWith(".tiktok.com")) return true;
  } catch {
    /* referer yok */
  }
  if (isTikTokBrowser(request)) return true;
  const params = request.nextUrl.searchParams;
  if (params.get("ttclid")) return true;
  return (params.get("utm_source") || "").toLowerCase().includes("tiktok");
}

function withCityCookie(response: NextResponse, cityName?: string | null) {
  if (!cityName) return response;
  response.cookies.set("zirve_konum", cityName, {
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
    sameSite: "lax",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
  });
  return response;
}

function withTikTokCookie(response: NextResponse) {
  response.cookies.set(TIKTOK_COOKIE, "1", {
    path: "/",
    maxAge: 60 * 60 * 24,
    sameSite: "lax",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
  });
  return response;
}

function quietRedirect(location: string | URL, request: NextRequest) {
  const target = typeof location === "string" && location.startsWith("/") ? new URL(location, request.url) : location;
  const response = NextResponse.redirect(target, 302);
  response.headers.set("Cache-Control", "private, no-store");
  response.headers.set("CDN-Cache-Control", "no-store");
  response.headers.set("Vary", "CF-Connecting-IP, X-Real-IP, Referer, Cookie");
  return response;
}

function noindexRewrite(url: URL) {
  const response = NextResponse.rewrite(url);
  response.headers.set("X-Robots-Tag", "noindex, follow");
  response.headers.set("Cache-Control", "private, no-store");
  return response;
}

function slugForCityName(cityName: string) {
  return cities.find((item) => item.name === cityName)?.slug || "";
}

function toCityPage(cityName: string, request: NextRequest) {
  const slug = slugForCityName(cityName);
  if (!slug) return null;
  return withCityCookie(quietRedirect(rehberUrl(cityPagePath(slug)), request), cityName);
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  if (pathname.startsWith("/_next") || pathname.startsWith("/api") || pathname === "/favicon.ico") {
    return NextResponse.next();
  }

  const requestHeaders = new Headers(request.headers);

  if (pathname.startsWith("/panel")) {
    const isLogin = pathname.startsWith("/panel/login");
    const admin = await adminFromToken(request.cookies.get(ADMIN_COOKIE)?.value);
    requestHeaders.set("x-zirve-gate", isLogin ? "login" : "panel");
    if (!isLogin && !admin) return quietRedirect(new URL("/panel/login/", request.url), request);
    if (isLogin && admin) return quietRedirect(new URL("/panel/", request.url), request);
    return NextResponse.next({ request: { headers: requestHeaders } });
  }

  if (pathname.startsWith("/hesap")) {
    const isLogin = pathname.startsWith("/hesap/login");
    const owner = await ownerFromToken(request.cookies.get(OWNER_COOKIE)?.value);
    requestHeaders.set("x-zirve-gate", isLogin ? "owner-login" : "owner");
    if (!isLogin && !owner) return quietRedirect(new URL("/hesap/login/", request.url), request);
    if (isLogin && owner) return quietRedirect(new URL("/hesap/", request.url), request);
    return NextResponse.next({ request: { headers: requestHeaders } });
  }

  if (pathname.startsWith("/sikayet") || pathname.startsWith("/rehber") || pathname.startsWith("/vitrin")) {
    return NextResponse.next();
  }

  const host = request.headers.get("host");
  const site = resolveSite(host);
  const local = isLocalHost(host);
  const bot = isSearchBot(request);
  const url = request.nextUrl.clone();
  const search = request.nextUrl.search;
  const tiktok = isTikTokRequest(request);

  // ?konum=İzmir → ilgili il sayfası. Bot/insan ayrımı yok; herkes aynı adrese gider.
  const konum = knownCity(request.nextUrl.searchParams.get("konum"));
  if (konum) {
    const target = toCityPage(konum, request);
    if (target) return tiktok ? withTikTokCookie(target) : target;
  }

  if (site === "rehber") {
    // İlan detayı her zaman ilan domainine gider.
    if (pathname.startsWith("/ilan")) {
      if (local) {
        url.pathname = `/vitrin${pathname}`;
        return noindexRewrite(url);
      }
      return quietRedirect(new URL(pathname + search, ilanOrigin()), request);
    }

    // Ana sayfa: kayıtlı il varsa o sayfaya düşer. Yoksa ziyaretçinin kendi IP'sinden
    // il bulunur. Konum açıksa sayfa, cihazın iline geçer. Yaş onayı sorulmaz.
    if (pathname === "/" || pathname === "") {
      if (!bot) {
        const city = browserCity(request.headers) || (await visitorCityName(request.headers));
        if (city) {
          const target = toCityPage(city, request);
          if (target) return tiktok ? withTikTokCookie(target) : target;
        }
      }
      url.pathname = "/rehber";
      const response = NextResponse.rewrite(url);
      return tiktok ? withTikTokCookie(response) : response;
    }

    // /izmir-escort/ ve diğer rehber yolları: bot ve insan aynı içeriği görür.
    if (local && pathname.startsWith("/ilanlar")) {
      url.pathname = "/vitrin/ilanlar";
      return noindexRewrite(url);
    }
    url.pathname = `/rehber${pathname}`;
    const response = NextResponse.rewrite(url);
    return tiktok ? withTikTokCookie(response) : response;
  }

  if (site === "ilan") {
    if (pathname.startsWith("/ilan/")) {
      url.pathname = `/vitrin${pathname}`;
      return noindexRewrite(url);
    }
    // *-escort yolları herkese rehber'e. Bot/insan ayrımı yok.
    if (isCityEscortPath(pathname)) {
      return quietRedirect(new URL(pathname + search, rehberOrigin()), request);
    }
    if (!bot) {
      const city = browserCity(request.headers);
      if (city) {
        const target = toCityPage(city, request);
        if (target) return target;
      }
    }
    if (local) {
      url.pathname = "/vitrin/ilanlar";
      return noindexRewrite(url);
    }
    return quietRedirect(vitrinListingsUrl(), request);
  }

  // Pano domaininde *-escort yolu açılırsa herkes rehber il sayfasına gider.
  if (isCityEscortPath(pathname)) {
    return quietRedirect(new URL(pathname + search, rehberOrigin()), request);
  }

  if (pathname.startsWith("/ilan/") || pathname === "/ilan" || pathname === "/ilan/") {
    if (!local) {
      return quietRedirect(
        new URL(`${pathname.endsWith("/") ? pathname : `${pathname}/`}${search}`, ilanOrigin()),
        request,
      );
    }
  }

  // Pano ana sayfası / ilanlar: konum varsa aynı domainde filtreler.
  // Reklam doğrudan zirvepano.xyz'e geliyorsa burası çalışmaya devam eder.
  const bareListings = pathname === "/" || pathname === "/ilanlar" || pathname === "/ilanlar/";
  if (!bot && bareListings && !request.nextUrl.searchParams.get("sehir")) {
    const city = browserCity(request.headers);
    if (city) {
      if (local) {
        url.pathname = "/vitrin/ilanlar";
        url.searchParams.set("sehir", city);
        return withCityCookie(noindexRewrite(url), city);
      }
      const target = request.nextUrl.clone();
      target.pathname = "/ilanlar/";
      target.searchParams.set("sehir", city);
      return withCityCookie(quietRedirect(target, request), city);
    }
  }

  url.pathname = pathname === "/" || pathname.startsWith("/ilanlar") ? "/vitrin/ilanlar" : `/vitrin${pathname}`;
  return noindexRewrite(url);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|.*\\..*).*)"],
};
