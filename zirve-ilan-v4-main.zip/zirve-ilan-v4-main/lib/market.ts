import { randomUUID } from "crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import path from "path";
import { recordSaleIncome } from "./ledger";
import { isTrc20Address } from "./payments";
import { getSettings } from "./settings";
import { sendTelegramMessage } from "./telegram";

export type MarketProduct = {
  id: string;
  name: string;
  image: string;
  priceUsd: number;
  stock: number;
  active: boolean;
};

export type MarketOrderStatus = "waiting" | "approved" | "rejected";

export type MarketOrder = {
  id: string;
  ownerId: string;
  ownerUsername: string;
  productId: string;
  productName: string;
  image: string;
  qty: number;
  unitUsd: number;
  amountUsd: number;
  note: string;
  address: string;
  status: MarketOrderStatus;
  delivery: string;
  createdAt: string;
  decidedAt: string | null;
};

type MarketFile = { products: MarketProduct[]; orders: MarketOrder[] };

const file = path.join(process.cwd(), "data", "market.json");

const defaults: MarketProduct[] = [
  {
    id: "prod-fiziki-hat",
    name: "Fiziki hat",
    image: "/market/fiziki-hat.jpg",
    priceUsd: 0,
    stock: 0,
    active: true,
  },
  {
    id: "prod-whatsapp",
    name: "WhatsApp numara",
    image: "/market/whatsapp-numara.jpg",
    priceUsd: 0,
    stock: 0,
    active: true,
  },
];

function emptyFile(): MarketFile {
  return { products: defaults.map((item) => ({ ...item })), orders: [] };
}

function readFile(): MarketFile {
  if (!existsSync(file)) {
    const seed = emptyFile();
    writeFile(seed);
    return seed;
  }
  try {
    const raw = JSON.parse(readFileSync(file, "utf8")) as Partial<MarketFile>;
    const products = Array.isArray(raw.products) ? raw.products.filter(isProduct) : [];
    const orders = Array.isArray(raw.orders) ? raw.orders.filter(isOrder) : [];
    if (!products.length) {
      const seed = emptyFile();
      seed.orders = orders;
      writeFile(seed);
      return seed;
    }
    return { products, orders };
  } catch {
    const seed = emptyFile();
    writeFile(seed);
    return seed;
  }
}

function writeFile(data: MarketFile) {
  mkdirSync(path.dirname(file), { recursive: true });
  writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

function isProduct(value: unknown): value is MarketProduct {
  if (!value || typeof value !== "object") return false;
  const item = value as MarketProduct;
  return typeof item.id === "string" && typeof item.name === "string" && typeof item.priceUsd === "number" && typeof item.stock === "number";
}

function isOrder(value: unknown): value is MarketOrder {
  if (!value || typeof value !== "object") return false;
  const item = value as MarketOrder;
  return typeof item.id === "string" && typeof item.ownerId === "string" && typeof item.productId === "string" && typeof item.qty === "number";
}

function roundMoney(value: number) {
  return Math.round(value * 100) / 100;
}

export function cleanMarketNote(value: unknown, max = 300) {
  if (typeof value !== "string") return "";
  return value.replace(/[\u0000-\u001F]+/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
}

export function cleanDelivery(value: unknown) {
  if (typeof value !== "string") return "";
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, 2000);
}

function safeImage(value: unknown) {
  if (typeof value !== "string") return "";
  const image = value.trim().slice(0, 240);
  if (!image.startsWith("/") || image.includes("..")) return "";
  return image;
}

export function marketProducts() {
  return readFile().products;
}

export function marketOrders() {
  return readFile().orders.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
}

export function ordersForOwner(ownerId: string) {
  return marketOrders().filter((item) => item.ownerId === ownerId);
}

export function addMarketProduct(input: { name: string; priceUsd: number; stock: number; image: string }) {
  const name = input.name.trim().slice(0, 80);
  if (name.length < 2) return { error: "Ürün adı yaz." as const };
  if (!(input.priceUsd > 0) || input.priceUsd > 1_000_000) return { error: "Fiyat 0'dan büyük olmalı." as const };
  if (!Number.isInteger(input.stock) || input.stock < 0 || input.stock > 100_000) return { error: "Stok adedi geçersiz." as const };
  const data = readFile();
  const product: MarketProduct = {
    id: randomUUID(),
    name,
    image: safeImage(input.image),
    priceUsd: roundMoney(input.priceUsd),
    stock: input.stock,
    active: true,
  };
  data.products.push(product);
  writeFile(data);
  return { product };
}

export function updateMarketProduct(id: string, input: { name?: string; priceUsd?: number; stock?: number; image?: string; active?: boolean }) {
  const data = readFile();
  const index = data.products.findIndex((item) => item.id === id);
  if (index < 0) return { error: "Ürün yok." as const };
  const current = data.products[index];
  const name = typeof input.name === "string" ? input.name.trim().slice(0, 80) : current.name;
  if (name.length < 2) return { error: "Ürün adı yaz." as const };
  const priceUsd = input.priceUsd == null ? current.priceUsd : roundMoney(input.priceUsd);
  if (!(priceUsd >= 0) || priceUsd > 1_000_000) return { error: "Fiyat geçersiz." as const };
  const stock = input.stock == null ? current.stock : input.stock;
  if (!Number.isInteger(stock) || stock < 0 || stock > 100_000) return { error: "Stok adedi geçersiz." as const };
  data.products[index] = {
    ...current,
    name,
    priceUsd,
    stock,
    image: input.image == null ? current.image : safeImage(input.image),
    active: typeof input.active === "boolean" ? input.active : current.active,
  };
  writeFile(data);
  return { product: data.products[index] };
}

export function deleteMarketProduct(id: string) {
  const data = readFile();
  if (data.orders.some((item) => item.productId === id && item.status === "waiting")) {
    return { error: "Onay bekleyen siparişi olan ürün silinemez." as const };
  }
  const next = data.products.filter((item) => item.id !== id);
  if (next.length === data.products.length) return { error: "Ürün yok." as const };
  data.products = next;
  writeFile(data);
  return { ok: true as const };
}

export async function placeMarketOrder(input: { ownerId: string; ownerUsername: string; productId: string; qty: number; note: string }) {
  if (!Number.isInteger(input.qty) || input.qty < 1 || input.qty > 50) return { error: "Sipariş miktarı 1 ile 50 arasında olmalı." as const };
  const address = getSettings().marketTrc20Address.trim();
  if (!isTrc20Address(address)) return { error: "Market ödeme adresi henüz tanımlı değil." as const };
  const data = readFile();
  const index = data.products.findIndex((item) => item.id === input.productId && item.active);
  if (index < 0) return { error: "Ürün yok." as const };
  const product = data.products[index];
  if (!(product.priceUsd > 0)) return { error: "Bu ürünün fiyatı henüz yok." as const };
  const waiting = data.orders.find((item) => item.ownerId === input.ownerId && item.productId === product.id && item.status === "waiting");
  if (waiting) return { order: waiting };
  if (product.stock < input.qty) return { error: "Stok yetersiz." as const };
  const order: MarketOrder = {
    id: randomUUID(),
    ownerId: input.ownerId,
    ownerUsername: input.ownerUsername,
    productId: product.id,
    productName: product.name,
    image: product.image,
    qty: input.qty,
    unitUsd: product.priceUsd,
    amountUsd: roundMoney(product.priceUsd * input.qty),
    note: cleanMarketNote(input.note),
    address,
    status: "waiting",
    delivery: "",
    createdAt: new Date().toISOString(),
    decidedAt: null,
  };
  data.products[index] = { ...product, stock: product.stock - input.qty };
  data.orders.unshift(order);
  writeFile(data);
  const sent = await sendTelegramMessage(
    `Market siparişi\n${input.ownerUsername}\n${product.name} × ${input.qty}\n${order.amountUsd} $\nOnay bekliyor.`,
    { stamp: false },
  );
  if (!sent.ok && sent.error !== "Bot token veya chat id yok.") {
    /* Bildirim gitmese de sipariş durur. */
  }
  return { order };
}

export function decideMarketOrder(id: string, action: "approve" | "reject", deliveryText: unknown) {
  const data = readFile();
  const index = data.orders.findIndex((item) => item.id === id);
  if (index < 0) return { error: "Sipariş yok." as const };
  const current = data.orders[index];
  if (current.status !== "waiting") return { error: "Bu sipariş zaten kapanmış." as const };
  const decidedAt = new Date().toISOString();
  if (action === "reject") {
    const productIndex = data.products.findIndex((item) => item.id === current.productId);
    if (productIndex >= 0) data.products[productIndex] = { ...data.products[productIndex], stock: data.products[productIndex].stock + current.qty };
    data.orders[index] = { ...current, status: "rejected", decidedAt };
    writeFile(data);
    return { order: data.orders[index] };
  }
  const delivery = cleanDelivery(deliveryText);
  if (!delivery) return { error: "Dijital teslim bilgisini yaz." as const };
  data.orders[index] = { ...current, status: "approved", delivery, decidedAt };
  writeFile(data);
  recordSaleIncome({
    id: current.id,
    ownerUsername: current.ownerUsername,
    amountUsd: current.amountUsd,
    note: `${current.productName} × ${current.qty}`,
    at: decidedAt,
  });
  return { order: data.orders[index] };
}
