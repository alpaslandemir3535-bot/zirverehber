"use client";

import { durationLabel, isListingLive, type Listing } from "@/lib/listing-types";
import { useRouter } from "next/navigation";
import { useState } from "react";

function statusLabel(listing: Listing) {
  if (listing.status === "published" && !isListingLive(listing)) return "Süresi doldu";
  if (listing.status === "published") return "Yayında";
  if (listing.status === "hidden") return "Gizli";
  return "Taslak";
}

export function SortableList({
  listings,
  editBase = "/panel/ilan",
  listingClicks = {},
  whatsappClicks = {},
}: {
  listings: Listing[];
  editBase?: string;
  listingClicks?: Record<string, number>;
  whatsappClicks?: Record<string, number>;
}) {
  const router = useRouter();
  const [rows, setRows] = useState(listings);
  const [dragId, setDragId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function onDrop(targetId: string) {
    if (!dragId || dragId === targetId) return;
    const next = [...rows];
    const from = next.findIndex((item) => item.id === dragId);
    const to = next.findIndex((item) => item.id === targetId);
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    setRows(next);
    setDragId(null);
  }

  async function saveOrder() {
    setSaving(true);
    await fetch("/api/listings/reorder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: rows.map((item) => item.id) }),
    });
    setSaving(false);
    router.refresh();
  }

  return (
    <div className="panel-card">
      <div className="panel-row">
        <p>Satırı tutup sürükle. Sıra sitedeki ızgaraya işler.</p>
        <button className="btn" type="button" onClick={saveOrder} disabled={saving}>
          {saving ? "Kaydediliyor..." : "Sırayı kaydet"}
        </button>
      </div>
      <table>
        <thead>
          <tr>
            <th></th>
            <th>İlan</th>
            <th>Kategori</th>
            <th>Şehir / ilçe</th>
            <th>Durum</th>
            <th>Süre</th>
            <th>İlan tık</th>
            <th>WA</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((listing) => (
            <tr
              key={listing.id}
              draggable
              onDragStart={() => setDragId(listing.id)}
              onDragOver={(event) => event.preventDefault()}
              onDrop={() => onDrop(listing.id)}
              className={dragId === listing.id ? "dragging" : ""}
            >
              <td className="drag-handle">↕</td>
              <td>
                <strong>{listing.displayName}</strong>
                <div>{listing.phone}</div>
                <div>
                  {listing.age} yaş
                  {listing.height ? ` · ${listing.height} cm` : ""}
                  {listing.weight ? ` · ${listing.weight} kg` : ""}
                </div>
                {listing.featured ? <span className="badge">VIP</span> : null}
                {listing.gold ? <span className="badge">GOLD</span> : null}
                {listing.yeni ? <span className="badge">YENİ</span> : null}
              </td>
              <td>{listing.category}</td>
              <td>
                {listing.cities.length} il
                {listing.districts.length ? ` / ${listing.districts.length} ilçe` : ""}
              </td>
              <td>
                <span className={`badge ${listing.status}`}>{statusLabel(listing)}</span>
              </td>
              <td>
                {durationLabel(listing.duration)}
                {listing.expiresAt ? <div>{new Date(listing.expiresAt).toLocaleDateString("tr-TR")}</div> : null}
              </td>
              <td>{listingClicks[listing.id] || 0}</td>
              <td>{whatsappClicks[listing.id] || 0}</td>
              <td>
                <a className="btn ghost" href={`${editBase}/${listing.id}/`}>
                  Düzenle
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
