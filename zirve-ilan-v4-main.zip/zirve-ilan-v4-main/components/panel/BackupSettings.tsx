"use client";

import { useState } from "react";

type DirHandle = {
  getFileHandle: (
    name: string,
    options: { create: boolean },
  ) => Promise<{
    createWritable: () => Promise<{ write: (data: Blob) => Promise<void>; close: () => Promise<void> }>;
  }>;
};

type Props = {
  lastBackupAt: string | null;
  backupDue: boolean;
};

function stampName() {
  return `zirve-yedek-${new Date().toISOString().slice(0, 10)}.zip`;
}

export function BackupSettings({ lastBackupAt, backupDue }: Props) {
  const [busy, setBusy] = useState("");
  const [message, setMessage] = useState("");
  const [dir, setDir] = useState("");

  async function pullZip() {
    const res = await fetch("/api/backup");
    if (!res.ok) {
      const json = await res.json().catch(() => ({}));
      throw new Error(json.error || "Yedek alınamadı.");
    }
    const blob = await res.blob();
    const match = /filename="([^"]+)"/.exec(res.headers.get("Content-Disposition") || "");
    return { blob, filename: match?.[1] || stampName() };
  }

  async function download() {
    setBusy("download");
    setMessage("");
    try {
      const { blob, filename } = await pullZip();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      link.click();
      URL.revokeObjectURL(url);
      setMessage("Yedek indirildi. USB’ye kopyalayabilirsin.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Yedek alınamadı.");
    }
    setBusy("");
  }

  async function saveUsb() {
    setBusy("usb");
    setMessage("");
    try {
      const picker = (window as unknown as { showDirectoryPicker?: (options: { mode: "readwrite" }) => Promise<DirHandle> })
        .showDirectoryPicker;
      if (!picker) {
        await download();
        setMessage("Bu tarayıcı klasör seçemiyor. Yedek indirildi, USB’ye kendin kaydet.");
        setBusy("");
        return;
      }
      const folder = await picker({ mode: "readwrite" });
      const { blob, filename } = await pullZip();
      const handle = await folder.getFileHandle(filename, { create: true });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      setMessage("Yedek seçtiğin klasöre yazıldı.");
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") setMessage("Klasör seçimi iptal edildi.");
      else setMessage(error instanceof Error ? error.message : "USB kaydı olmadı.");
    }
    setBusy("");
  }

  async function savePath(event: React.FormEvent) {
    event.preventDefault();
    setBusy("path");
    setMessage("");
    const res = await fetch("/api/backup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dir }),
    });
    const json = await res.json();
    setBusy("");
    setMessage(res.ok ? `${json.filename} klasöre yazıldı.` : json.error || "Yazılamadı.");
  }

  const when = lastBackupAt ? new Date(lastBackupAt).toLocaleString("tr-TR") : "henüz yok";

  return (
    <div className="panel-card">
      <p className={backupDue ? "err" : "muted"}>Son yedek: {when}. Haftada bir tam veritabanı ve ilan görsellerini USB’ye al.</p>
      <div className="row-actions" style={{ marginTop: 12 }}>
        <button className="btn" type="button" onClick={saveUsb} disabled={Boolean(busy)}>
          {busy === "usb" ? "Kaydediliyor" : "USB belleğe kaydet"}
        </button>
        <button className="btn secondary" type="button" onClick={download} disabled={Boolean(busy)}>
          {busy === "download" ? "Hazırlanıyor" : "Bilgisayara indir"}
        </button>
      </div>
      <form className="form-grid" style={{ marginTop: 16 }} onSubmit={savePath}>
        <label className="full">
          Sunucu bu bilgisayardaysa klasör yolu
          <input value={dir} onChange={(event) => setDir(event.target.value)} placeholder="E:\ZirveYedek" />
        </label>
        <div>
          <button className="btn ghost" type="submit" disabled={Boolean(busy) || !dir.trim()}>
            {busy === "path" ? "Yazılıyor" : "Bu yola yaz"}
          </button>
        </div>
      </form>
      {message ? <p>{message}</p> : null}
    </div>
  );
}
