import { AdCard } from "@/components/AdCard";
import type { Listing } from "@/lib/listings";
import { getSettings } from "@/lib/settings";

export function AdGrid({
  listings,
  cityName,
}: {
  listings: Listing[];
  cityName?: string;
}) {
  if (!listings.length) {
    return (
      <p className="muted" style={{ padding: "24px 16px" }}>
        {cityName ? `${cityName} için henüz yayınlanmış ilan yok.` : "Henüz yayınlanmış ilan yok."}
      </p>
    );
  }

  const rotatePhotos = getSettings().rotatePhotos !== false;
  return (
    <div className="grid-container">
      {listings.map((listing, index) => (
        <AdCard key={listing.slug} listing={listing} cityName={cityName} index={index} rotatePhotos={rotatePhotos} />
      ))}
    </div>
  );
}
