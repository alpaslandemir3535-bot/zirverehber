import { DeleteListing } from "@/components/panel/DeleteListing";
import { ListingForm } from "@/components/panel/ListingForm";
import { listingById } from "@/lib/store";
import { getOwners } from "@/lib/users";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function EditListingPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const listing = listingById(id);
  if (!listing) notFound();
  const owners = getOwners().map(({ passwordHash: _h, ...owner }) => owner);

  return (
    <>
      <div className="panel-row">
        <h1>İlanı düzenle</h1>
        <div>
          <a className="btn secondary" href="/panel/ilanlar/">
            Listeye dön
          </a>{" "}
          <DeleteListing id={listing.id} />
        </div>
      </div>
      <ListingForm listing={listing} owners={owners} />
    </>
  );
}
