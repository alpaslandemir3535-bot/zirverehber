"use client";

import Image from "next/image";
import { useEffect, useState } from "react";

export function CardSlide({
  images,
  alt,
  eager = false,
  rotate = true,
}: {
  images: string[];
  alt: string;
  eager?: boolean;
  rotate?: boolean;
}) {
  const frames = images.filter(Boolean);
  const signature = frames.join("|");
  const [index, setIndex] = useState(0);

  useEffect(() => {
    setIndex(0);
  }, [signature]);

  useEffect(() => {
    if (!rotate || frames.length < 2) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => {
      setIndex((current) => (current + 1) % frames.length);
    }, 2200);
    return () => window.clearInterval(timer);
  }, [signature, frames.length, rotate]);

  const src = frames[index] || frames[0];
  if (!src) return null;
  return (
    <Image
      alt={alt}
      src={src}
      width={332}
      height={552}
      sizes="(max-width: 767px) 50vw, (max-width: 1099px) 33vw, 25vw"
      priority={eager}
      loading={eager ? undefined : "lazy"}
    />
  );
}
