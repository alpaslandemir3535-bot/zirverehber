import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { publicSettings, rehberDescriptionText, saveSettings } from "@/lib/settings";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { rehberDescription?: string } | null;
  const text = rehberDescriptionText(body?.rehberDescription);
  if (text.length < 20) return NextResponse.json({ error: "Açıklama en az 20 karakter olsun." }, { status: 400 });
  saveSettings({ rehberDescription: text });
  return NextResponse.json(publicSettings());
}
