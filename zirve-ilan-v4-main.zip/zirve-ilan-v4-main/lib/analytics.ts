import path from "path";
import { cities, resolveCitySlug } from "./cities";
import { readJsonFile, writeJsonFile } from "./json-file";
import { ilanOrigin, panoOrigin, rehberOrigin } from "./site";
import { getPublishedListings, listingById } from "./store";

type TrafficSource = "direct" | "reklam" | "google" | "arama" | "yonlendirme";

type DayBucket = {
  views: number;
  visitors: string[];
  listingClicks: Record<string, number>;
  listingVisitors?: Record<string, string[]>;
  whatsappClicks: Record<string, number>;
  cityViews: Record<string, number>;
  cityVisitors: Record<string, string[]>;
  deviceVisitors?: { mobile: string[]; desktop: string[] };
  sourceVisitors?: Partial<Record<TrafficSource, string[]>>;
  terms?: Record<string, number>;
  googleHiddenVisitors?: string[];
};

type Store = {
  days: Record<string, DayBucket>;
  totalVisitors?: number;
  seenVisitors?: Record<string, true>;
};

const file = path.join(process.cwd(), "data", "analytics.json");
const KEEP_DAYS = 90;

export function dayKey(date = new Date()) {
  return date.toLocaleDateString("en-CA", { timeZone: "Europe/Istanbul" });
}

function emptyDay(): DayBucket {
  return {
    views: 0,
    visitors: [],
    listingClicks: {},
    listingVisitors: {},
    whatsappClicks: {},
    cityViews: {},
    cityVisitors: {},
    deviceVisitors: { mobile: [], desktop: [] },
    sourceVisitors: {},
    terms: {},
    googleHiddenVisitors: [],
  };
}

function readStore(): Store {
  const parsed = readJsonFile<Store | null>(file, null);
  const raw: Store =
    parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? parsed
      : { days: {}, totalVisitors: 0, seenVisitors: {} };
  if (!raw.days || typeof raw.days !== "object") raw.days = {};
  Object.entries(raw.days).forEach(([key, day]) => {
    if (!day || typeof day !== "object") {
      delete raw.days[key];
      return;
    }
    day.views = Number(day.views) || 0;
    day.visitors = Array.isArray(day.visitors) ? day.visitors : [];
    day.listingClicks ||= {};
    day.whatsappClicks ||= {};
    day.cityViews ||= {};
    day.cityVisitors ||= {};
  });
  if (!raw.seenVisitors || typeof raw.totalVisitors !== "number") {
    const seen: Record<string, true> = { ...(raw.seenVisitors || {}) };
    Object.values(raw.days).forEach((day) => {
      day.visitors.forEach((id) => {
        seen[id] = true;
      });
    });
    raw.seenVisitors = seen;
    raw.totalVisitors = Object.keys(seen).length;
    writeStore(raw);
  }
  return raw;
}

function writeStore(store: Store) {
  const keys = Object.keys(store.days).sort();
  const drop = keys.slice(0, Math.max(0, keys.length - KEEP_DAYS));
  drop.forEach((key) => {
    delete store.days[key];
  });
  writeJsonFile(file, store, false);
}

function dayOrCreate(store: Store, key: string) {
  store.days[key] ||= emptyDay();
  const day = store.days[key];
  day.cityViews ||= {};
  day.cityVisitors ||= {};
  day.listingVisitors ||= {};
  return day;
}

const SOURCES = ["direct", "reklam", "google", "arama", "yonlendirme"] as const;

function cleanTerm(value?: string | null) {
  return (value || "").replace(/[<>"]/g, "").replace(/\s+/g, " ").trim().slice(0, 80);
}

export function trackEvent(input: {
  type: "view" | "listing" | "whatsapp";
  visitorId?: string;
  listingId?: string;
  city?: string | null;
  device?: "mobile" | "desktop" | null;
  source?: string | null;
  term?: string | null;
}) {
  const store = readStore();
  const day = dayOrCreate(store, dayKey());
  day.deviceVisitors ||= { mobile: [], desktop: [] };
  day.sourceVisitors ||= {};
  day.terms ||= {};
  day.googleHiddenVisitors ||= [];
  const citySlug = resolveCitySlug(input.city);
  const visitor = input.visitorId?.slice(0, 64);
  if (input.type === "view") {
    const firstToday = !visitor || !day.visitors.includes(visitor);
    if (firstToday) day.views += 1;
    if (visitor && firstToday) {
      day.visitors.push(visitor);
      store.seenVisitors ||= {};
      if (!store.seenVisitors[visitor]) {
        store.seenVisitors[visitor] = true;
        store.totalVisitors = (store.totalVisitors || 0) + 1;
      }
      if (input.device === "mobile" || input.device === "desktop") {
        const deviceList = day.deviceVisitors![input.device];
        if (!deviceList.includes(visitor)) deviceList.push(visitor);
      }
      const source = SOURCES.find((item) => item === input.source);
      if (source) {
        const sourceList = day.sourceVisitors![source] || [];
        if (!sourceList.includes(visitor)) {
          sourceList.push(visitor);
          day.sourceVisitors![source] = sourceList;
        }
        const term = cleanTerm(input.term);
        if (term) day.terms![term] = (day.terms![term] || 0) + 1;
        else if (source === "google" && !day.googleHiddenVisitors!.includes(visitor)) day.googleHiddenVisitors!.push(visitor);
      }
    }
  }
  if (input.type === "listing" && input.listingId) {
    const seen = day.listingVisitors![input.listingId] || [];
    const firstListing = !visitor || !seen.includes(visitor);
    if (firstListing) {
      day.listingClicks[input.listingId] = (day.listingClicks[input.listingId] || 0) + 1;
      if (visitor) {
        seen.push(visitor);
        day.listingVisitors![input.listingId] = seen;
      }
    }
  }
  if (input.type === "whatsapp" && input.listingId) {
    day.whatsappClicks[input.listingId] = (day.whatsappClicks[input.listingId] || 0) + 1;
  }
  if (citySlug && input.type !== "whatsapp") {
    const list = day.cityVisitors[citySlug] || [];
    const firstCity = !visitor || !list.includes(visitor);
    if (firstCity) {
      day.cityViews[citySlug] = (day.cityViews[citySlug] || 0) + 1;
      if (visitor) {
        list.push(visitor);
        day.cityVisitors[citySlug] = list;
      }
    }
  }
  writeStore(store);
}

function istanbulWeekKeys(now = new Date()) {
  const [year, month, day] = dayKey(now).split("-").map(Number);
  const noon = new Date(Date.UTC(year, month - 1, day, 9, 0, 0));
  const weekday = noon.getUTCDay();
  const sinceMonday = weekday === 0 ? 6 : weekday - 1;
  const keys: string[] = [];
  for (let i = sinceMonday; i >= 0; i -= 1) {
    keys.push(dayKey(new Date(noon.getTime() - i * 24 * 60 * 60 * 1000)));
  }
  return keys;
}

export function todayListingClicks() {
  const day = readStore().days[dayKey()];
  return day?.listingClicks || {};
}

export function whatsappForListing(listingId: string) {
  const store = readStore();
  const clicks = (key: string) => store.days[key]?.whatsappClicks?.[listingId] || 0;
  return {
    today: clicks(dayKey()),
    week: istanbulWeekKeys().reduce((sum, key) => sum + clicks(key), 0),
  };
}

function rangeKeys(days: number) {
  const keys: string[] = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i -= 1) {
    const date = new Date(now);
    date.setDate(now.getDate() - i);
    keys.push(dayKey(date));
  }
  return keys;
}

function sumDays(store: Store, keys: string[]) {
  let views = 0;
  let listingClicks = 0;
  let whatsappClicks = 0;
  const visitors = new Set<string>();
  const listingTotals: Record<string, number> = {};
  const waTotals: Record<string, number> = {};
  keys.forEach((key) => {
    const day = store.days[key];
    if (!day) return;
    views += day.views;
    day.visitors.forEach((id) => visitors.add(id));
    Object.entries(day.listingClicks).forEach(([id, count]) => {
      listingClicks += count;
      listingTotals[id] = (listingTotals[id] || 0) + count;
    });
    Object.entries(day.whatsappClicks).forEach(([id, count]) => {
      whatsappClicks += count;
      waTotals[id] = (waTotals[id] || 0) + count;
    });
  });
  return { views, visitors: visitors.size, listingClicks, whatsappClicks, listingTotals, waTotals };
}

function cityStats(store: Store, keys: string[]) {
  const views: Record<string, number> = {};
  const visitors: Record<string, Set<string>> = {};
  keys.forEach((key) => {
    const day = store.days[key];
    if (!day) return;
    Object.entries(day.cityViews || {}).forEach(([slug, count]) => {
      views[slug] = (views[slug] || 0) + count;
    });
    Object.entries(day.cityVisitors || {}).forEach(([slug, ids]) => {
      visitors[slug] ||= new Set();
      ids.forEach((id) => visitors[slug].add(id));
    });
  });
  return cities.map((city) => ({
    slug: city.slug,
    name: city.name,
    views: views[city.slug] || 0,
    visitors: visitors[city.slug]?.size || 0,
  }));
}

export function getDashboardStats() {
  const store = readStore();
  const today = rangeKeys(1);
  const week = rangeKeys(7);
  const month = rangeKeys(30);
  const last14 = rangeKeys(14);
  const series = last14.map((key) => {
    const day = store.days[key] || emptyDay();
    return {
      date: key.slice(5),
      visitors: day.visitors.length,
      views: day.views,
      listingClicks: Object.values(day.listingClicks).reduce((a, b) => a + b, 0),
      whatsappClicks: Object.values(day.whatsappClicks).reduce((a, b) => a + b, 0),
    };
  });
  return {
    totalVisitors: store.totalVisitors || 0,
    today: sumDays(store, today),
    week: sumDays(store, week),
    month: sumDays(store, month),
    citiesToday: cityStats(store, today),
    citiesMonth: cityStats(store, month),
    series,
  };
}

export type TrafficSlice = {
  mobile: number;
  desktop: number;
  direct: number;
  google: number;
  arama: number;
  yonlendirme: number;
};

function trafficSlice(store: Store, keys: string[]): TrafficSlice {
  const devices = { mobile: new Set<string>(), desktop: new Set<string>() };
  const sources = {
    direct: new Set<string>(),
    reklam: new Set<string>(),
    google: new Set<string>(),
    arama: new Set<string>(),
    yonlendirme: new Set<string>(),
  };
  keys.forEach((key) => {
    const day = store.days[key];
    if (!day) return;
    day.deviceVisitors?.mobile?.forEach((id) => devices.mobile.add(id));
    day.deviceVisitors?.desktop?.forEach((id) => devices.desktop.add(id));
    (Object.keys(sources) as TrafficSource[]).forEach((source) => {
      day.sourceVisitors?.[source]?.forEach((id) => sources[source].add(id));
    });
  });
  sources.reklam.forEach((id) => sources.google.add(id));
  return {
    mobile: devices.mobile.size,
    desktop: devices.desktop.size,
    direct: sources.direct.size,
    google: sources.google.size,
    arama: sources.arama.size,
    yonlendirme: sources.yonlendirme.size,
  };
}

export function getTrafficStats() {
  const store = readStore();
  return {
    today: trafficSlice(store, rangeKeys(1)),
    week: trafficSlice(store, rangeKeys(7)),
    month: trafficSlice(store, rangeKeys(30)),
  };
}

export function topEntries(totals: Record<string, number>, limit = 8) {
  return Object.entries(totals)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([id, count]) => ({
      id,
      count,
      name: listingById(id)?.displayName || id,
    }));
}

function pct(part: number, total: number) {
  if (!total) return "0,0";
  return (part / total * 100).toLocaleString("tr-TR", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
}

export function formatStatsMessage(_part: 1 | 2 = 1) {
  const stats = getDashboardStats();
  const store = readStore();
  const last24 = sumDays(store, rangeKeys(2));
  const stamp = new Date().toLocaleString("tr-TR", {
    timeZone: "Europe/Istanbul",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
  const ids = new Set([...Object.keys(stats.today.listingTotals), ...Object.keys(stats.today.waTotals)]);
  const top = [...ids]
    .map((id) => ({
      name: listingById(id)?.displayName || listingById(id)?.name || "İlan",
      clicks: stats.today.listingTotals[id] || 0,
      wa: stats.today.waTotals[id] || 0,
    }))
    .sort((a, b) => b.clicks - a.clicks || b.wa - a.wa)
    .slice(0, 5);
  const cities = stats.citiesToday
    .filter((row) => row.views)
    .sort((a, b) => b.views - a.views)
    .slice(0, 8)
    .map((row) => `• ${row.name}: ${row.views} gor.`);

  return [
    "📊 Zirve İlan — Site Özeti",
    `🕐 ${stamp}`,
    "",
    `👁 Bugün: ${stats.today.views} goruntulenme`,
    `💬 Bugün: ${stats.today.whatsappClicks} WhatsApp tik`,
    `📈 CTR: %${pct(stats.today.whatsappClicks, stats.today.views)}`,
    `📅 Son 24s: ${last24.views} / ${last24.whatsappClicks} WA`,
    "",
    `📋 İlanlar: ${getPublishedListings().length} yayinda`,
    "",
    "🏆 En cok goruntulenen:",
    top.length ? top.map((row, index) => `${index + 1}. ${row.name} — ${row.clicks} / ${row.wa} WA`).join("\n") : "Henüz tiklama yok.",
    "",
    "📍 Sehir (bugun):",
    cities.length ? cities.join("\n") : "Henüz sehir girisi yok.",
    "",
    `🔗 Ön alan: ${panoOrigin()}`,
    `🔗 İlan: ${ilanOrigin()}`,
    `🔗 Panel: ${rehberOrigin()}/panel/`,
  ].join("\n");
}
