import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { saveSettings } from "@/lib/settings";
import { mkdirSync, readdirSync, unlinkSync, writeFileSync } from "fs";
import path from "path";
import { NextResponse } from "next/server";

const MAX_BYTES = 2 * 1024 * 1024;
const dir = path.join(process.cwd(), "public", "uploads", "site");

function sniff(buf: Buffer) {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.length >= 4 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "png";
  if (buf.length >= 12 && buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WEBP") {
    return "webp";
  }
  return null;
}

function clearOld() {
  mkdirSync(dir, { recursive: true });
  for (const name of readdirSync(dir)) {
    if (name.startsWith("vitrin-bg.")) unlinkSync(path.join(dir, name));
  }
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "Görsel seç." }, { status: 400 });
  if (file.size > MAX_BYTES) return NextResponse.json({ error: "Zemin fotoğrafı en fazla 2 MB." }, { status: 400 });
  const buf = Buffer.from(await file.arrayBuffer());
  const ext = sniff(buf);
  if (!ext) return NextResponse.json({ error: "PNG, JPG veya WEBP yükle." }, { status: 400 });
  clearOld();
  const name = `vitrin-bg.${ext}`;
  writeFileSync(path.join(dir, name), buf);
  const vitrinBgImage = `/uploads/site/${name}?v=${Date.now()}`;
  saveSettings({ vitrinBgImage });
  return NextResponse.json({ ok: true, vitrinBgImage });
}

export async function DELETE(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  clearOld();
  saveSettings({ vitrinBgImage: "" });
  return NextResponse.json({ ok: true, vitrinBgImage: "" });
}
