import type { City } from "./cities";
import { districtsFor } from "./districts";

export type CitySection = { heading: string; body: string };

export type CityContent = {
  /** Meta açıklama. 140-160 karakter arası tutulur. */
  description: string;
  sections: CitySection[];
};

// Her il kendi metnini taşır. Şablon cümle paylaşılmaz; semtler, mesafeler ve
// günün hangi saatinde neyin açık olduğu ile ilgili bilgiler ile yazılır.
export const CITY_CONTENT: Record<string, CityContent> = {
  adana: {
    description:
      "Adana escort ilanları Seyhan, Çukurova, Yüreğir ve Ceyhan ayrımıyla listelenir. Semt etiketine, güncel fotoğrafa ve iletişim numarasına tek sayfadan bakılır.",
    sections: [
      {
        heading: "Seyhan ile Çukurova arasında mesafe kısadır",
        body: "Adana'da şehir, Seyhan Nehri'nin iki yakasına kurulmuştur. Eski merkez ve çarşı Seyhan tarafında, yeni konut alanları ile kafelerin çoğu Çukurova tarafında toplanır. İki yaka arasında araçla on beş dakikalık bir mesafe vardır, bu yüzden ilanlarda semt farkı pratikte büyük bir zaman kaybı yaratmaz. Yüreğir ve Sarıçam ise merkeze göre daha dışarıda kalır.",
      },
      {
        heading: "Ceyhan ve çevre ilçelerden gelen ilanlar",
        body: "Ceyhan, Adana merkeze otoyoldan yaklaşık kırk dakikadır ve kendi içinde ayrı bir hareketliliği vardır. Listede Ceyhan etiketli bir ilan görürsen mesafeyi hesaba katmak gerekir. Adana yazın uzun süre sıcak kaldığı için şehrin günlük temposu akşam saatlerine kayar; ilanların güncellenme saatleri de çoğunlukla bu saatlere denk gelir.",
      },
      {
        heading: "Şakirpaşa Havalimanı şehrin içindedir",
        body: "Adana Şakirpaşa Havalimanı merkeze yalnızca birkaç kilometre uzaklıktadır ve araçla on dakikada ulaşılır; bu yönüyle Türkiye'de merkeze en yakın havalimanlarından biridir. Otogar ise batı çıkışında, çevre yoluna bitişik konumdadır. Şehir dışından gelen biri için giriş noktaları birbirine yakın olduğundan ilk ulaşım planı kolay kurulur.",
      },
    ],
  },
  adiyaman: {
    description:
      "Adıyaman escort ilanları merkez, Kahta ve Besni ayrımıyla tek listede toplanır. Her ilanda fotoğraf, ilçe etiketi ve iletişim numarası birlikte durur.",
    sections: [
      {
        heading: "Merkez küçük, Kahta ayrı bir durak",
        body: "Adıyaman merkez yürünebilir ölçüde bir şehirdir; çarşı ile konut alanları birbirine yakındır. Kahta ise Nemrut yoluna açılan ayrı bir ilçedir ve merkeze yaklaşık kırk beş dakika uzaklıktadır. Besni de benzer bir mesafededir. Bu yüzden listede ilçe etiketi, fotoğraftan sonra bakılacak ilk bilgidir.",
      },
      {
        heading: "Turizm sezonunda tempo değişir",
        body: "Nemrut Dağı'na çıkan ziyaretçiler nisan ile ekim arasında yoğunlaşır ve şehirdeki otel doluluğu bu dönemde artar. Kış aylarında ise ilan sayısı belirgin biçimde azalır. Sayfayı aralıklarla kontrol etmek, kış döneminde güncel ilanı yakalamanın en pratik yoludur.",
      },
      {
        heading: "Ulaşım karayolu ağırlıklıdır",
        body: "Adıyaman Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır ve sefer sayısı sınırlıdır. Bu nedenle şehre giriş çıkışın büyük bölümü karayoluyla, Gaziantep ve Malatya yönünden yapılır. Gaziantep'e yaklaşık iki buçuk, Malatya'ya ise iki saatte ulaşılır. Otogar merkeze yakındır ve ilçe minibüsleri buradan kalkar.",
      },
    ],
  },
  afyonkarahisar: {
    description:
      "Afyonkarahisar escort ilanları merkez, Sandıklı ve Bolvadin ayrımıyla listelenir. Termal otel bölgesi ile merkez arasındaki mesafe ilanda belirtilir.",
    sections: [
      {
        heading: "Termal bölge şehir merkezinin dışındadır",
        body: "Afyonkarahisar'ın bilinen termal otelleri merkezin birkaç kilometre dışında, Ömer ve Gecek yönünde toplanmıştır. Şehir merkezi ise kale eteğindeki çarşı çevresinde kalır. İlanlarda termal bölge mi yoksa merkez mi tarif edildiğine bakmak gerekir; ikisi arasında araçla yirmi dakikalık bir yol vardır.",
      },
      {
        heading: "Otoyol kavşağı şehri hareketli tutar",
        body: "Afyon, İzmir, Ankara, Antalya ve Konya yollarının kesiştiği noktadadır. Bu konum şehri yıl boyu geçiş trafiğine açık tutar ve hafta içi ile hafta sonu arasındaki fark diğer Ege illerine göre daha azdır. Sandıklı ve Bolvadin ilanları ise merkeze yaklaşık bir saat mesafede kalır.",
      },
      {
        heading: "Hızlı tren ve otogar bağlantısı",
        body: "Afyonkarahisar, Ankara ile İzmir ve Konya hatlarının kesiştiği bir demiryolu düğümüdür; gar merkeze yürüme mesafesindedir. Otogar ise çevre yolu üzerindedir. Şehre giriş çıkışın büyük kısmı otoyolla olur ve dört ayrı ile uzanan bağlantı, günübirlik gelenler için şehri uygun bir durak haline getirir.",
      },
    ],
  },
  agri: {
    description:
      "Ağrı escort ilanları merkez, Doğubayazıt ve Patnos ayrımıyla listelenir. Kış koşullarında yol süreleri uzadığı için ilçe etiketi listede öne çıkarılır.",
    sections: [
      {
        heading: "Doğubayazıt merkeze bağlı ama uzaktır",
        body: "Ağrı merkez ile Doğubayazıt arasında doksan kilometreye yakın bir yol vardır ve bu mesafe kış aylarında saatlerce sürebilir. Patnos ise diğer yönde, Van sınırına yakın durur. Üç yerleşim birbirine bağlı görünse de pratikte ayrı ayrı değerlendirilmesi gerekir; listedeki ilçe bilgisi bu yüzden önemlidir.",
      },
      {
        heading: "Kış ayları planı belirler",
        body: "Ağrı'da kar aralık ile mart arasında yolları doğrudan etkiler ve şehirler arası geçişler sık sık aksar. Bu dönemde ilan sayısı düşer, güncellemeler seyrekleşir. Yaz aylarında ise Doğubayazıt'tan İran sınırına uzanan hat üzerinde hareketlilik artar.",
      },
      {
        heading: "Havalimanı merkeze yakın",
        body: "Ağrı Havalimanı şehir merkezine birkaç kilometre uzaklıktadır ve kış aylarında hava koşullarına bağlı olarak seferler zaman zaman iptal edilebilir. Doğubayazıt'a ise havalimanı yoktur; ilçeye ulaşım karayoluyla sağlanır. Otogar merkezde olduğundan ilçe bağlantıları buradan kurulur.",
      },
    ],
  },
  amasya: {
    description:
      "Amasya escort ilanları merkez, Merzifon ve Suluova ayrımıyla listelenir. Yeşilırmak kıyısındaki merkez yürünebilir olduğu için semt farkı azdır.",
    sections: [
      {
        heading: "Merkez vadi içinde ve dardır",
        body: "Amasya, Yeşilırmak'ın iki yakasına sıkışmış dar bir vadide kuruludur. Şehrin merkezi baştan sona yürünebilir ölçüdedir, bu yüzden merkez etiketli ilanlar arasında mesafe farkı neredeyse yoktur. Kral kaya mezarlarının altındaki tarihi evler bölgesi ile yeni konut alanları arasında yalnızca birkaç dakikalık yol vardır.",
      },
      {
        heading: "Merzifon ayrı bir yerleşim gibidir",
        body: "Merzifon, merkeze yaklaşık kırk kilometre uzaklıkta ve kendi çarşısı olan ayrı bir ilçedir. Havalimanı da bu taraftadır. Suluova ise ikisinin arasında kalır. Merkez dışı etiketli ilanlarda ulaşımı önceden planlamak gerekir, çünkü ilçeler arası toplu taşıma akşam saatlerinde seyrekleşir.",
      },
      {
        heading: "Merzifon Havalimanı ortak kullanılır",
        body: "Amasya'ya hava yoluyla giriş Merzifon'daki havalimanından yapılır; merkeze yaklaşık elli kilometre uzaklıktadır ve araçla bir saat sürer. Tren hattı da şehirden geçer ve gar merkeze yakındır. Samsun'a yaklaşık iki, Çorum'a ise bir buçuk saatte ulaşılır.",
      },
    ],
  },
  ankara: {
    description:
      "Ankara escort ilanları Çankaya, Kızılay, Çayyolu, Keçiören ve Etimesgut ayrımıyla listelenir. Her ilanda semt etiketi ve fotoğraf birlikte durur.",
    sections: [
      {
        heading: "Semtler arası mesafe şehrin en belirleyici konusu",
        body: "Ankara geniş bir alana yayılır ve semtler arası fark yarım saati rahatlıkla bulur. Kızılay ile Çankaya merkez hattını oluşturur; Çayyolu ve Ümitköy batıda, Keçiören ile Altındağ kuzeyde kalır. Etimesgut ve Sincan ise daha uzakta, Eskişehir yolu üzerindedir. Bu yüzden listede önce semt etiketine bakmak zaman kazandırır.",
      },
      {
        heading: "Metro hattı planı kolaylaştırır",
        body: "Kızılay'dan Çayyolu'na ve Batıkent'e uzanan metro hatları, Ankara'da semtler arası geçişin en öngörülebilir yoludur. Trafiğin yoğunlaştığı akşam saatlerinde araçla kırk dakika süren bir yol metroyla yarıya inebilir. İlan sahibinin tarif ettiği semti metro hattına göre düşünmek, buluşma saatini tutturmak açısından işe yarar.",
      },
      {
        heading: "Esenboğa, YHT garı ve AŞTİ",
        body: "Ankara'ya giriş noktaları birbirinden uzaktır. Esenboğa Havalimanı merkeze yaklaşık otuz beş kilometre ve kırk dakika mesafededir. YHT garı Ankara Garı'nın yanındadır ve metroyla Kızılay'a doğrudan bağlanır. AŞTİ ise Söğütözü'ndedir ve yine metro hattı üzerindedir. Hangi noktadan gelindiği, hangi semtin daha pratik olduğunu doğrudan değiştirir.",
      },
    ],
  },
  antalya: {
    description:
      "Antalya escort ilanları Lara, Konyaaltı, Muratpaşa, Kepez ve Alanya ayrımıyla listelenir. Sezon döneminde ilan sayısı ve güncellenme sıklığı artar.",
    sections: [
      {
        heading: "Sahil hattı ile merkez ayrı çalışır",
        body: "Antalya'da Konyaaltı batı sahilini, Lara ise doğu sahilini tarif eder ve ikisi arasında şehir merkezi üzerinden yaklaşık yarım saatlik yol vardır. Muratpaşa merkezi, Kepez ise merkezin kuzeyindeki geniş konut alanını kapsar. Kaleiçi çevresi yürünebilir ölçüdedir ama araçla ulaşımı sınırlıdır.",
      },
      {
        heading: "Alanya ve Manavgat ayrı birer merkezdir",
        body: "Alanya, Antalya merkeze iki saatlik mesafededir ve kendi içinde bağımsız bir turizm merkezi gibi çalışır. Manavgat ile Side de benzer biçimde ayrı değerlendirilir. Listede Alanya etiketli bir ilanı merkez ilanı gibi düşünmek, pratikte ciddi bir yol hesabı hatasına yol açar. Sezon nisanda başlar ve ekim sonuna kadar sürer.",
      },
      {
        heading: "Havalimanı Lara tarafındadır",
        body: "Antalya Havalimanı şehrin doğusunda, Lara yönündedir ve merkeze yaklaşık on beş dakika uzaklıktadır. Konyaaltı tarafına geçiş ise yarım saati bulur. Alanya'ya gelenler için Gazipaşa Havalimanı daha pratik bir seçenektir. Otogar şehrin kuzeyindedir ve tramvay hattıyla merkeze bağlanır.",
      },
    ],
  },
  artvin: {
    description:
      "Artvin escort ilanları merkez, Hopa ve Arhavi ayrımıyla listelenir. Dağlık arazide mesafe kilometreden çok yol süresiyle ölçülür, ilçe etiketi önemlidir.",
    sections: [
      {
        heading: "Merkez dağ yamacında, sahil aşağıdadır",
        body: "Artvin'in merkezi deniz seviyesinden yüksekte, dik bir yamaca kurulmuştur. Hopa ve Arhavi ise sahil şeridindedir. Merkez ile Hopa arasında yaklaşık yetmiş kilometre vardır ama virajlı yol yüzünden bu mesafe bir buçuk saati bulur. Listede ilçe bilgisi, bu ilde diğer illerden daha belirleyicidir.",
      },
      {
        heading: "Sınır kapısı Hopa'yı hareketli tutar",
        body: "Sarp Sınır Kapısı'nın yakınlığı Hopa'yı yıl boyu geçiş trafiğine açık tutar ve ilçedeki otel kapasitesi merkeze göre daha yüksektir. Yağışın sık olduğu sonbahar aylarında sahil yolu zaman zaman yavaşlar. İlan sayısı Artvin genelinde sınırlıdır, bu yüzden sayfanın güncel halini takip etmek gerekir.",
      },
      {
        heading: "En yakın havalimanı Hopa tarafında",
        body: "Artvin'in kendi havalimanı yoktur; bölgeye hava yoluyla giriş Rize-Artvin Havalimanı ya da Trabzon üzerinden yapılır. Rize-Artvin Havalimanı Hopa'ya yaklaşık kırk dakika, Artvin merkeze ise iki saat uzaklıktadır. Bu yüzden merkez hedefleniyorsa yol süresini havalimanından itibaren hesaplamak gerekir.",
      },
    ],
  },
  aydin: {
    description:
      "Aydın escort ilanları Efeler, Kuşadası, Didim, Söke ve Nazilli ayrımıyla listelenir. Sahil ilçeleri ile merkez arasındaki yoğunluk farkı sezona göre değişir.",
    sections: [
      {
        heading: "Merkez ile sahil arasında bir saatlik yol var",
        body: "Aydın'ın merkezi Efeler, iç kesimde ve Büyük Menderes Ovası'nın kenarındadır. Kuşadası ile Didim ise sahildedir ve merkeze yaklaşık bir saat uzaklıktadır. Söke ikisinin arasında kalan geçiş noktasıdır. Bu yüzden Aydın listesinde merkez ilanı ile sahil ilanını ayrı düşünmek gerekir.",
      },
      {
        heading: "Kuşadası ve Didim yaz boyunca ayrı tempodadır",
        body: "Kuşadası kruvaziyer limanı ve otel kapasitesiyle haziran ile eylül arasında belirgin biçimde kalabalıklaşır; Didim de benzer bir sezon yaşar. Kışın ise aynı ilçeler büyük ölçüde sakinleşir ve ilan sayısı merkeze kayar. Nazilli ise sezondan bağımsız, kendi iç düzeni olan bir ilçedir.",
      },
      {
        heading: "İzmir havalimanı ortak giriş noktası",
        body: "Aydın'a hava yoluyla gelenler genellikle İzmir Adnan Menderes Havalimanı'nı kullanır; merkeze yaklaşık bir buçuk saat uzaklıktadır. Bodrum Havalimanı ise Didim tarafına daha yakındır. Şehirden geçen banliyö tren hattı Aydın'ı Söke, Nazilli ve İzmir'e düzenli seferlerle bağlar.",
      },
    ],
  },
  balikesir: {
    description:
      "Balıkesir escort ilanları Altıeylül, Karesi, Edremit, Bandırma ve Ayvalık ayrımıyla listelenir. İl geniş olduğu için ilçe etiketi listede öne alınır.",
    sections: [
      {
        heading: "Üç ayrı merkez gibi çalışan bir il",
        body: "Balıkesir'de şehir merkezi Altıeylül ve Karesi ilçelerinden oluşur. Bandırma kuzeyde, Marmara kıyısında; Edremit ile Ayvalık ise batıda, Ege kıyısındadır. Merkez ile Ayvalık arasında yaklaşık iki saatlik yol vardır. Bu yüzden il adına bakıp mesafeyi küçük sanmak yanıltıcı olur.",
      },
      {
        heading: "Bandırma feribot saatlerine göre hareketlenir",
        body: "Bandırma, İstanbul'a deniz otobüsü seferleriyle bağlanır ve ilçenin günlük temposu bu sefer saatlerine göre şekillenir. Ayvalık ve Edremit körfezi ise yaz aylarında tatil yoğunluğu yaşar. Merkez ise üniversite ve sanayi nedeniyle yıl boyu dengeli bir hareketlilik gösterir.",
      },
      {
        heading: "Üç ayrı giriş noktası var",
        body: "Balıkesir'e giriş, hedeflenen bölgeye göre değişir. Merkez için Koca Seyit Havalimanı Edremit tarafındadır. Bandırma'ya İstanbul'dan deniz otobüsüyle iki saatte ulaşılır. Ayvalık ise Midilli feribot hattına bağlıdır. Bu üç kapı birbirinden uzak olduğu için önce hedef ilçeyi belirlemek gerekir.",
      },
    ],
  },
  bilecik: {
    description:
      "Bilecik escort ilanları merkez ve Bozüyük ayrımıyla listelenir. İki yerleşim otoyolla bağlı olduğu için aralarındaki geçiş yarım saatte tamamlanır.",
    sections: [
      {
        heading: "Bozüyük merkezden daha hareketlidir",
        body: "Bilecik'te il merkezi küçük ve sakin bir yerleşimdir. Buna karşılık Bozüyük, Ankara-İstanbul yolu üzerinde olduğu için sanayi ve geçiş trafiği bakımından merkezden daha canlıdır. İki yerleşim arasında yaklaşık kırk kilometre ve yarım saatlik bir yol vardır.",
      },
      {
        heading: "Çevre illere yakınlık belirleyicidir",
        body: "Bilecik; Bursa, Eskişehir ve Sakarya'ya yakın bir konumdadır ve üç ile de bir ile bir buçuk saat arasında ulaşılır. Bu yakınlık, ildeki ilan sayısının sınırlı kalmasının başlıca sebebidir. Güncel ilan bulunamadığında komşu il sayfalarına bakmak daha pratik olur.",
      },
      {
        heading: "Hızlı tren hattı üzerinde",
        body: "Bilecik, Ankara-İstanbul yüksek hızlı tren hattı üzerindedir ve Bozüyük ile Bilecik duraklarından iki büyük şehre doğrudan bağlanır. Havalimanı yoktur; en yakın seçenek Eskişehir ve Bursa yönündedir. Otoyol bağlantısı sayesinde günübirlik gidiş gelişler yaygındır.",
      },
    ],
  },
  bingol: {
    description:
      "Bingöl escort ilanları merkez ağırlıklı olarak listelenir. Şehir kompakt olduğu için ilanlarda semt farkı yerine iletişim bilgisi öne çıkar.",
    sections: [
      {
        heading: "Şehir merkezi tek parça halindedir",
        body: "Bingöl'de yerleşim büyük ölçüde merkezde toplanmıştır ve şehir baştan sona kısa sürede geçilir. Üniversite kampüsü merkeze yakın durur ve şehrin genç nüfusunu bir arada tutar. Semt ayrımı diğer illerdeki kadar belirleyici değildir; bu yüzden listede ilanın güncelliği daha önemlidir.",
      },
      {
        heading: "Ulaşım karayoluna bağlıdır",
        body: "Bingöl'e giriş çıkış ağırlıklı olarak Elazığ ve Muş yönündeki karayollarıyla olur. Kış aylarında bu yollar hava koşullarına göre yavaşlar. İldeki ilan sayısı sınırlı olduğundan sayfanın güncel halini düzenli kontrol etmek, aramayı kolaylaştıran tek yöntemdir.",
      },
      {
        heading: "Havalimanı şehre bitişiktir",
        body: "Bingöl Havalimanı merkeze çok yakındır ama sefer sayısı sınırlıdır ve kış koşullarında aksayabilir. Bu nedenle şehre giriş çıkış daha çok karayoluyla, Elazığ üzerinden yapılır. Elazığ'a yaklaşık iki, Muş'a ise bir buçuk saatte ulaşılır. Otogar merkezdedir.",
      },
    ],
  },
  bitlis: {
    description:
      "Bitlis escort ilanları merkez ve Tatvan ayrımıyla listelenir. Göl kıyısındaki Tatvan ile dar vadideki merkez arasında yaklaşık yarım saatlik yol vardır.",
    sections: [
      {
        heading: "Merkez vadide, Tatvan göl kıyısında",
        body: "Bitlis merkezi dar bir vadiye kurulmuştur ve şehir tek bir cadde boyunca uzanır. Tatvan ise Van Gölü kıyısında, daha düz bir arazide yer alır ve ilçe merkezden daha geniş bir yerleşimdir. İki nokta arasında yaklaşık yirmi beş kilometre vardır. Listedeki ilçe etiketi bu ilde doğrudan ulaşım planını değiştirir.",
      },
      {
        heading: "Göl ulaşımı ve tren feribotu",
        body: "Tatvan, Van Gölü'nün batı ucundadır ve karşı kıyıya feribot bağlantısı buradan yapılır. Bu durum ilçeyi bölgedeki geçişlerde bir durak noktası haline getirir. Kış aylarında Bitlis yoğun kar alır ve şehirler arası yollar aksayabilir; ilan güncellemeleri de bu dönemde seyrekleşir.",
      },
      {
        heading: "Tatvan üzerinden ulaşım",
        body: "Bitlis'in kendi havalimanı yoktur; bölgeye hava yoluyla giriş Van ya da Muş havalimanlarından yapılır. Van'a Tatvan üzerinden yaklaşık iki saatte ulaşılır. Tatvan ayrıca demiryolu hattının göl kıyısındaki son durağıdır ve karşı kıyıya feribot bağlantısı buradan kurulur.",
      },
    ],
  },
  bolu: {
    description:
      "Bolu escort ilanları merkez ağırlıklı listelenir. Abant ve Kartalkaya yönündeki otellerle şehir merkezi arasındaki mesafe ilan notlarında belirtilir.",
    sections: [
      {
        heading: "Merkez ile dağ otelleri ayrı noktalardır",
        body: "Bolu'da şehir merkezi küçük ve derli toplu bir alandır. Abant yaklaşık kırk dakika, Kartalkaya ise hava koşullarına göre bir saate yakın uzaklıktadır. İlanlarda merkez mi yoksa dağ bölgesi mi tarif edildiğini ayırt etmek gerekir, çünkü iki nokta arasında dönüş planı tamamen değişir.",
      },
      {
        heading: "Otoyol şehri hafta sonu kalabalıklaştırır",
        body: "Bolu, İstanbul ile Ankara arasındaki otoyolun tam ortasındadır ve her iki şehirden de yaklaşık üç saatte ulaşılır. Bu konum, özellikle hafta sonları ve kayak sezonunda şehirdeki otel doluluğunu belirgin biçimde artırır. İlan sayısı da aynı dönemlerde yükselir.",
      },
      {
        heading: "Otoyol dışında bağlantı sınırlı",
        body: "Bolu'ya ulaşım neredeyse tamamen D-100 ve TEM otoyolu üzerinden sağlanır; havalimanı ve yolcu treni yoktur. İstanbul ve Ankara'dan düzenli otobüs seferleri vardır ve her iki şehirden de yaklaşık üç saatte ulaşılır. Otogar merkeze yakındır, dağ otellerine geçiş ise özel araçla yapılır.",
      },
    ],
  },
  burdur: {
    description:
      "Burdur escort ilanları merkez ağırlıklı listelenir. Göl kenarındaki şehir küçük olduğundan semt farkı yerine ilanın güncelliği öne çıkar, yollar kısadır.",
    sections: [
      {
        heading: "Göl kenarında kompakt bir merkez",
        body: "Burdur, aynı adı taşıyan gölün kıyısında kurulu küçük bir şehirdir. Merkez baştan sona kısa sürede yürünebilir ve konut alanları çarşıya yakındır. Semt ayrımının pratik bir karşılığı olmadığı için listede fotoğraf ve iletişim bilgisi daha belirleyicidir.",
      },
      {
        heading: "Isparta ve Antalya yakınlığı",
        body: "Burdur, Isparta'ya yarım saat, Antalya'ya ise yaklaşık iki saat mesafededir. Bu yakınlık şehirdeki hareketliliğin bir bölümünü komşu illere kaydırır ve ildeki ilan sayısını sınırlı tutar. Güncel bir ilan bulunamadığında Isparta sayfasına bakmak daha hızlı sonuç verir.",
      },
      {
        heading: "Isparta ile ortak havalimanı",
        body: "Burdur'a hava yoluyla giriş Isparta Süleyman Demirel Havalimanı üzerinden yapılır; merkeze yaklaşık bir saat uzaklıktadır. Antalya Havalimanı ise iki saat mesafededir ve sefer çeşitliliği daha fazladır. Şehirden geçen tren hattı Isparta ve İzmir yönüne bağlanır.",
      },
    ],
  },
  bursa: {
    description:
      "Bursa escort ilanları Nilüfer, Osmangazi, Yıldırım, Mudanya ve Gemlik ayrımıyla listelenir. Her ilanda ilçe etiketi ve güncel fotoğraf birlikte durur.",
    sections: [
      {
        heading: "Nilüfer, Osmangazi ve Yıldırım farklı tempolardadır",
        body: "Bursa'da şehir doğudan batıya uzanan uzun bir hat üzerine kuruludur. Yıldırım doğuda eski yerleşimi, Osmangazi ortada tarihi merkezi, Nilüfer ise batıda yeni konut alanlarını kapsar. Uçtan uca yolculuk trafiğe göre kırk dakikayı bulur, bu yüzden ilçe etiketi listede ilk bakılacak bilgidir.",
      },
      {
        heading: "Mudanya ve Gemlik sahil tarafında kalır",
        body: "Mudanya, İstanbul'dan gelen deniz otobüsü seferlerinin yanaştığı ilçedir ve merkeze yaklaşık yarım saat uzaklıktadır. Gemlik ise körfezin doğusunda, sanayi ağırlıklı bir ilçedir. Uludağ yönündeki oteller ise kış sezonunda ayrı bir yoğunluk oluşturur ve merkeze çıkış teleferik ya da dağ yoluyla sağlanır.",
      },
      {
        heading: "Deniz otobüsü en hızlı yol",
        body: "İstanbul'dan Bursa'ya en hızlı giriş, Mudanya'ya yanaşan deniz otobüsüyle olur ve yolculuk yaklaşık iki saat sürer. Yenişehir Havalimanı merkeze uzak ve sefer sayısı sınırlıdır. Osmangazi Köprüsü üzerinden karayolu bağlantısı da iki buçuk saate inmiştir. Metro hattı merkez ile Nilüfer arasını bağlar.",
      },
    ],
  },
  canakkale: {
    description:
      "Çanakkale escort ilanları merkez, Kepez ve Biga ayrımıyla listelenir. Boğazın iki yakası arasındaki geçiş süresi ilan planını doğrudan etkiler.",
    sections: [
      {
        heading: "Boğazın iki yakası ayrı hesaplanır",
        body: "Çanakkale'de şehir merkezi Anadolu yakasındadır; Eceabat ve Gelibolu ise karşı kıyıda kalır. 1915 Çanakkale Köprüsü açıldıktan sonra iki yaka arasındaki geçiş kısalmış olsa da feribot hâlâ yaygın kullanılır ve sefer saatleri akşam seyrekleşir. Listede karşı yaka etiketli bir ilan varsa geçiş süresini hesaba katmak gerekir.",
      },
      {
        heading: "Üniversite şehrin temposunu belirler",
        body: "Çanakkale Onsekiz Mart Üniversitesi şehrin nüfusunu dönem içinde belirgin biçimde artırır. Eylül ile haziran arasında kordon boyu ve merkez çarşı canlıdır, yaz aylarında ise hareketlilik Assos ve Bozcaada yönüne kayar. Kepez merkeze bitişik bir yerleşimdir, Biga ise yaklaşık bir saat uzaklıktadır.",
      },
      {
        heading: "Havalimanı merkeze yakın",
        body: "Çanakkale Havalimanı şehir merkezine birkaç kilometre uzaklıktadır ve İstanbul'a düzenli seferleri vardır. Karayoluyla gelenler için 1915 Çanakkale Köprüsü, İstanbul'u yaklaşık üç saate indirmiştir. Bozcaada ve Gökçeada'ya geçiş ise Geyikli ve Kabatepe iskelelerinden feribotla yapılır.",
      },
    ],
  },
  cankiri: {
    description:
      "Çankırı escort ilanları merkez ağırlıklı listelenir. Şehir küçük ve yürünebilir olduğu için ilanlarda güncellik semt bilgisinden önce gelir.",
    sections: [
      {
        heading: "Merkez kısa mesafelerden oluşur",
        body: "Çankırı'da yerleşim merkezde toplanmıştır ve çarşı ile konut alanları arasındaki mesafe yürüme süresindedir. Üniversite kampüsü şehrin kenarında kalır. Semt ayrımı pratikte belirleyici olmadığından listede ilanın ne zaman güncellendiğine bakmak daha işe yarar.",
      },
      {
        heading: "Ankara'ya yakınlık ilan sayısını etkiler",
        body: "Çankırı, Ankara'ya yaklaşık bir buçuk saat mesafededir ve bu yakınlık şehirdeki hareketliliğin bir kısmını başkente taşır. İldeki ilan sayısı bu nedenle sınırlı kalır. Tuz mağarası çevresindeki ziyaretçi akışı ise mevsimlik ve kısa sürelidir.",
      },
      {
        heading: "Ankara üzerinden giriş",
        body: "Çankırı'nın havalimanı yoktur; hava yoluyla gelenler Ankara Esenboğa'yı kullanır ve oradan karayoluyla yaklaşık bir buçuk saatte ulaşır. Şehirden geçen tren hattı Ankara ile Karabük yönüne bağlanır. Otogar merkeze yakındır ve ilçe seferleri buradan kalkar.",
      },
    ],
  },
  corum: {
    description:
      "Çorum escort ilanları merkez ağırlıklı listelenir. Şehirde çarşı ile yeni konut alanları arasındaki mesafe kısa olduğu için ulaşım basittir.",
    sections: [
      {
        heading: "Çarşı ile yeni mahalleler yan yanadır",
        body: "Çorum'da merkez, saat kulesi çevresindeki çarşı ile onun uzantısındaki yeni konut alanlarından oluşur. İki bölge arasında araçla on dakikalık bir yol vardır. Şehrin genel düzeni sade olduğu için ilan tarifleri genellikle cadde adıyla verilir ve bulunması kolaydır.",
      },
      {
        heading: "Sanayi ve geçiş trafiği",
        body: "Çorum, Samsun ile Ankara arasındaki güzergah üzerindedir ve makine sanayisiyle yıl boyu dengeli bir hareketlilik gösterir. Hafta içi ile hafta sonu arasındaki fark bu nedenle diğer İç Anadolu illerine göre daha azdır. Alacahöyük ve Hattuşa yönündeki ziyaretçi akışı ise mevsimliktir.",
      },
      {
        heading: "Merzifon ve Samsun bağlantısı",
        body: "Çorum'a hava yoluyla giriş genellikle Merzifon Havalimanı üzerinden yapılır; merkeze yaklaşık bir buçuk saat uzaklıktadır. Samsun Havalimanı ise iki buçuk saat mesafededir. Ankara'ya karayoluyla yaklaşık üç saatte ulaşılır. Otogar çevre yolu üzerindedir.",
      },
    ],
  },
  denizli: {
    description:
      "Denizli escort ilanları Merkezefendi, Pamukkale ve Çivril ayrımıyla listelenir. Travertenler bölgesi ile şehir merkezi arasındaki mesafe ayrı değerlendirilir.",
    sections: [
      {
        heading: "Merkez iki ilçeye bölünmüştür",
        body: "Denizli'de şehir merkezi Merkezefendi ve Pamukkale ilçelerinin birleştiği alandır; ikisi arasında belirgin bir sınır hissedilmez. Çarşı, Bayramyeri çevresinde toplanır. Asıl mesafe, merkez ile travertenlerin bulunduğu Pamukkale beldesi arasındadır ve bu yol yaklaşık yarım saat sürer.",
      },
      {
        heading: "Tekstil şehri yıl boyu hareketlidir",
        body: "Denizli'nin tekstil ve ev tekstili üretimi şehre düzenli bir iş trafiği getirir; otel doluluğu sezondan çok fuar ve iş takvimine bağlıdır. Pamukkale'ye gelen turist akışı ise ilkbahar ve sonbaharda yoğunlaşır. Çivril merkeze yaklaşık bir saat uzaklıktadır ve ayrı değerlendirilir.",
      },
      {
        heading: "Çardak Havalimanı merkeze uzak",
        body: "Denizli Çardak Havalimanı merkeze yaklaşık altmış kilometre uzaklıktadır ve araçla bir saat sürer; uçuş saatlerine bağlı servisler çalışır. Şehrin tren garı ise merkezdedir ve İzmir ile Isparta yönüne bağlanır. Pamukkale'ye gelen ziyaretçiler genellikle bu havalimanını kullanır.",
      },
    ],
  },
  diyarbakir: {
    description:
      "Diyarbakır escort ilanları Kayapınar, Bağlar, Yenişehir ve Sur ayrımıyla listelenir. Her ilçenin kendi düzeni olduğu için semt etiketi öne çıkarılır.",
    sections: [
      {
        heading: "Dört ilçe dört ayrı karakter taşır",
        body: "Diyarbakır'da Sur, surlarla çevrili tarihi merkezdir. Yenişehir idari yapıların ve otellerin toplandığı alandır. Kayapınar yeni konut bölgesidir ve son yılların en hızlı büyüyen tarafıdır. Bağlar ise yoğun nüfuslu bir yerleşimdir. İlçeler arası geçiş araçla on beş ile yirmi beş dakika arasında sürer.",
      },
      {
        heading: "Yaz sıcağı günlük düzeni kaydırır",
        body: "Diyarbakır'da yaz ayları uzun ve çok sıcak geçer; şehrin günlük temposu bu dönemde akşam saatlerine kayar ve gece hayatı geç başlar. Kışın ise düzen gündüze döner. İlanların güncellenme saatleri de mevsime göre bu ritmi takip eder.",
      },
      {
        heading: "Havalimanı şehrin içindedir",
        body: "Diyarbakır Havalimanı merkeze yaklaşık beş kilometre uzaklıktadır ve araçla on beş dakikada ulaşılır; bu yakınlık şehri bölgedeki en erişilebilir giriş noktalarından biri yapar. Otogar ise çevre yolu üzerindedir. Mardin'e yaklaşık bir buçuk, Batman'a bir saatte ulaşılır.",
      },
    ],
  },
  edirne: {
    description:
      "Edirne escort ilanları merkez ve Keşan ayrımıyla listelenir. Selimiye çevresindeki merkez yürünebilir, Keşan ise ayrı bir ilçe olarak değerlendirilir.",
    sections: [
      {
        heading: "Merkez Selimiye çevresinde toplanır",
        body: "Edirne'de şehir merkezi Selimiye Camii ve çevresindeki çarşı hattında yoğunlaşır. Saraçlar Caddesi boyunca uzanan bu alan baştan sona yürünebilir. Üniversite kampüsü ve yeni konut alanları merkezin dışında kalır ama araçla on dakika uzaklıktadır.",
      },
      {
        heading: "Sınır kapıları geçiş trafiği yaratır",
        body: "Kapıkule ve İpsala sınır kapıları Edirne'yi yıl boyu uluslararası geçiş trafiğine açık tutar. Bu durum şehirdeki otel kapasitesini nüfusuna göre yüksek tutar. Keşan ise İpsala yoluna yakın, merkeze yaklaşık bir saat uzaklıkta ayrı bir ilçedir. Kırkpınar haftasında şehir belirgin biçimde kalabalıklaşır.",
      },
      {
        heading: "Tren ve otobüs ağırlıklı",
        body: "Edirne'nin havalimanı yoktur; İstanbul'dan gelenler karayolunu kullanır ve yolculuk yaklaşık üç saat sürer. Halkalı'dan kalkan tren seferleri de şehre bağlantı sağlar. Otogar merkezin dışında, çevre yolu üzerindedir ve şehir içi servislerle merkeze bağlanır.",
      },
    ],
  },
  elazig: {
    description:
      "Elazığ escort ilanları merkez ağırlıklı listelenir. Üniversite çevresi ile çarşı arasındaki mesafe kısa olduğundan ulaşım planı basit kalır, tarif nettir.",
    sections: [
      {
        heading: "Çarşı ile üniversite arasında kısa yol var",
        body: "Elazığ'da merkez, Gazi Caddesi çevresindeki çarşı hattından oluşur. Fırat Üniversitesi kampüsü şehrin kenarında, merkeze araçla on beş dakika uzaklıktadır. İkisi arasındaki hat şehrin en hareketli bölgesidir ve ilan tarifleri genellikle bu hattı referans alır.",
      },
      {
        heading: "Hazar Gölü ve çevre bağlantıları",
        body: "Hazar Gölü merkeze yaklaşık yarım saat uzaklıktadır ve yaz aylarında günübirlik hareketliliğin toplandığı yerdir. Elazığ ayrıca Malatya ve Diyarbakır yollarının kesiştiği noktadadır; iki ile de bir buçuk ile iki saat arasında ulaşılır. Bu konum şehri bölgesel bir durak haline getirir.",
      },
      {
        heading: "Havalimanı merkeze on dakika",
        body: "Elazığ Havalimanı şehir merkezine yaklaşık on kilometre uzaklıktadır ve İstanbul ile Ankara'ya düzenli seferleri vardır. Tren hattı da şehirden geçer; Doğu Ekspresi güzergahı üzerindedir. Malatya'ya yaklaşık bir buçuk, Diyarbakır'a iki saatte ulaşılır.",
      },
    ],
  },
  erzincan: {
    description:
      "Erzincan escort ilanları merkez ağırlıklı listelenir. Düz ovaya kurulu şehirde caddeler paralel uzanır, mesafeler kısadır ve adres tarifi kolaydır.",
    sections: [
      {
        heading: "Ova üzerinde düz ve açık bir merkez",
        body: "Erzincan, geniş bir ovanın ortasında kurulu olduğu için şehir düzeni ızgara biçimindedir ve yönünü bulmak kolaydır. Merkez caddeleri birbirine paraleldir, konut alanları çarşıya yakındır. Bu nedenle ilan tarifleri genellikle cadde adıyla verilir ve semt farkı pratikte önemli değildir.",
      },
      {
        heading: "Ergan Dağı ve kış sezonu",
        body: "Ergan Dağı kayak merkezi şehre yaklaşık yirmi dakika uzaklıktadır ve aralık ile mart arasında şehirdeki otel doluluğunu artırır. Erzincan ayrıca Sivas ile Erzurum arasındaki ana güzergah üzerindedir, bu da yıl boyu düzenli bir geçiş trafiği sağlar.",
      },
      {
        heading: "Havalimanı ve demiryolu birlikte",
        body: "Erzincan Havalimanı merkeze birkaç kilometre uzaklıktadır ve İstanbul ile Ankara'ya seferleri vardır. Şehir ayrıca Doğu Ekspresi güzergahı üzerindedir. Erzurum'a yaklaşık iki, Sivas'a ise iki buçuk saatte ulaşılır. Giriş noktalarının hepsi merkeze yakın olduğu için ulaşım planı basittir.",
      },
    ],
  },
  erzurum: {
    description:
      "Erzurum escort ilanları merkez ve Palandöken ayrımıyla listelenir. Kayak sezonunda otel bölgesi ile şehir merkezi arasındaki fark belirginleşir.",
    sections: [
      {
        heading: "Merkez ile Palandöken arasındaki yol",
        body: "Erzurum'da şehir merkezi Cumhuriyet Caddesi ve çevresindeki çarşıdan oluşur. Palandöken'deki oteller ise merkezin güneyinde, araçla yaklaşık yirmi dakika yukarıdadır. Kış aylarında bu yol hava koşullarına göre uzayabilir. İlanlarda merkez mi dağ bölgesi mi tarif edildiğini ayırt etmek gerekir.",
      },
      {
        heading: "Uzun kış ve yüksek rakım",
        body: "Erzurum Türkiye'nin en yüksek rakımlı büyük şehirlerinden biridir ve kış kasımdan nisana kadar sürer. Bu dönemde kayak turizmi şehre düzenli ziyaretçi getirir ve otel doluluğu yükselir. Yaz aylarında ise tempo belirgin biçimde düşer ve ilan sayısı azalır.",
      },
      {
        heading: "Havalimanı ve gar merkeze yakın",
        body: "Erzurum Havalimanı merkeze yaklaşık on kilometre uzaklıktadır ve kış sezonunda sefer sayısı artar. Gar da merkezdedir ve Doğu Ekspresi'nin önemli duraklarındandır. Palandöken'deki otellere geçiş için havalimanından servis ya da taksi kullanılır; yolculuk yarım saat sürer.",
      },
    ],
  },
  eskisehir: {
    description:
      "Eskişehir escort ilanları Tepebaşı ve Odunpazarı ayrımıyla listelenir. Tramvay hattı semtler arası geçişi öngörülebilir kıldığı için planlama kolaydır.",
    sections: [
      {
        heading: "Tramvay hattı şehrin omurgasıdır",
        body: "Eskişehir'de ulaşımın büyük bölümü tramvay hattı üzerinden yürür. Hat, üniversite kampüsünden şehir merkezine ve oradan Odunpazarı yönüne uzanır. Bu yüzden semtler arası geçiş süresi trafikten bağımsız ve tahmin edilebilir kalır. İlan tariflerinde genellikle en yakın tramvay durağı referans alınır.",
      },
      {
        heading: "Öğrenci nüfusu dönemlik yoğunluk yaratır",
        body: "Anadolu ve Osmangazi üniversiteleri şehrin nüfusunu eylül ile haziran arasında belirgin biçimde artırır. Porsuk Çayı kıyısındaki kafeler ve Barlar Sokağı çevresi bu dönemde gece geç saatlere kadar açıktır. Yaz tatilinde ise şehir sakinleşir ve ilan sayısı düşer.",
      },
      {
        heading: "Hızlı tren şehrin kapısıdır",
        body: "Eskişehir'e giriş ağırlıklı olarak yüksek hızlı trenle yapılır; Ankara'ya yaklaşık bir buçuk, İstanbul'a ise üç saatte ulaşılır. Gar merkeze yürüme mesafesindedir ve tramvay hattı buradan geçer. Hasan Polatkan Havalimanı ise ağırlıklı olarak eğitim amaçlı kullanılır.",
      },
    ],
  },
  gaziantep: {
    description:
      "Gaziantep escort ilanları Şehitkamil ve Şahinbey ayrımıyla listelenir. İki ilçe arasındaki mesafe kısadır, ilanlarda cadde tarifi yaygındır.",
    sections: [
      {
        heading: "Şehitkamil yeni, Şahinbey eski taraf",
        body: "Gaziantep'te Şahinbey tarihi merkezi, bakırcılar çarşısını ve eski konut alanlarını kapsar. Şehitkamil ise kuzeydeki yeni yerleşim bölgesidir; otellerin ve alışveriş merkezlerinin çoğu bu taraftadır. İki ilçe arasında araçla yaklaşık yirmi dakikalık bir yol vardır.",
      },
      {
        heading: "Sanayi ve iş trafiği yıl boyu sürer",
        body: "Gaziantep organize sanayi bölgeleriyle Türkiye'nin en yoğun üretim merkezlerinden biridir ve bu durum şehre sezondan bağımsız bir iş trafiği getirir. Otel doluluğu hafta içi genellikle hafta sonundan yüksektir. Mutfak turizmi nedeniyle gelen ziyaretçiler ise ağırlıklı olarak hafta sonlarına denk gelir.",
      },
      {
        heading: "Havalimanı ve otoyol bağlantısı",
        body: "Gaziantep Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır ve bölgedeki en yoğun sefer trafiğine sahip noktalardan biridir. Otogar ise şehrin kuzeyindedir. Şanlıurfa'ya otoyoldan yaklaşık bir buçuk, Adana'ya iki, Kahramanmaraş'a bir buçuk saatte ulaşılır.",
      },
    ],
  },
  giresun: {
    description:
      "Giresun escort ilanları merkez ve Bulancak ayrımıyla listelenir. Sahil şeridi boyunca uzanan yerleşimde mesafeler kilometreyle hesaplanır, ilçe önemlidir.",
    sections: [
      {
        heading: "Şehir sahil boyunca uzanır",
        body: "Giresun'da yerleşim denizle dağ arasındaki dar şeride sıkışmıştır ve sahil yolu boyunca doğu-batı yönünde uzanır. Merkez, liman ve çarşı çevresinde toplanır. Bulancak batıda, araçla yaklaşık yirmi dakika uzaklıktadır ve kendi çarşısı vardır.",
      },
      {
        heading: "Fındık sezonu temposu değiştirir",
        body: "Ağustos ve eylül aylarındaki fındık hasadı Giresun'a bölge dışından yoğun bir işgücü akışı getirir ve şehirdeki hareketlilik bu dönemde belirgin biçimde artar. Kışın ise tempo düşer. Yağışın sık olduğu sonbaharda sahil yolu zaman zaman yavaşlar.",
      },
      {
        heading: "Ordu-Giresun Havalimanı ortaktır",
        body: "Bölgeye hava yoluyla giriş, iki ilin ortak kullandığı Ordu-Giresun Havalimanı'ndan yapılır; Giresun merkeze yaklaşık kırk dakika uzaklıktadır. Deniz üzerine kurulu bu havalimanı sahil yolu üzerindedir. Trabzon Havalimanı ise doğu yönünde yaklaşık iki saat mesafededir.",
      },
    ],
  },
  gumushane: {
    description:
      "Gümüşhane escort ilanları merkez ağırlıklı listelenir. Dağ arasındaki vadiye kurulu şehirde ulaşım tek ana yol üzerinden yürür, adres tarifi kolaydır.",
    sections: [
      {
        heading: "Vadiye kurulu dar bir merkez",
        body: "Gümüşhane merkezi Harşit Vadisi boyunca uzanan dar bir yerleşimdir. Şehir tek bir ana cadde etrafında kurulduğu için adres tarifi kolaydır ve semt ayrımı pratikte bir anlam taşımaz. Üniversite kampüsü merkeze yakın durur.",
      },
      {
        heading: "Trabzon yolu üzerinde bir durak",
        body: "Gümüşhane, Trabzon ile Erzurum arasındaki ana güzergah üzerindedir ve iki şehre de yaklaşık iki saatte ulaşılır. Zigana geçidi kış aylarında hava koşullarına göre yavaşlayabilir. İldeki ilan sayısı sınırlıdır, bu yüzden sayfanın güncel halini takip etmek gerekir.",
      },
      {
        heading: "Trabzon üzerinden giriş",
        body: "Gümüşhane'nin havalimanı yoktur; hava yoluyla gelenler Trabzon'u kullanır ve Zigana üzerinden yaklaşık iki saatte şehre ulaşır. Kış aylarında bu geçit hava koşullarına göre yavaşlar. Erzurum yönünden geliş de benzer sürededir. Otogar merkeze yakındır.",
      },
    ],
  },
  hakkari: {
    description:
      "Hakkari escort ilanları merkez ve Yüksekova ayrımıyla listelenir. Dağlık arazi nedeniyle iki yerleşim arasındaki yol bir buçuk saati bulur, plan gerekir.",
    sections: [
      {
        heading: "Yüksekova merkezden büyüktür",
        body: "Hakkari'de il merkezi dik bir yamaca kurulu, sınırlı alana sahip bir yerleşimdir. Yüksekova ise ovada kurulu ve nüfus bakımından merkezden daha büyük bir ilçedir. İki nokta arasında yaklaşık yetmiş kilometre vardır ve dağ yolu nedeniyle bu mesafe bir buçuk saati bulur.",
      },
      {
        heading: "Kış koşulları ulaşımı belirler",
        body: "Hakkari'de kış uzun sürer ve yüksek geçitler kar nedeniyle zaman zaman kapanır. Bu dönemde şehirler arası geçişler aksar, ilan güncellemeleri seyrekleşir. Yaz aylarında ise Yüksekova üzerinden İran sınırına uzanan hatta hareketlilik artar.",
      },
      {
        heading: "Yüksekova'daki havalimanı",
        body: "Hakkari'ye hava yoluyla giriş Yüksekova'daki Selahaddin Eyyubi Havalimanı üzerinden yapılır; il merkezine yaklaşık bir buçuk saat uzaklıktadır. Van Havalimanı ise üç saatlik alternatif bir giriş noktasıdır. Kış aylarında yüksek geçitler nedeniyle karayolu süreleri uzar.",
      },
    ],
  },
  hatay: {
    description:
      "Hatay escort ilanları Antakya, İskenderun ve Defne ayrımıyla listelenir. İki ana merkez arasında yaklaşık bir saatlik yol var, ilçe etiketi önemlidir.",
    sections: [
      {
        heading: "Antakya ve İskenderun iki ayrı merkez",
        body: "Hatay'da il merkezi Antakya'dır; Asi Nehri kıyısında ve dağ eteğinde kuruludur. İskenderun ise kuzeyde, körfez kıyısındaki liman şehridir ve kendi içinde bağımsız bir merkez gibi çalışır. İki şehir arasında yaklaşık altmış kilometre ve bir saatlik yol vardır.",
      },
      {
        heading: "Deprem sonrası yerleşim değişti",
        body: "2023 depreminin ardından Antakya'da konut düzeni büyük ölçüde değişti ve yerleşimin bir bölümü çevre ilçelere ile yeni alanlara kaydı. Bu nedenle eski semt tarifleri her zaman güncel karşılık bulmayabilir. İlanlarda verilen konum bilgisini doğrudan teyit etmek bu ilde özellikle önemlidir.",
      },
      {
        heading: "Havalimanı ve çevre il bağlantıları",
        body: "Hatay Havalimanı Antakya ile İskenderun arasındaki hat üzerindedir ve merkeze yaklaşık yirmi kilometre uzaklıktadır. Depremin ardından sefer düzeni bir süre Adana üzerinden yürümüştür. Adana'ya yaklaşık iki buçuk, Gaziantep'e üç saatte ulaşılır.",
      },
    ],
  },
  isparta: {
    description:
      "Isparta escort ilanları merkez ağırlıklı listelenir. Üniversite çevresi ile çarşı arasındaki kısa mesafe ulaşımı basit tutar, tarif cadde adıyla verilir.",
    sections: [
      {
        heading: "Üniversite şehrin merkezini besler",
        body: "Isparta'da Süleyman Demirel Üniversitesi kampüsü şehrin kenarında yer alır ve merkeze araçla yaklaşık on beş dakikadır. Çarşı, Kaymakkapı çevresinde toplanır. Dönem içinde bu iki nokta arasındaki hat şehrin en hareketli bölgesidir, yaz tatilinde ise tempo düşer.",
      },
      {
        heading: "Gül hasadı ve Eğirdir yönü",
        body: "Mayıs ve haziran aylarındaki gül hasadı Isparta çevresine mevsimlik bir hareketlilik getirir. Eğirdir Gölü merkeze yaklaşık yarım saat uzaklıktadır ve yaz aylarında günübirlik ziyaretçi çeker. Antalya'ya iki saatlik mesafe ise şehri bölgesel bir ara durak haline getirir.",
      },
      {
        heading: "Havalimanı merkeze uzak kalır",
        body: "Isparta Süleyman Demirel Havalimanı merkeze yaklaşık otuz kilometre uzaklıktadır ve sefer sayısı sınırlıdır. Çoğu ziyaretçi Antalya Havalimanı'nı kullanıp karayoluyla iki saatte şehre ulaşır. Tren hattı da Isparta'yı Burdur ve İzmir yönüne bağlar.",
      },
    ],
  },
  mersin: {
    description:
      "Mersin escort ilanları Yenişehir, Mezitli, Akdeniz ve Erdemli ayrımıyla listelenir. Sahil boyunca uzanan şehirde ilçe etiketi listede öne alınır.",
    sections: [
      {
        heading: "Şehir sahil boyunca batıya uzanır",
        body: "Mersin'de Akdeniz ilçesi liman ve eski çarşı çevresini, Yenişehir merkez konut alanlarını, Mezitli ise batıdaki yeni yerleşimi kapsar. Üç ilçe sahil yolu üzerinde arka arkaya dizilir ve uçtan uca yolculuk yaklaşık yarım saat sürer. Erdemli ise daha batıda, ayrı bir ilçedir.",
      },
      {
        heading: "Liman ve yazlık nüfus",
        body: "Mersin Limanı şehre yıl boyu düzenli bir iş trafiği getirir. Buna ek olarak Mezitli'den Silifke'ye uzanan sahil şeridindeki yazlık siteler haziran ile eylül arasında nüfusu belirgin biçimde artırır. Bu dönemde ilanlar da sahil ilçelerine kayar.",
      },
      {
        heading: "Adana havalimanı ve banliyö hattı",
        body: "Mersin'e hava yoluyla giriş Adana Şakirpaşa üzerinden yapılır; merkeze yaklaşık bir saat uzaklıktadır. Çukurova Havalimanı devreye girdikçe bu süre değişmektedir. İki şehir arasındaki banliyö tren hattı ise günün büyük bölümünde düzenli sefer yapar ve trafikten etkilenmez.",
      },
    ],
  },
  istanbul: {
    description:
      "İstanbul escort ilanları Şişli, Kadıköy, Beşiktaş, Ataşehir, Bakırköy ve Maltepe ayrımıyla listelenir. İlanlarda semt etiketi ilk sırada gösterilir.",
    sections: [
      {
        heading: "Yaka farkı her şeyden önce gelir",
        body: "İstanbul'da Avrupa ile Anadolu yakası arasındaki geçiş, trafiğe bağlı olarak kırk beş dakika ile bir buçuk saat arasında değişir. Bu yüzden listede önce yaka, sonra semt etiketine bakmak gerekir. Şişli, Beşiktaş ve Bakırköy Avrupa yakasında; Kadıköy, Ataşehir ve Maltepe Anadolu yakasındadır.",
      },
      {
        heading: "Metro ve Marmaray planı değiştirir",
        body: "Marmaray, Söğütlüçeşme ile Yenikapı arasını trafikten bağımsız biçimde yirmi dakikaya indirir; M4 ve M2 hatları da yaka içi geçişleri hızlandırır. Araçla bir saat süren bir yol toplu taşımayla yarıya inebilir. İlanda verilen semti en yakın metro durağına göre düşünmek, buluşma saatini tutturmanın en güvenilir yoludur.",
      },
      {
        heading: "İki havalimanı iki ayrı yakadadır",
        body: "İstanbul Havalimanı Avrupa yakasının kuzeybatısındadır ve merkeze metroyla bağlanır. Sabiha Gökçen ise Anadolu yakasının doğusundadır. İki havalimanı arasındaki mesafe iki saati bulabilir, bu yüzden hangi yakaya inildiği planı doğrudan belirler. Otogarlar Esenler ve Harem'dedir.",
      },
    ],
  },
  izmir: {
    description:
      "İzmir escort ilanları Konak, Bornova, Karşıyaka, Alsancak, Çeşme ve Buca ayrımıyla listelenir. Körfezin iki yakası arasında vapur bağlantısı vardır.",
    sections: [
      {
        heading: "Körfezin iki yakası vapurla bağlanır",
        body: "İzmir'de Konak ve Alsancak güney yakayı, Karşıyaka ve Bostanlı ise kuzey yakayı oluşturur. İki yaka arasında karayoluyla yarım saatlik bir yol varken vapurla geçiş yaklaşık yirmi dakika sürer ve trafikten etkilenmez. Bu yüzden karşı yaka etiketli ilanlarda vapur saatleri işe yarar bir plan aracıdır.",
      },
      {
        heading: "Çeşme ve Urla ayrı değerlendirilir",
        body: "Çeşme, İzmir merkeze otoyoldan yaklaşık bir saat uzaklıktadır ve yaz aylarında kendi içinde bağımsız bir merkez gibi çalışır. Urla ise yarı yolda kalır. Bornova ve Buca üniversite nüfusuyla dönem içinde hareketlenir; Alsancak ise yıl boyu şehrin gece temposunu taşıyan bölgedir.",
      },
      {
        heading: "Havalimanı İZBAN ile merkeze bağlı",
        body: "Adnan Menderes Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır ve İZBAN banliyö hattıyla Alsancak'a doğrudan bağlanır; yolculuk yaklaşık yarım saat sürer. Otogar şehrin doğusundadır. Çeşme ve Urla'ya geçiş ise otoyolla yapılır.",
      },
    ],
  },
  kars: {
    description:
      "Kars escort ilanları merkez ağırlıklı listelenir. Izgara planlı şehirde adres tarifi kolaydır, kış koşulları ise şehir dışı ulaşımı doğrudan belirler.",
    sections: [
      {
        heading: "Taş binalar ve düz cadde düzeni",
        body: "Kars merkezi birbirine dik kesişen geniş caddelerden oluşur ve bu düzen adres bulmayı kolaylaştırır. Tarihi taş binaların bulunduğu hat şehrin ana ekseni sayılır. Konut alanları çarşıya yakındır, bu yüzden merkez içinde mesafe farkı pratikte önemsizdir.",
      },
      {
        heading: "Sarıkamış ve kış turizmi",
        body: "Sarıkamış kayak merkezi Kars merkeze yaklaşık elli kilometre uzaklıktadır ve aralık ile mart arasında şehre düzenli bir ziyaretçi akışı getirir. Doğu Ekspresi de aynı dönemde yolcu sayısını artırır. Yaz aylarında Ani Harabeleri yönündeki ziyaretler öne çıkar ama hareketlilik kışa göre daha düşüktür.",
      },
      {
        heading: "Havalimanı ve Doğu Ekspresi",
        body: "Kars Havalimanı merkeze yaklaşık altı kilometre uzaklıktadır ve kış sezonunda sefer sayısı belirgin biçimde artar. Gar da merkezdedir ve Doğu Ekspresi'nin son durağıdır; bu hat özellikle kış aylarında şehre düzenli yolcu getirir. Sarıkamış'a karayoluyla bir saatte ulaşılır.",
      },
    ],
  },
  kastamonu: {
    description:
      "Kastamonu escort ilanları merkez ve Tosya ayrımıyla listelenir. Merkez kompakt olduğundan listede ilanın güncelliği semt bilgisinden önce gelir.",
    sections: [
      {
        heading: "Merkez nehir boyunca uzanır",
        body: "Kastamonu merkezi, kale eteğinden geçen dere hattı boyunca uzanan derli toplu bir yerleşimdir. Çarşı ile konut alanları arasındaki mesafe yürüme süresindedir. Üniversite kampüsü şehrin dışında kalır ama merkeze araçla on beş dakikadır.",
      },
      {
        heading: "Orman yolları ve mevsim farkı",
        body: "Kastamonu çevresi yoğun ormanlıktır ve ilçelere giden yollar virajlıdır; kilometre olarak kısa görünen mesafeler sürede uzayabilir. Tosya merkeze yaklaşık bir saat uzaklıktadır. Kış aylarında kar nedeniyle ilçe bağlantıları aksayabilir, ilan sayısı da bu dönemde azalır.",
      },
      {
        heading: "Havalimanı sınırlı, karayolu esas",
        body: "Kastamonu Havalimanı merkeze yaklaşık kırk kilometre uzaklıktadır ve sefer sayısı azdır. Şehre giriş çıkışın büyük bölümü karayoluyla yapılır; Ankara'ya yaklaşık üç, İstanbul'a altı saatte ulaşılır. Otogar merkezin dışındadır ve ilçe seferleri buradan kalkar.",
      },
    ],
  },
  kayseri: {
    description:
      "Kayseri escort ilanları Melikgazi, Kocasinan ve Talas ayrımıyla listelenir. Tramvay hattı üç ilçe arasındaki geçişi öngörülebilir ve hızlı kılar.",
    sections: [
      {
        heading: "Üç ilçe tramvay hattıyla bağlıdır",
        body: "Kayseri'de Melikgazi merkez ve kale çevresini, Kocasinan batıdaki yerleşimi, Talas ise doğudaki üniversite ve konut bölgesini kapsar. Tramvay hattı üçünü birbirine bağlar ve uçtan uca yolculuk yaklaşık kırk dakikadır. İlan tariflerinde en yakın durak sık kullanılan bir referanstır.",
      },
      {
        heading: "Erciyes kış sezonunu belirler",
        body: "Erciyes kayak merkezi şehre yaklaşık yarım saat uzaklıktadır ve aralık ile mart arasında otel doluluğunu artırır. Bunun dışında Kayseri'nin sanayi ve ticaret hacmi yıl boyu düzenli bir iş trafiği sağlar; hafta içi hareketlilik hafta sonundan düşük kalmaz.",
      },
      {
        heading: "Havalimanı şehrin içindedir",
        body: "Kayseri Havalimanı merkeze yaklaşık beş kilometre uzaklıktadır ve tramvay hattıyla şehir merkezine doğrudan bağlanır; bu yakınlık Kayseri'yi Kapadokya bölgesine gelenler için de sık kullanılan bir giriş noktası yapar. Nevşehir'e karayoluyla yaklaşık bir saatte ulaşılır.",
      },
    ],
  },
  kirklareli: {
    description:
      "Kırklareli escort ilanları merkez ve Lüleburgaz ayrımıyla listelenir. Lüleburgaz nüfus ve hareketlilik bakımından il merkezinin belirgin biçimde önündedir.",
    sections: [
      {
        heading: "Lüleburgaz merkezden daha canlıdır",
        body: "Kırklareli'nde il merkezi sakin ve küçük bir yerleşimdir. Lüleburgaz ise İstanbul-Edirne hattı üzerinde, sanayi ve ticaretle büyümüş daha kalabalık bir ilçedir. İki yerleşim arasında yaklaşık kırk beş kilometre ve yarım saatlik yol vardır. Listede ilçe etiketi bu nedenle belirleyicidir.",
      },
      {
        heading: "İstanbul yakınlığı akışı yönlendirir",
        body: "Kırklareli, İstanbul'a yaklaşık iki saat mesafededir ve bu yakınlık ildeki hareketliliğin bir bölümünü büyük şehre taşır. Kıyıköy ve Vize yönündeki ziyaretler ise yaz aylarıyla sınırlıdır. İldeki ilan sayısı sınırlı kaldığından sayfanın güncel halini kontrol etmek gerekir.",
      },
      {
        heading: "İstanbul üzerinden giriş",
        body: "Kırklareli'nin havalimanı yoktur; hava yoluyla gelenler İstanbul Havalimanı'nı kullanır ve karayoluyla yaklaşık iki saatte şehre ulaşır. Lüleburgaz, otoyola daha yakın olduğu için bu süre yarım saat kısalır. Edirne'ye ise bir saatte ulaşılır.",
      },
    ],
  },
  kirsehir: {
    description:
      "Kırşehir escort ilanları merkez ağırlıklı listelenir. Termal tesisler ile şehir merkezi arasındaki mesafe ilan notlarında ayrıca belirtilir, yol kısadır.",
    sections: [
      {
        heading: "Merkez küçük ve tek eksenlidir",
        body: "Kırşehir'de yerleşim merkezde toplanmıştır ve şehir ana cadde boyunca uzanır. Üniversite kampüsü merkezin kenarındadır. Semt ayrımı pratikte karşılık bulmadığı için listede ilanın güncellenme tarihine bakmak daha işe yarar.",
      },
      {
        heading: "Terme ve çevre yol bağlantıları",
        body: "Kırşehir'in termal tesisleri merkezin birkaç kilometre dışındadır ve araçla on dakikada ulaşılır. Şehir ayrıca Ankara ile Kayseri arasındaki güzergah üzerindedir; Ankara'ya yaklaşık iki saattir. Bu konum şehri bölgesel bir ara durak haline getirir.",
      },
      {
        heading: "Ankara ve Kayseri arasında",
        body: "Kırşehir'in havalimanı yoktur; hava yoluyla gelenler Ankara Esenboğa ya da Kayseri'yi kullanır. Ankara'ya karayoluyla yaklaşık iki, Kayseri'ye bir buçuk saatte ulaşılır. Nevşehir ise yaklaşık bir saat mesafededir. Otogar merkeze yakındır.",
      },
    ],
  },
  kocaeli: {
    description:
      "Kocaeli escort ilanları İzmit, Gebze, Darıca ve Körfez ayrımıyla listelenir. Gebze ile İzmit arasındaki mesafe ilan planını doğrudan etkiler.",
    sections: [
      {
        heading: "Gebze İstanbul'a, İzmit il merkezine yakındır",
        body: "Kocaeli'de il merkezi İzmit'tir; körfezin doğu ucunda yer alır. Gebze ve Darıca ise batıda, İstanbul sınırına bitişiktir. İzmit ile Gebze arasında yaklaşık elli kilometre ve trafiğe göre bir saate yakın yol vardır. Listedeki ilçe etiketi bu ilde en belirleyici bilgidir.",
      },
      {
        heading: "Sanayi yoğunluğu düzeni belirler",
        body: "Kocaeli Türkiye'nin en yoğun sanayi bölgesidir ve bu durum şehre sezondan bağımsız, hafta içi ağırlıklı bir iş trafiği getirir. Otel doluluğu genellikle hafta içi yükselir. Marmaray ve banliyö hattı Gebze'yi İstanbul'a doğrudan bağlar, bu da iki şehir arasındaki geçişi kolaylaştırır.",
      },
      {
        heading: "Sabiha Gökçen ve Marmaray",
        body: "Kocaeli'ne hava yoluyla giriş Sabiha Gökçen Havalimanı üzerinden yapılır; Gebze'ye yaklaşık yarım saat, İzmit'e ise bir saat uzaklıktadır. Marmaray hattı Gebze'den Halkalı'ya kadar uzanır ve bölgeyi İstanbul'a trafikten bağımsız biçimde bağlar.",
      },
    ],
  },
  konya: {
    description:
      "Konya escort ilanları Selçuklu, Meram ve Karatay ayrımıyla listelenir. Geniş şehir düzeninde ilçeler arası geçiş tramvay hattıyla kolaylaşır.",
    sections: [
      {
        heading: "Üç merkez ilçe farklı karakterdedir",
        body: "Konya'da Karatay tarihi merkezi ve Mevlana çevresini, Meram batıdaki bağlık konut alanlarını, Selçuklu ise kuzeydeki yeni yerleşimi ve üniversite bölgesini kapsar. Otellerin çoğu Selçuklu tarafındadır. İlçeler arası geçiş araçla yirmi ile otuz dakika arasında sürer.",
      },
      {
        heading: "Şeb-i Arus ve ziyaretçi takvimi",
        body: "Aralık ayındaki Şeb-i Arus törenleri şehre yılın en yoğun ziyaretçi akışını getirir ve otel doluluğu bu haftada tavan yapar. Yılın geri kalanında Konya, sanayi ve tarım ticaretiyle düzenli ama sakin bir tempo izler. Tramvay hattı üniversite ile merkez arasını trafikten bağımsız biçimde bağlar.",
      },
      {
        heading: "Hızlı tren ve havalimanı",
        body: "Konya'ya Ankara'dan yüksek hızlı trenle yaklaşık bir buçuk, İstanbul'dan ise dört buçuk saatte ulaşılır; gar merkeze tramvayla bağlanır. Konya Havalimanı ise merkeze yaklaşık on sekiz kilometre uzaklıktadır. Otogar şehrin kuzeyinde, Selçuklu tarafındadır.",
      },
    ],
  },
  kutahya: {
    description:
      "Kütahya escort ilanları merkez ve Tavşanlı ayrımıyla listelenir. Merkez kompakt olduğu için ilanlarda cadde tarifi semt bilgisinin yerini tutar.",
    sections: [
      {
        heading: "Çini çarşısı çevresinde toplanmış merkez",
        body: "Kütahya'da yerleşim kale eteğindeki çarşı ve onun uzantısındaki caddeler boyunca uzanır. Şehir yürünebilir ölçüdedir ve konut alanları merkeze yakındır. Üniversite kampüsü şehrin kenarında, araçla on beş dakika uzaklıktadır.",
      },
      {
        heading: "Termal bölge ve Tavşanlı",
        body: "Kütahya'nın termal tesisleri merkezin dışında, Yoncalı yönünde toplanmıştır ve araçla yaklaşık yirmi dakika uzaklıktadır. Tavşanlı ise merkeze bir saat mesafede, madencilik ağırlıklı ayrı bir ilçedir. Bu iki nokta için ulaşımı ayrıca planlamak gerekir.",
      },
      {
        heading: "Zafer Havalimanı ortak kullanılır",
        body: "Kütahya'ya hava yoluyla giriş, Afyon ve Uşak ile ortak kullanılan Zafer Havalimanı üzerinden yapılır; merkeze yaklaşık altmış kilometre uzaklıktadır. Sefer sayısı sınırlı olduğu için çoğu ziyaretçi karayolunu tercih eder. Eskişehir'e bir buçuk saatte ulaşılır.",
      },
    ],
  },
  malatya: {
    description:
      "Malatya escort ilanları Battalgazi ve Yeşilyurt ayrımıyla listelenir. Deprem sonrası yerleşim değiştiği için konum bilgisini teyit etmek önemlidir.",
    sections: [
      {
        heading: "Merkez iki ilçeye yayılmıştır",
        body: "Malatya'da şehir merkezi Battalgazi ve Yeşilyurt ilçelerinin birleştiği alandır. Yeşilyurt tarafı daha yeni konut alanlarını, Battalgazi ise eski merkez ve çarşıyı kapsar. İki taraf arasında araçla yaklaşık yirmi dakikalık bir yol vardır.",
      },
      {
        heading: "Deprem sonrası konum tarifleri değişti",
        body: "2023 depreminin ardından Malatya'da konut düzeni büyük ölçüde yenilendi ve yerleşimin bir bölümü yeni alanlara kaydı. Bu nedenle eski semt tarifleri her zaman güncel karşılık bulmaz. İlanda verilen konumu doğrudan teyit etmek bu ilde özellikle gereklidir.",
      },
      {
        heading: "Havalimanı merkeze yarım saat",
        body: "Malatya Havalimanı merkeze yaklaşık yirmi beş kilometre uzaklıktadır ve İstanbul ile Ankara'ya düzenli seferleri vardır. Tren hattı da şehirden geçer. Elazığ'a yaklaşık bir buçuk, Kahramanmaraş'a iki saatte ulaşılır. Otogar çevre yolu üzerindedir.",
      },
    ],
  },
  manisa: {
    description:
      "Manisa escort ilanları Şehzadeler, Yunusemre, Akhisar ve Salihli ayrımıyla listelenir. İzmir'e yakınlık ildeki hareketliliği doğrudan etkiler.",
    sections: [
      {
        heading: "İzmir'e kırk dakikalık mesafe",
        body: "Manisa merkez, İzmir'e otoyoldan yaklaşık kırk dakika uzaklıktadır ve iki şehir arasında günlük bir gidiş geliş trafiği vardır. Bu yakınlık, Manisa'daki hareketliliğin bir bölümünü İzmir'e taşır. Merkez, Şehzadeler ve Yunusemre ilçelerinin birleştiği alandır.",
      },
      {
        heading: "Akhisar ve Salihli ayrı merkezlerdir",
        body: "Akhisar kuzeyde, Salihli ise doğuda yer alır ve her ikisi de merkeze yaklaşık bir saat uzaklıktadır. İkisi de kendi çarşısı ve otel kapasitesi olan ilçelerdir. Listede bu ilçelerden birinin etiketini gören biri mesafeyi merkeze göre ayrıca hesaplamalıdır.",
      },
      {
        heading: "İzmir havalimanı ve banliyö hattı",
        body: "Manisa'ya hava yoluyla giriş İzmir Adnan Menderes üzerinden yapılır; merkeze yaklaşık bir saat uzaklıktadır. İki şehir arasındaki banliyö tren hattı düzenli sefer yapar ve trafikten etkilenmez. Akhisar ve Salihli'ye ise otogardan kalkan seferlerle ulaşılır.",
      },
    ],
  },
  kahramanmaras: {
    description:
      "Kahramanmaraş escort ilanları Onikişubat ve Dulkadiroğlu ayrımıyla listelenir. Deprem sonrası değişen yerleşim nedeniyle konum teyidi önemlidir.",
    sections: [
      {
        heading: "Merkez iki ilçeden oluşur",
        body: "Kahramanmaraş'ta şehir merkezi Onikişubat ve Dulkadiroğlu ilçelerinin birleştiği alandır. Dulkadiroğlu eski çarşıyı ve kale çevresini, Onikişubat ise kuzeydeki yeni konut alanlarını kapsar. İki taraf arasında araçla yaklaşık yirmi dakikalık yol vardır.",
      },
      {
        heading: "Deprem sonrası düzen ve çevre bağlantıları",
        body: "2023 depreminin merkez üssüne yakın olan şehirde yerleşim büyük ölçüde yeniden şekillendi; eski semt tarifleri her zaman geçerli değildir. Şehir ayrıca Gaziantep'e bir buçuk, Adana'ya iki saat mesafededir ve bu bağlantılar bölgesel geçişi kolaylaştırır.",
      },
      {
        heading: "Havalimanı ve otoyol bağlantısı",
        body: "Kahramanmaraş Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır ve İstanbul ile Ankara'ya seferleri vardır. Otoyol bağlantısı Gaziantep'e bir buçuk, Adana'ya iki saatte ulaşmayı sağlar. Deprem sonrası otogar ve giriş düzenlemeleri değiştiği için güncel bilgiye bakmak gerekir.",
      },
    ],
  },
  mardin: {
    description:
      "Mardin escort ilanları eski şehir, Yenişehir ve Kızıltepe ayrımıyla listelenir. Eski şehir ile Yenişehir arasında belirgin bir kot farkı vardır.",
    sections: [
      {
        heading: "Eski şehir yamaçta, Yenişehir ovada",
        body: "Mardin'de taş evlerin bulunduğu eski şehir dik bir yamaca kuruludur ve araç trafiğine büyük ölçüde kapalıdır. Yenişehir ise aşağıda, ovada yer alan modern yerleşimdir ve otellerin çoğu bu taraftadır. İki bölge arasında araçla on beş dakikalık bir yol vardır.",
      },
      {
        heading: "Kızıltepe ve sınır hattı",
        body: "Kızıltepe, merkeze yaklaşık yirmi kilometre uzaklıkta, ovada kurulu ve nüfus bakımından merkezden büyük bir ilçedir. Suriye sınırına yakınlığı ticaret trafiğini canlı tutar. Mardin'de turizm ilkbahar ve sonbaharda yoğunlaşır, yaz sıcakları günlük düzeni akşama kaydırır.",
      },
      {
        heading: "Havalimanı Kızıltepe yönündedir",
        body: "Mardin Havalimanı merkezin yaklaşık yirmi kilometre güneyinde, Kızıltepe yönündedir ve araçla yarım saatte ulaşılır. Diyarbakır Havalimanı ise bir buçuk saat mesafeli bir alternatiftir. Midyat'a yaklaşık bir saat, Nusaybin'e ise kırk dakikada ulaşılır.",
      },
    ],
  },
  mugla: {
    description:
      "Muğla escort ilanları Bodrum, Marmaris, Fethiye, Menteşe ve Datça ayrımıyla listelenir. İlçeler arası mesafeler kilometreyle değil saatle ölçülür.",
    sections: [
      {
        heading: "İlçeler birbirine uzaktır",
        body: "Muğla'da il merkezi Menteşe'dir ama hareketliliğin büyük bölümü sahil ilçelerindedir. Bodrum merkeze yaklaşık bir buçuk, Marmaris bir, Fethiye ise iki buçuk saat uzaklıktadır. İlçeler arası geçiş dağ yollarıyla yapıldığı için kilometreden çok süreye bakmak gerekir.",
      },
      {
        heading: "Sezon nisanda başlar, ekimde biter",
        body: "Bodrum ve Marmaris'te yoğunluk haziran ile eylül arasında tavan yapar; bu dönemde ilan sayısı ve güncellenme sıklığı belirgin biçimde artar. Kış aylarında ise sahil ilçeleri büyük ölçüde sakinleşir ve hareketlilik Menteşe ile Fethiye merkeze kayar. Dalaman ve Bodrum havalimanları sezonda giriş noktalarıdır.",
      },
      {
        heading: "İki havalimanı ili ikiye böler",
        body: "Muğla'ya hava yoluyla giriş Bodrum Milas ya da Dalaman havalimanlarından yapılır. Bodrum Milas, Bodrum yarımadasına yaklaşık kırk dakika; Dalaman ise Fethiye ve Marmaris tarafına bir saat uzaklıktadır. Hedef ilçeye göre doğru havalimanını seçmek, saatlerce yol farkı yaratır.",
      },
    ],
  },
  mus: {
    description:
      "Muş escort ilanları merkez ağırlıklı listelenir. Ova kenarına kurulu şehirde mesafeler kısadır, ulaşım tek ana hat üzerinden yürür ve tarif nettir.",
    sections: [
      {
        heading: "Ova kenarında dar bir yerleşim",
        body: "Muş merkezi, geniş Muş Ovası'nın kuzey kenarında, dağ eteğine kurulmuştur. Şehir doğu-batı yönünde uzanan ana cadde etrafında toplanır ve baştan sona kısa sürede geçilir. Üniversite kampüsü merkezin dışında kalır.",
      },
      {
        heading: "Malazgirt ve yol bağlantıları",
        body: "Malazgirt, merkeze yaklaşık yetmiş kilometre uzaklıkta ayrı bir ilçedir. Muş ayrıca Bitlis ve Bingöl yollarının kesiştiği noktadadır; iki ile de yaklaşık bir buçuk saatte ulaşılır. Kış aylarında bu yollar hava koşullarına göre yavaşlar ve ilan güncellemeleri seyrekleşir.",
      },
      {
        heading: "Havalimanı merkeze yakın",
        body: "Muş Havalimanı şehir merkezine yaklaşık on beş kilometre uzaklıktadır ve İstanbul ile Ankara'ya seferleri vardır. Tren hattı da şehirden geçer ve Tatvan yönüne bağlanır. Bitlis'e yaklaşık bir buçuk, Van'a ise üç saatte ulaşılır.",
      },
    ],
  },
  nevsehir: {
    description:
      "Nevşehir escort ilanları merkez, Ürgüp ve Avanos ayrımıyla listelenir. Kapadokya bölgesindeki oteller merkez dışında yoğunlaştığı için ilçe belirleyicidir.",
    sections: [
      {
        heading: "Otel yoğunluğu merkezde değil",
        body: "Nevşehir'de il merkezi sakin bir yerleşimdir; turizmin asıl yoğunlaştığı yerler Göreme, Ürgüp, Uçhisar ve Avanos'tur. Merkez ile Göreme arasında yaklaşık yirmi kilometre, Ürgüp'e ise yarım saatlik yol vardır. Listede ilçe etiketi bu ilde doğrudan ulaşım planını belirler.",
      },
      {
        heading: "Sezon ilkbahar ve sonbaharda zirve yapar",
        body: "Kapadokya'da ziyaretçi yoğunluğu nisan-haziran ve eylül-kasım aralığında tavan yapar; balon turlarının en düzenli kalktığı dönemler de bunlardır. Yaz ortasında sıcaklık, kışın ise hava koşulları akışı azaltır. İlan sayısı da bu takvimi izler.",
      },
      {
        heading: "İki havalimanı seçeneği",
        body: "Kapadokya'ya hava yoluyla giriş Nevşehir Kapadokya Havalimanı ya da Kayseri üzerinden yapılır. Nevşehir havalimanı merkeze yaklaşık otuz kilometre, Kayseri ise Göreme'ye yaklaşık bir saat uzaklıktadır. Sefer çeşitliliği nedeniyle çoğu ziyaretçi Kayseri'yi kullanır.",
      },
    ],
  },
  nigde: {
    description:
      "Niğde escort ilanları merkez ağırlıklı listelenir. Kompakt şehir düzeninde adres cadde adıyla tarif edilir, merkez içi mesafeler yürüme süresindedir.",
    sections: [
      {
        heading: "Kale çevresinde toplanmış merkez",
        body: "Niğde'de yerleşim kale eteğindeki çarşı ve çevresindeki caddelerde yoğunlaşır. Şehir küçük olduğu için merkez içinde mesafe farkı önemsizdir. Üniversite kampüsü şehrin kenarındadır ve dönem içinde merkezdeki hareketliliği artırır.",
      },
      {
        heading: "Otoyol ve Kapadokya yakınlığı",
        body: "Niğde, Ankara-Adana otoyolu üzerindedir ve bu konum yıl boyu geçiş trafiği sağlar. Kapadokya bölgesine yaklaşık bir saat, Adana'ya ise iki saat uzaklıktadır. Çamardı ve Aladağlar yönündeki hareketlilik ise yaz aylarıyla sınırlıdır.",
      },
      {
        heading: "Kapadokya ve Adana üzerinden",
        body: "Niğde'nin havalimanı yoktur; hava yoluyla gelenler Nevşehir, Kayseri ya da Adana'yı kullanır. Kayseri'ye yaklaşık bir buçuk, Adana'ya iki saatte ulaşılır. Şehirden geçen tren hattı Kayseri ile Adana yönüne bağlanır ve gar merkeze yakındır.",
      },
    ],
  },
  ordu: {
    description:
      "Ordu escort ilanları Altınordu, Ünye ve Fatsa ayrımıyla listelenir. Sahil yolu boyunca dizilen üç yerleşim arasındaki mesafe belirgin biçimde hissedilir.",
    sections: [
      {
        heading: "Üç yerleşim sahil yolu üzerinde dizilir",
        body: "Ordu'da il merkezi Altınordu'dur; Boztepe eteğinde, sahil ile tepe arasına sıkışmış bir yerleşimdir. Fatsa batıda yaklaşık kırk dakika, Ünye ise bir saat uzaklıktadır. Üçü de sahil yolu üzerinde arka arkaya gelir ve her birinin kendi çarşısı vardır.",
      },
      {
        heading: "Fındık sezonu ve teleferik",
        body: "Ağustos ve eylüldeki fındık hasadı bölgeye mevsimlik bir işgücü akışı getirir ve şehirdeki hareketlilik bu dönemde artar. Boztepe'ye çıkan teleferik merkezden kısa sürede ulaşılan bir noktadır. Kışın yağış nedeniyle sahil yolu zaman zaman yavaşlar.",
      },
      {
        heading: "Deniz üzerindeki havalimanı",
        body: "Ordu-Giresun Havalimanı deniz doldurularak yapılmış bir tesistir ve Ordu merkeze yaklaşık yirmi kilometre uzaklıktadır. Sahil yolu üzerinde olduğu için ilçelere geçiş kolaydır. Samsun'a karayoluyla yaklaşık iki buçuk, Trabzon'a üç saatte ulaşılır.",
      },
    ],
  },
  rize: {
    description:
      "Rize escort ilanları merkez, Çayeli ve Ardeşen ayrımıyla listelenir. Dar sahil şeridinde yerleşim doğu-batı yönünde uzanır, yukarı mahalleler diktir.",
    sections: [
      {
        heading: "Deniz ile dağ arasında dar bir şerit",
        body: "Rize'de yerleşim sahil ile hemen arkasındaki dik yamaç arasına sıkışmıştır. Merkez, liman ve çarşı çevresinde toplanır. Çayeli doğuda yaklaşık yirmi dakika, Ardeşen ise kırk dakika uzaklıktadır. Yukarı mahallelere çıkış dik yollarla olur ve süre kilometreye göre uzun gelir.",
      },
      {
        heading: "Yağış ve yayla sezonu",
        body: "Rize Türkiye'nin en çok yağış alan ilidir ve yağmur yılın büyük bölümünde etkilidir. Ayder ve çevre yaylalara çıkış haziran ile eylül arasında yoğunlaşır; bu dönemde Çamlıhemşin yönündeki trafik artar. Kışın ise hareketlilik sahil şeridinde kalır.",
      },
      {
        heading: "Rize-Artvin Havalimanı açıldı",
        body: "Rize'ye hava yoluyla giriş, deniz üzerine kurulan Rize-Artvin Havalimanı'ndan yapılır; merkeze yaklaşık kırk dakika uzaklıktadır. Trabzon Havalimanı ise bir saatlik alternatiftir. Ayder'e karayoluyla yaklaşık bir buçuk saatte ulaşılır.",
      },
    ],
  },
  sakarya: {
    description:
      "Sakarya escort ilanları Adapazarı, Serdivan ve Erenler ayrımıyla listelenir. Üç ilçe birleşik bir merkez oluşturduğu için mesafeler kısadır.",
    sections: [
      {
        heading: "Adapazarı ve Serdivan iç içedir",
        body: "Sakarya'da il merkezi Adapazarı'dır; Serdivan ve Erenler ise ona bitişik ilçelerdir ve üçü birlikte tek bir şehir gibi çalışır. Üniversite kampüsü ile alışveriş merkezlerinin çoğu Serdivan tarafındadır. İlçeler arası geçiş araçla on beş dakikayı geçmez.",
      },
      {
        heading: "İstanbul yakınlığı ve Sapanca",
        body: "Sakarya, İstanbul'a otoyoldan yaklaşık bir buçuk saat uzaklıktadır ve bu yakınlık hafta sonu hareketliliğini artırır. Sapanca Gölü çevresindeki bungalov ve otel yoğunluğu merkeze yirmi dakika mesafededir ve özellikle hafta sonları doluluk yükselir.",
      },
      {
        heading: "Tren ve otoyol bağlantısı",
        body: "Sakarya'ya hava yoluyla giriş Sabiha Gökçen üzerinden yapılır; Adapazarı'na yaklaşık bir saat uzaklıktadır. Şehirden geçen tren hattı Ankara ve İstanbul yönüne bağlanır. Otoyol çıkışı merkeze yakındır, Sapanca'ya ise yirmi dakikada ulaşılır.",
      },
    ],
  },
  samsun: {
    description:
      "Samsun escort ilanları İlkadım, Atakum, Canik ve Bafra ayrımıyla listelenir. Sahil boyunca uzanan şehirde tramvay hattı geçişi kolaylaştırır.",
    sections: [
      {
        heading: "Atakum ile İlkadım sahil boyunca uzanır",
        body: "Samsun'da İlkadım şehrin tarihi merkezini ve çarşıyı, Atakum ise batıdaki yeni konut ve üniversite bölgesini kapsar. İkisi sahil boyunca birbirine bağlanır ve tramvay hattı bu ekseni izler. Canik ise doğuda, yamaçta kalan yerleşimdir.",
      },
      {
        heading: "Bafra ayrı bir ilçedir",
        body: "Bafra, merkeze yaklaşık elli kilometre uzaklıkta, Kızılırmak deltasında kurulu ayrı bir ilçedir ve kendi çarşısı vardır. Samsun ayrıca Karadeniz'in en büyük limanlarından birine sahiptir; bu da şehre yıl boyu düzenli bir iş trafiği getirir.",
      },
      {
        heading: "Çarşamba Havalimanı merkeze uzak",
        body: "Samsun Çarşamba Havalimanı merkeze yaklaşık yirmi beş kilometre doğuda yer alır ve araçla yarım saatte ulaşılır. Şehirdeki tramvay hattı sahil boyunca uzanır ve merkez ile Atakum arasını bağlar. Ankara'ya karayoluyla yaklaşık altı saatte ulaşılır.",
      },
    ],
  },
  siirt: {
    description:
      "Siirt escort ilanları merkez ağırlıklı listelenir. Yamaca kurulu kompakt şehirde ulaşım tek ana hat üzerinden yürür, çarşı ve konutlar yan yanadır.",
    sections: [
      {
        heading: "Merkez yamaçta ve derli topludur",
        body: "Siirt merkezi eğimli bir arazide kurulmuştur ve şehir ana cadde çevresinde toplanır. Çarşı ile konut alanları birbirine yakındır, bu yüzden semt ayrımı pratik bir karşılık bulmaz. Üniversite kampüsü merkezin dışında kalır.",
      },
      {
        heading: "Bölge bağlantıları ve mevsim",
        body: "Siirt; Batman'a yaklaşık bir saat, Diyarbakır'a iki buçuk saat uzaklıktadır ve bölge içi geçişler bu hat üzerinden yürür. Yaz ayları çok sıcak geçtiği için günlük tempo akşama kayar, kışın ise düzen gündüze döner. İldeki ilan sayısı sınırlıdır.",
      },
      {
        heading: "Havalimanı ve Batman bağlantısı",
        body: "Siirt Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır ama sefer sayısı sınırlıdır. Bu yüzden çoğu ziyaretçi Batman Havalimanı'nı kullanıp karayoluyla bir saatte şehre ulaşır. Otogar merkeze yakındır ve ilçe seferleri buradan kalkar.",
      },
    ],
  },
  sinop: {
    description:
      "Sinop escort ilanları merkez ve Boyabat ayrımıyla listelenir. Yarımada üzerindeki merkez yürünebilir, iç kesimdeki Boyabat ise bir buçuk saat uzaktadır.",
    sections: [
      {
        heading: "Merkez yarımada üzerindedir",
        body: "Sinop merkezi dar bir yarımadaya kurulmuştur; liman, kale ve çarşı birbirine birkaç dakikalık yürüme mesafesindedir. Bu yüzden merkez etiketli ilanlar arasında mesafe farkı yok sayılabilir. Yeni konut alanları yarımadanın güney tarafında kalır.",
      },
      {
        heading: "Boyabat iç kesimde, uzaktadır",
        body: "Boyabat, merkeze yaklaşık yüz kilometre uzaklıkta, iç kesimde kurulu ayrı bir ilçedir ve araçla bir buçuk saat sürer. Sinop'ta yaz ayları günübirlik ve haftalık ziyaretçi akışıyla hareketlenir, kışın ise şehir belirgin biçimde sakinleşir.",
      },
      {
        heading: "Havalimanı ve karayolu",
        body: "Sinop Havalimanı merkeze yakındır ama sefer sayısı sınırlı ve mevsime bağlıdır. Şehre giriş çıkışın büyük bölümü karayoluyla yapılır; Samsun'a yaklaşık üç, Kastamonu'ya iki buçuk saatte ulaşılır. Ankara'dan gelenler için yol yaklaşık yedi saattir.",
      },
    ],
  },
  sivas: {
    description:
      "Sivas escort ilanları merkez ağırlıklı listelenir. Geniş caddeli şehirde adres tarifi kolaydır, çevre ilçeler ise merkeze saatlerce uzaklıkta kalır.",
    sections: [
      {
        heading: "Kongre binası çevresinde toplanan merkez",
        body: "Sivas'ta şehir merkezi Atatürk Caddesi ve kongre binası çevresindeki alanda yoğunlaşır. Caddeler geniş ve düzenlidir, bu da adres bulmayı kolaylaştırır. Cumhuriyet Üniversitesi kampüsü merkeze araçla yaklaşık yirmi dakikadır.",
      },
      {
        heading: "Demiryolu kavşağı ve kış",
        body: "Sivas, Türkiye'nin en önemli demiryolu kavşaklarından biridir ve bu konum şehre yıl boyu düzenli bir geçiş trafiği sağlar. Kış uzun ve soğuk geçer; aralık ile mart arasında şehir dışı yollar hava koşullarına göre aksayabilir. Balıklı Kaplıca ise merkeze yaklaşık bir saat uzaklıktadır.",
      },
      {
        heading: "Havalimanı, gar ve hızlı tren",
        body: "Sivas Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır. Şehir aynı zamanda Ankara-Sivas yüksek hızlı tren hattının son durağıdır; Ankara'ya yaklaşık iki saatte ulaşılır. Gar merkeze yakındır ve bu hat şehre düzenli bir yolcu akışı getirmiştir.",
      },
    ],
  },
  tekirdag: {
    description:
      "Tekirdağ escort ilanları Süleymanpaşa, Çorlu ve Çerkezköy ayrımıyla listelenir. Sanayi ilçeleri ile sahildeki il merkezi ayrı değerlendirilir.",
    sections: [
      {
        heading: "Çorlu merkezden daha kalabalıktır",
        body: "Tekirdağ'da il merkezi Süleymanpaşa, Marmara kıyısındadır. Çorlu ve Çerkezköy ise iç kesimde, İstanbul yoluna yakın sanayi ilçeleridir ve nüfus bakımından merkezin önündedir. Süleymanpaşa ile Çorlu arasında yaklaşık kırk dakikalık yol vardır.",
      },
      {
        heading: "Sanayi ve hafta sonu sahil akışı",
        body: "Çerkezköy ve Çorlu'daki organize sanayi bölgeleri hafta içi yoğun bir iş trafiği yaratır; otel doluluğu da bu günlerde yükselir. Buna karşılık sahil şeridi, özellikle yaz hafta sonlarında İstanbul'dan gelen günübirlik ziyaretçilerle hareketlenir.",
      },
      {
        heading: "Çorlu Havalimanı ve otoyol",
        body: "Tekirdağ'a hava yoluyla giriş Çorlu'daki Tekirdağ Havalimanı üzerinden yapılır ama sefer sayısı sınırlıdır; çoğu ziyaretçi İstanbul Havalimanı'nı kullanır. Süleymanpaşa'ya İstanbul'dan karayoluyla yaklaşık iki saatte ulaşılır. Kuzey Marmara Otoyolu bu süreyi kısaltmıştır.",
      },
    ],
  },
  tokat: {
    description:
      "Tokat escort ilanları merkez, Turhal ve Erbaa ayrımıyla listelenir. İlçelerin kendi çarşısı olduğu için listede ilçe etiketi ilk bakılacak bilgidir.",
    sections: [
      {
        heading: "Merkez vadi içinde kalır",
        body: "Tokat merkezi, kale eteğindeki vadiye kurulu derli toplu bir yerleşimdir. Çarşı ile konut alanları birbirine yakındır ve şehir içi mesafeler kısadır. Gaziosmanpaşa Üniversitesi kampüsü merkezin dışında, araçla on beş dakika uzaklıktadır.",
      },
      {
        heading: "Turhal ve Erbaa kendi düzenlerini kurar",
        body: "Turhal merkeze yaklaşık yarım saat, Erbaa ise bir saat uzaklıktadır ve ikisi de kendi çarşısı olan ilçelerdir. Niksar ve Zile de benzer biçimde ayrı değerlendirilir. İlanlarda ilçe bilgisi, mesafeyi doğru hesaplamak için ilk bakılacak alandır.",
      },
      {
        heading: "Havalimanı ve çevre bağlantılar",
        body: "Tokat Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır ve sefer sayısı sınırlıdır. Birçok ziyaretçi Sivas ya da Merzifon havalimanlarını kullanır. Sivas'a karayoluyla yaklaşık iki, Amasya'ya bir buçuk saatte ulaşılır. Otogar merkeze yakındır.",
      },
    ],
  },
  trabzon: {
    description:
      "Trabzon escort ilanları Ortahisar, Akçaabat ve Yomra ayrımıyla listelenir. Sahil yolu boyunca uzanan şehirde ilçe etiketi ulaşım süresini belirler.",
    sections: [
      {
        heading: "Şehir sahil yolu boyunca uzanır",
        body: "Trabzon'da merkez Ortahisar ilçesidir; Meydan Parkı ve Uzun Sokak çevresinde toplanır. Akçaabat batıda yaklaşık yirmi dakika, Yomra ise doğuda on beş dakika uzaklıktadır. Yerleşim sahil ile yamaç arasına sıkıştığı için yukarı mahallelere çıkış dik yollarla olur.",
      },
      {
        heading: "Körfez turizmi yaz aylarında zirvede",
        body: "Haziran ile eylül arasında Körfez ülkelerinden gelen ziyaretçi akışı Trabzon'daki otel doluluğunu belirgin biçimde artırır; bu dönemde Uzungöl ve Ayder yönündeki trafik de yoğunlaşır. Kışın ise şehir kendi günlük temposuna döner ve ilan sayısı normalleşir.",
      },
      {
        heading: "Havalimanı sahil yoluna bitişik",
        body: "Trabzon Havalimanı merkeze yaklaşık altı kilometre uzaklıktadır ve sahil yoluna bitişik olduğu için şehre giriş hızlıdır; bölgenin en yoğun sefer trafiğine sahip noktasıdır. Uzungöl'e karayoluyla yaklaşık bir buçuk saatte ulaşılır. Otogar da havalimanına yakındır.",
      },
    ],
  },
  tunceli: {
    description:
      "Tunceli escort ilanları merkez ağırlıklı listelenir. Munzur kıyısındaki küçük merkezde mesafeler yürüme süresindedir, semt ayrımı karşılık bulmaz.",
    sections: [
      {
        heading: "Munzur kıyısında küçük bir merkez",
        body: "Tunceli merkezi Munzur Nehri kıyısında kurulu, Türkiye'nin en küçük il merkezlerinden biridir. Şehir baştan sona yürünebilir ve semt ayrımının pratik bir karşılığı yoktur. Üniversite kampüsü merkeze bitişiktir ve şehrin genç nüfusunu bir arada tutar.",
      },
      {
        heading: "Yaz aylarında hareketlilik artar",
        body: "Munzur Vadisi ve çevresindeki doğa alanları haziran ile eylül arasında ziyaretçi çeker ve şehirdeki tempo bu dönemde yükselir. Kışın ise yollar hava koşullarına göre aksar, ilan sayısı belirgin biçimde azalır. Elazığ'a yaklaşık bir buçuk saatte ulaşılır.",
      },
      {
        heading: "Elazığ üzerinden giriş",
        body: "Tunceli'nin havalimanı yoktur; hava yoluyla gelenler Elazığ'ı kullanır ve karayoluyla yaklaşık bir buçuk saatte şehre ulaşır. Erzincan Havalimanı ise iki saatlik bir alternatiftir. Otogar merkezdedir ve ilçe seferleri buradan kalkar.",
      },
    ],
  },
  sanliurfa: {
    description:
      "Şanlıurfa escort ilanları Haliliye, Eyyübiye, Karaköprü ve Siverek ayrımıyla listelenir. Yaz sıcağı şehrin günlük düzenini akşam saatlerine kaydırır.",
    sections: [
      {
        heading: "Karaköprü yeni, Haliliye merkez taraftır",
        body: "Şanlıurfa'da Haliliye şehrin merkezini ve Balıklıgöl çevresindeki tarihi alanı kapsar. Karaköprü kuzeydeki yeni konut bölgesidir ve otellerin çoğu bu tarafta ya da merkeze yakın hattadır. Eyyübiye ise güneyde yoğun nüfuslu bir ilçedir. İlçeler arası geçiş araçla yirmi dakikayı bulur.",
      },
      {
        heading: "Sıcaklık ve Siverek mesafesi",
        body: "Urfa'da yaz uzun ve çok sıcak geçer; şehrin günlük hayatı bu dönemde akşam saatlerinde canlanır ve gece geç saatlere uzanır. Siverek ise merkeze yaklaşık yüz kilometre uzaklıkta, kendi düzeni olan büyük bir ilçedir ve ayrı değerlendirilmelidir.",
      },
      {
        heading: "GAP Havalimanı merkeze uzak",
        body: "Şanlıurfa GAP Havalimanı merkeze yaklaşık otuz beş kilometre uzaklıktadır ve araçla kırk dakika sürer; uçuş saatlerine bağlı servisler çalışır. Gaziantep'e otoyolla yaklaşık bir buçuk saatte ulaşılır. Otogar şehrin kuzeyinde, çevre yolu üzerindedir.",
      },
    ],
  },
  usak: {
    description:
      "Uşak escort ilanları merkez ağırlıklı listelenir. Kompakt şehir düzeninde çarşı ile konut alanları arasındaki mesafe araçla on dakikayı geçmez.",
    sections: [
      {
        heading: "Merkez tek parça halindedir",
        body: "Uşak'ta yerleşim merkezde toplanmıştır ve çarşı ile konut alanları arasındaki mesafe araçla on dakikayı geçmez. Üniversite kampüsü şehrin kenarında kalır. Semt ayrımı belirleyici olmadığı için listede ilanın güncellenme zamanına bakmak daha işe yarar.",
      },
      {
        heading: "Tekstil ve geçiş yolu",
        body: "Uşak'ın tekstil ve deri üretimi şehre düzenli bir iş trafiği getirir ve hafta içi hareketliliği hafta sonundan düşük kalmaz. Şehir ayrıca İzmir ile Afyon arasındaki güzergah üzerindedir; İzmir'e yaklaşık üç, Afyon'a bir buçuk saat uzaklıktadır.",
      },
      {
        heading: "Zafer Havalimanı ve tren",
        body: "Uşak'a hava yoluyla giriş, Kütahya ve Afyon ile ortak kullanılan Zafer Havalimanı üzerinden yapılır; merkeze yaklaşık yetmiş kilometre uzaklıktadır. Şehirden geçen tren hattı İzmir ile Afyon yönüne bağlanır ve gar merkeze yakındır.",
      },
    ],
  },
  van: {
    description:
      "Van escort ilanları İpekyolu, Edremit ve Erciş ayrımıyla listelenir. Göl kıyısındaki Edremit ile merkez arasında on beş dakikalık bir yol vardır.",
    sections: [
      {
        heading: "Merkez gölün birkaç kilometre içindedir",
        body: "Van'da şehir merkezi İpekyolu ilçesindedir ve göl kıyısından birkaç kilometre içeride kalır. Edremit ise kıyıya bitişik, daha yeni bir yerleşimdir ve merkeze araçla yaklaşık on beş dakikadır. Otellerin çoğu merkez ile Edremit arasındaki hat üzerindedir.",
      },
      {
        heading: "Erciş ve göl çevresi mesafeleri",
        body: "Erciş, gölün kuzeyinde, merkeze yaklaşık yüz kilometre uzaklıkta ayrı bir ilçedir ve araçla bir buçuk saat sürer. Van'da kış uzun geçer ve bu dönemde şehirler arası yollar aksayabilir. Yaz aylarında ise göl çevresi ve Akdamar yönünde hareketlilik artar.",
      },
      {
        heading: "Ferit Melen Havalimanı şehre yakın",
        body: "Van Ferit Melen Havalimanı merkeze yaklaşık altı kilometre uzaklıktadır ve bölgenin en yoğun giriş noktalarından biridir. Gar ise Tatvan feribot hattına bağlanır. Hakkari'ye karayoluyla yaklaşık üç, Bitlis'e iki saatte ulaşılır.",
      },
    ],
  },
  yozgat: {
    description:
      "Yozgat escort ilanları merkez ve Sorgun ayrımıyla listelenir. Otoyol üzerindeki konum şehre yıl boyu düzenli bir geçiş trafiği sağlar, mesafe kısadır.",
    sections: [
      {
        heading: "Merkez yamaçta, Sorgun ovada",
        body: "Yozgat merkezi eğimli bir arazide kurulu, çarşı çevresinde toplanmış bir yerleşimdir. Sorgun ise merkeze yaklaşık kırk kilometre uzaklıkta, daha düz bir arazide kurulu ve kendi çarşısı olan bir ilçedir. İki nokta arasında yarım saatlik yol vardır.",
      },
      {
        heading: "Ankara-Sivas hattı üzerinde",
        body: "Yozgat, Ankara ile Sivas arasındaki ana güzergah üzerindedir; Ankara'ya yaklaşık iki buçuk saatte ulaşılır. Bu konum şehre yıl boyu geçiş trafiği getirir. Sarıkaya ve Boğazlıyan yönündeki termal tesisler ise merkeze bir saatten uzaktır.",
      },
      {
        heading: "Ankara ve Kayseri üzerinden",
        body: "Yozgat'ın havalimanı yoktur; hava yoluyla gelenler Ankara Esenboğa ya da Kayseri'yi kullanır. Ankara'ya karayoluyla yaklaşık iki buçuk, Kayseri'ye iki saatte ulaşılır. Ankara-Sivas hızlı tren hattının Yerköy durağı da bir alternatif oluşturur.",
      },
    ],
  },
  zonguldak: {
    description:
      "Zonguldak escort ilanları merkez, Ereğli ve Çaycuma ayrımıyla listelenir. Ereğli nüfus bakımından il merkezinin önündedir, arada bir saatlik yol vardır.",
    sections: [
      {
        heading: "Ereğli merkezden büyüktür",
        body: "Zonguldak'ta il merkezi liman çevresinde, dik yamaçlara kurulu dar bir yerleşimdir. Kdz. Ereğli ise batıda, demir çelik tesisleriyle büyümüş ve nüfus bakımından merkezin önüne geçmiş bir ilçedir. İki yerleşim arasında yaklaşık bir saatlik yol vardır.",
      },
      {
        heading: "Madencilik ve vardiya düzeni",
        body: "Taş kömürü madenciliği şehrin günlük temposunu vardiya saatlerine göre şekillendirir ve hafta içi hareketlilik yüksek kalır. Çaycuma ise iç kesimde, merkeze yaklaşık kırk dakika uzaklıktadır. Yağışlı günlerde sahil ve yamaç yolları yavaşlar.",
      },
      {
        heading: "Çaycuma'daki havalimanı",
        body: "Zonguldak'a hava yoluyla giriş Çaycuma'daki Zonguldak Havalimanı üzerinden yapılır; merkeze yaklaşık elli kilometre uzaklıktadır ve sefer sayısı sınırlıdır. İstanbul'a karayoluyla yaklaşık dört saatte ulaşılır. Limandan ise Karadeniz'e yük trafiği yürür.",
      },
    ],
  },
  aksaray: {
    description:
      "Aksaray escort ilanları merkez ağırlıklı listelenir. Otoyol kenarındaki konum şehre yıl boyu geçiş trafiği getirir, merkez içi mesafeler kısa kalır.",
    sections: [
      {
        heading: "Düz ovada derli toplu bir merkez",
        body: "Aksaray, düz bir ovada kurulu olduğu için şehir düzeni açıktır ve adres bulmak kolaydır. Çarşı merkezdeki ana meydan çevresinde toplanır, konut alanları ona yakındır. Üniversite kampüsü şehrin dışında, araçla on beş dakika uzaklıktadır.",
      },
      {
        heading: "Ankara-Adana hattı ve Ihlara",
        body: "Aksaray, Ankara ile Adana arasındaki otoyol üzerindedir; Ankara'ya iki buçuk, Konya'ya iki saat uzaklıktadır. Bu konum şehri bir ara durak haline getirir. Ihlara Vadisi ve Hasan Dağı yönündeki ziyaretler ise ilkbahar ve sonbaharda yoğunlaşır.",
      },
      {
        heading: "Nevşehir ve Konya üzerinden",
        body: "Aksaray'ın havalimanı yoktur; hava yoluyla gelenler Nevşehir Kapadokya ya da Konya'yı kullanır. Nevşehir'e yaklaşık bir, Konya'ya iki saatte ulaşılır. Otoyol bağlantısı sayesinde Ankara ve Adana yönüne doğrudan geçiş mümkündür.",
      },
    ],
  },
  bayburt: {
    description:
      "Bayburt escort ilanları merkez ağırlıklı listelenir. Türkiye'nin en küçük illerinden biri olduğu için ilan sayısı sınırlı, mesafeler ise çok kısadır.",
    sections: [
      {
        heading: "Nehir kenarında tek merkez",
        body: "Bayburt, Çoruh Nehri kıyısında kurulu küçük bir şehirdir ve yerleşim tamamen merkezde toplanır. Kale eteğindeki çarşı ile konut alanları arasındaki mesafe yürüme süresindedir. Semt ayrımının pratikte bir karşılığı yoktur.",
      },
      {
        heading: "Erzurum ve Trabzon arasında kalır",
        body: "Bayburt; Erzurum'a yaklaşık iki, Trabzon'a ise iki buçuk saat uzaklıktadır ve iki şehir arasındaki geçiş hattı üzerinde yer alır. Kış uzun ve sert geçer; bu dönemde yollar aksayabilir ve ilan sayısı daha da düşer.",
      },
      {
        heading: "En yakın havalimanları uzaktır",
        body: "Bayburt'un havalimanı yoktur; en yakın seçenekler Erzurum ve Trabzon'dur ve her ikisi de yaklaşık iki saat uzaklıktadır. Trabzon yönünden geliş Zigana geçidini içerir ve kış aylarında yavaşlayabilir. Otogar merkezdedir.",
      },
    ],
  },
  karaman: {
    description:
      "Karaman escort ilanları merkez ağırlıklı listelenir. Konya'ya bir buçuk saatlik yakınlık ildeki hareketliliğin bir bölümünü komşu ile taşır, merkez küçüktür.",
    sections: [
      {
        heading: "Kompakt ve düzenli bir merkez",
        body: "Karaman, ova üzerinde kurulu derli toplu bir şehirdir. Çarşı merkezdeki ana cadde çevresinde toplanır ve konut alanları ona yakındır. Üniversite kampüsü şehrin kenarındadır. Şehir içi mesafeler kısa olduğu için ulaşım planı basittir.",
      },
      {
        heading: "Konya yakınlığı belirleyicidir",
        body: "Karaman, Konya'ya yaklaşık yüz kilometre uzaklıktadır ve araçla bir buçuk saatte ulaşılır. Bu yakınlık ildeki hareketliliğin bir bölümünü Konya'ya kaydırır ve ilan sayısını sınırlı tutar. Güncel ilan bulunamadığında Konya sayfasına bakmak daha hızlı sonuç verir.",
      },
      {
        heading: "Konya üzerinden giriş",
        body: "Karaman'ın havalimanı yoktur; hava yoluyla gelenler Konya'yı kullanır ve karayoluyla bir buçuk saatte şehre ulaşır. Şehirden geçen tren hattı Konya ve Mersin yönüne bağlanır. Mersin'e karayoluyla yaklaşık iki buçuk saatte ulaşılır.",
      },
    ],
  },
  kirikkale: {
    description:
      "Kırıkkale escort ilanları merkez ağırlıklı listelenir. Ankara'ya bir saatlik mesafe ildeki günlük hareketliliği ve ilan sayısını doğrudan etkiler.",
    sections: [
      {
        heading: "Merkez sanayi çevresinde kurulmuştur",
        body: "Kırıkkale, sanayi tesisleri etrafında büyümüş planlı bir şehirdir; caddeler düzenlidir ve adres bulmak kolaydır. Çarşı merkezde toplanır, konut alanları ona bitişiktir. Üniversite kampüsü şehrin dışında, araçla yaklaşık yirmi dakika uzaklıktadır.",
      },
      {
        heading: "Ankara'ya günlük gidiş geliş var",
        body: "Kırıkkale, Ankara'ya yaklaşık seksen kilometre uzaklıktadır ve iki şehir arasında günlük bir gidiş geliş trafiği bulunur. Bu yakınlık ildeki ilan sayısını sınırlı tutar. Şehir ayrıca Ankara ile Samsun ve Sivas yollarının ayrıldığı noktadadır.",
      },
      {
        heading: "Esenboğa bir saat uzaklıkta",
        body: "Kırıkkale'nin havalimanı yoktur; hava yoluyla gelenler Ankara Esenboğa'yı kullanır ve karayoluyla yaklaşık bir saatte şehre ulaşır. Ankara-Sivas hızlı tren hattı da şehirden geçer. Otogar merkeze yakındır ve seferler sık aralıklarla kalkar.",
      },
    ],
  },
  batman: {
    description:
      "Batman escort ilanları merkez ağırlıklı listelenir. Planlı cadde düzeni adres tarifini kolaylaştırır, oteller ana bulvar üzerinde toplanmış durumdadır.",
    sections: [
      {
        heading: "Petrol sanayisiyle büyümüş planlı şehir",
        body: "Batman, rafineri çevresinde planlı biçimde büyümüş bir şehirdir; caddeler geniş ve birbirine diktir. Merkez, Turgut Özal Bulvarı çevresinde toplanır ve otellerin çoğu bu hat üzerindedir. Şehir içi mesafeler kısadır, semt farkı belirleyici değildir.",
      },
      {
        heading: "Hasankeyf ve bölge bağlantıları",
        body: "Batman; Diyarbakır'a yaklaşık bir buçuk, Mardin'e bir saat uzaklıktadır ve bölge içi geçişlerde sık kullanılan bir duraktır. Yeni Hasankeyf merkeze yaklaşık kırk dakika mesafededir. Yaz sıcakları nedeniyle günlük tempo akşam saatlerine kayar.",
      },
      {
        heading: "Havalimanı bölgesel giriş noktası",
        body: "Batman Havalimanı merkeze yaklaşık yirmi kilometre uzaklıktadır ve Siirt ile Hasankeyf yönüne gelenler için de kullanılan bir giriş noktasıdır. Diyarbakır Havalimanı ise bir buçuk saatlik alternatiftir. Tren hattı da şehirden geçer.",
      },
    ],
  },
  sirnak: {
    description:
      "Şırnak escort ilanları merkez ve Cizre ayrımıyla listelenir. Cizre nüfus bakımından merkezin önünde olduğundan listede ilçe etiketi öne alınır, yol uzundur.",
    sections: [
      {
        heading: "Merkez yüksekte, Cizre ovada",
        body: "Şırnak merkezi Cudi Dağı eteğinde, yüksek bir arazide kurulmuştur. Cizre ise Dicle kıyısındaki ovada yer alır ve nüfus bakımından merkezden büyüktür. İki yerleşim arasında yaklaşık elli kilometre vardır ama dağ yolu nedeniyle süre bir saati bulur.",
      },
      {
        heading: "Sınır ticareti bölgeyi hareketli tutar",
        body: "Habur Sınır Kapısı'nın yakınlığı Silopi ve Cizre hattında yıl boyu bir geçiş trafiği yaratır. Yaz ayları çok sıcak geçtiği için günlük düzen akşama kayar; merkezde ise yükseklik nedeniyle sıcaklık daha ılımlıdır. İldeki ilan sayısı sınırlı kalır.",
      },
      {
        heading: "Şerafettin Elçi Havalimanı",
        body: "Şırnak'a hava yoluyla giriş Cizre yakınındaki Şerafettin Elçi Havalimanı'ndan yapılır; il merkezine yaklaşık bir saat uzaklıktadır. Mardin Havalimanı ise iki saatlik bir alternatiftir. Habur Sınır Kapısı'na Silopi üzerinden ulaşılır.",
      },
    ],
  },
  bartin: {
    description:
      "Bartın escort ilanları merkez ve Amasra ayrımıyla listelenir. Amasra sahilde, merkez ise iç kesimde kaldığı için ikisi ayrı ayrı planlanmalıdır.",
    sections: [
      {
        heading: "Merkez sahilde değil, içeridedir",
        body: "Bartın'da il merkezi denize birkaç kilometre uzaklıkta, nehir kıyısında kuruludur. Amasra ise sahildedir ve merkeze araçla yaklaşık yirmi dakikadır. Otel kapasitesinin büyük bölümü Amasra tarafındadır. Listede bu ayrım, ulaşım planını doğrudan belirler.",
      },
      {
        heading: "Hafta sonu ve yaz yoğunluğu",
        body: "Amasra, özellikle yaz hafta sonlarında Ankara ve İstanbul'dan gelen günübirlik ziyaretçilerle kalabalıklaşır ve doluluk belirgin biçimde artar. Kışın ise hem ilçe hem merkez sakinleşir. Yağışlı dönemde sahil yolu virajlı kesimlerde yavaşlar.",
      },
      {
        heading: "Karayolu ağırlıklı ulaşım",
        body: "Bartın'ın havalimanı yoktur; en yakın seçenek Çaycuma'daki Zonguldak Havalimanı'dır ve yaklaşık bir saat uzaklıktadır. Şehre giriş çıkışın büyük bölümü karayoluyla yapılır; Ankara'ya yaklaşık dört, İstanbul'a beş saatte ulaşılır.",
      },
    ],
  },
  ardahan: {
    description:
      "Ardahan escort ilanları merkez ağırlıklı listelenir. Yüksek rakım ve kasımdan nisana süren kış, ildeki hareketliliği ve ilan sayısını doğrudan belirler.",
    sections: [
      {
        heading: "Küçük ve tek eksenli bir merkez",
        body: "Ardahan merkezi, Kura Nehri kıyısında kurulu küçük bir yerleşimdir ve şehir tek ana cadde boyunca uzanır. Çarşı ile konut alanları birbirine yürüme mesafesindedir. Semt ayrımının pratik bir karşılığı yoktur, listede ilanın güncelliği öne çıkar.",
      },
      {
        heading: "Kış çok uzun sürer",
        body: "Ardahan Türkiye'nin en yüksek rakımlı ve en soğuk il merkezlerinden biridir; kış kasımdan nisana kadar sürer. Bu dönemde şehirler arası yollar sık sık aksar ve ilan sayısı düşer. Kars'a yaklaşık bir saat, Artvin'e ise iki saat uzaklıktadır.",
      },
      {
        heading: "Kars üzerinden giriş",
        body: "Ardahan'ın havalimanı yoktur; hava yoluyla gelenler Kars'ı kullanır ve karayoluyla yaklaşık bir saatte şehre ulaşır. Kış aylarında bu yol hava koşullarına göre uzayabilir. Artvin yönüne geçiş ise Şavşat üzerinden yaklaşık iki saat sürer.",
      },
    ],
  },
  igdir: {
    description:
      "Iğdır escort ilanları merkez ağırlıklı listelenir. Ova üzerindeki şehirde mesafeler kısadır, sınır kapısı ise yıl boyu bir geçiş trafiği yaratır.",
    sections: [
      {
        heading: "Ağrı Dağı eteğinde düz bir ova",
        body: "Iğdır, Ağrı Dağı'nın kuzey eteğindeki ovada kuruludur ve bölgenin en alçak rakımlı yerleşimlerinden biridir. Şehir merkezi düz ve derli topludur, caddeler birbirine diktir. Şehir içi mesafeler kısa olduğu için ulaşım planı basittir.",
      },
      {
        heading: "Dilucu Sınır Kapısı ve iklim",
        body: "Nahçıvan'a açılan Dilucu Sınır Kapısı ile İran bağlantısı, Iğdır'da yıl boyu bir geçiş trafiği yaratır. Rakımın düşük olması yazları sıcak, kışları ise bölgeye göre daha ılıman geçmesini sağlar. Bu yüzden çevre illerin aksine kış ulaşımı daha az aksar.",
      },
      {
        heading: "Kars ve Ağrı üzerinden",
        body: "Iğdır'ın havalimanı yoktur; hava yoluyla gelenler Kars ya da Ağrı'yı kullanır ve karayoluyla iki ile üç saat arasında şehre ulaşır. Nahçıvan'a açılan Dilucu Sınır Kapısı ise merkeze yaklaşık bir saat uzaklıktadır.",
      },
    ],
  },
  yalova: {
    description:
      "Yalova escort ilanları merkez ve Çınarcık ayrımıyla listelenir. İstanbul'dan feribot bağlantısı ildeki hafta sonu yoğunluğunu belirgin biçimde artırır.",
    sections: [
      {
        heading: "Feribot şehre giriş noktasıdır",
        body: "Yalova'ya İstanbul'dan deniz yoluyla yaklaşık bir saatte ulaşılır ve şehrin günlük temposu feribot sefer saatlerine göre şekillenir. Merkez, iskele çevresinde toplanır ve yürünebilir ölçüdedir. Çınarcık ise batıda, sahil yolu üzerinde yaklaşık yarım saat uzaklıktadır.",
      },
      {
        heading: "Termal bölge merkezin dışındadır",
        body: "Termal ilçesindeki kaplıca tesisleri merkezin yaklaşık on iki kilometre güneyindedir ve araçla yirmi dakikada ulaşılır. Bu bölgedeki otel doluluğu hafta sonları belirgin biçimde yükselir. Listede merkez mi termal bölge mi tarif edildiğine bakmak gerekir.",
      },
      {
        heading: "Feribot ve otoyol birlikte",
        body: "Yalova'ya İstanbul'dan Yenikapı ve Pendik iskelelerinden deniz otobüsüyle yaklaşık bir saatte ulaşılır. Osmangazi Köprüsü üzerinden karayolu bağlantısı da benzer sürededir. Bursa'ya karayoluyla yaklaşık bir saat on beş dakikada ulaşılır.",
      },
    ],
  },
  karabuk: {
    description:
      "Karabük escort ilanları merkez ve Safranbolu ayrımıyla listelenir. Safranbolu'daki konaklama yoğunluğu il merkezinden ayrı değerlendirilmelidir.",
    sections: [
      {
        heading: "Safranbolu merkeze çok yakındır",
        body: "Karabük'te il merkezi demir çelik tesisleri çevresinde büyümüş bir yerleşimdir. Safranbolu ise merkeze yaklaşık on kilometre uzaklıkta, tarihi konaklarıyla bilinen ilçedir ve araçla on beş dakikada ulaşılır. Konaklama kapasitesinin büyük bölümü Safranbolu tarafındadır.",
      },
      {
        heading: "Hafta sonu ziyaretçi akışı",
        body: "Safranbolu, özellikle sonbahar ve kış hafta sonlarında yoğun ziyaretçi alır; bu dönemde ilçedeki doluluk merkezin çok üzerine çıkar. Karabük ayrıca Ankara'ya yaklaşık üç saat uzaklıktadır ve üniversite nüfusu dönem içinde şehri hareketli tutar.",
      },
      {
        heading: "Tren hattı Safranbolu'ya uğrar",
        body: "Karabük'ün havalimanı yoktur; şehre ulaşım karayolu ve demiryoluyla sağlanır. Ankara'dan kalkan tren seferleri Karabük ve Safranbolu duraklarına uğrar ve yolculuk yaklaşık dört saat sürer. Karayoluyla Ankara'ya üç, İstanbul'a beş saatte ulaşılır.",
      },
    ],
  },
  kilis: {
    description:
      "Kilis escort ilanları merkez ağırlıklı listelenir. Gaziantep'e bir saatlik yakınlık ildeki hareketliliğin bir bölümünü komşu ile taşır, merkez küçüktür.",
    sections: [
      {
        heading: "Tek merkezli küçük bir il",
        body: "Kilis'te yerleşim tamamen merkezde toplanır ve şehir baştan sona kısa sürede geçilir. Çarşı ile konut alanları birbirine yakındır, semt ayrımı pratik bir karşılık bulmaz. Üniversite kampüsü merkezin kenarındadır.",
      },
      {
        heading: "Gaziantep ve sınır hattı",
        body: "Kilis, Gaziantep'e yaklaşık altmış kilometre uzaklıktadır ve araçla bir saatte ulaşılır. Bu yakınlık ildeki ilan sayısını sınırlı tutar. Öncüpınar Sınır Kapısı ise şehre düzenli bir geçiş trafiği getirir. Yaz sıcakları günlük düzeni akşam saatlerine kaydırır.",
      },
      {
        heading: "Gaziantep üzerinden giriş",
        body: "Kilis'in havalimanı yoktur; hava yoluyla gelenler Gaziantep'i kullanır ve karayoluyla yaklaşık bir saatte şehre ulaşır. Öncüpınar Sınır Kapısı merkeze birkaç kilometre uzaklıktadır. Otogar merkezdedir ve Gaziantep seferleri sık aralıklarla kalkar.",
      },
    ],
  },
  osmaniye: {
    description:
      "Osmaniye escort ilanları merkez ve Kadirli ayrımıyla listelenir. Otoyol kavşağındaki konum şehre yıl boyu düzenli bir geçiş trafiği sağlar, yollar kısadır.",
    sections: [
      {
        heading: "Merkez otoyola bitişiktir",
        body: "Osmaniye merkezi, Adana-Gaziantep otoyoluna bitişik konumdadır ve bu durum şehre düzenli bir geçiş trafiği getirir. Yerleşim derli topludur, çarşı ile konut alanları arasındaki mesafe kısadır. Üniversite kampüsü şehrin kenarında kalır.",
      },
      {
        heading: "Kadirli ayrı bir ilçedir",
        body: "Kadirli, merkeze yaklaşık kırk kilometre uzaklıkta ve kendi çarşısı olan bir ilçedir; araçla yarım saatte ulaşılır. Osmaniye ayrıca Adana'ya bir, Gaziantep'e bir buçuk saat mesafededir. Yaz ayları sıcak geçtiği için şehrin temposu akşam saatlerinde yükselir.",
      },
      {
        heading: "Adana ve Hatay havalimanları",
        body: "Osmaniye'nin havalimanı yoktur; hava yoluyla gelenler Adana ya da Hatay'ı kullanır. Adana'ya karayoluyla yaklaşık bir saatte ulaşılır. Şehirden geçen tren hattı Adana ile Gaziantep yönüne bağlanır ve otoyol çıkışı merkeze bitişiktir.",
      },
    ],
  },
  duzce: {
    description:
      "Düzce escort ilanları merkez ve Akçakoca ayrımıyla listelenir. Sahildeki Akçakoca ile ovadaki merkez arasında kırk dakikalık bir yol bulunur, plan gerekir.",
    sections: [
      {
        heading: "Merkez ovada, Akçakoca sahilde",
        body: "Düzce merkezi düz bir ovada kurulu derli toplu bir şehirdir ve otoyola yakındır. Akçakoca ise kuzeyde, Karadeniz kıyısındadır ve merkeze araçla yaklaşık kırk dakika uzaklıktadır. Listede bu iki noktayı ayırt etmek ulaşım planını değiştirir.",
      },
      {
        heading: "İstanbul ve Ankara arasında bir durak",
        body: "Düzce, İstanbul'a yaklaşık iki buçuk, Ankara'ya ise üç saat uzaklıktadır ve otoyol üzerindeki konumu şehri bir ara durak haline getirir. Yaz hafta sonlarında Akçakoca ve Yedigöller yönünde günübirlik ziyaretçi akışı artar, kışın ise tempo merkeze döner.",
      },
      {
        heading: "Otoyol ana giriş noktasıdır",
        body: "Düzce'nin havalimanı yoktur; şehre ulaşım neredeyse tamamen TEM ve D-100 üzerinden sağlanır. İstanbul'a yaklaşık iki buçuk, Ankara'ya üç saatte ulaşılır. Otogar merkeze yakındır ve Akçakoca seferleri buradan sık aralıklarla kalkar.",
      },
    ],
  },
};

export function cityEscortEssay(city: City) {
  const label = `${city.name.toLocaleLowerCase("tr-TR")} escort`;
  const districts = mainDistricts(city.slug);
  const list = joinTr(districts);
  const content = cityContent(city);
  const fact = firstSentence(content.sections[0]?.body || content.description || city.blurb);
  if (districts.length < 2) {
    const open = pick(city.slug, 4, [
      `${city.name} küçük bir il. ${label} ilanı merkezde toplanır, başka ilçe aramam.`,
      `${label} kaydı ${city.name} merkezinde durur. Şehir dağılmadığı için yol da kısalır.`,
      `${city.name} merkezinin dışına çıkmadan ${label} ilanını okurum.`,
      `${label} için ${city.name} denince tek durak vardır: merkez.`,
    ]);
    const mid = pick(city.slug, 5, [
      `İlçe adı ayrıca yazılmasa da yer bellidir. ${city.name} içinde adres, merkezin neresi olduğunu söyler.`,
      `${city.region} tarafında ${city.name} kendi halinde kalır. ${label} araması da bu dar alana sığar.`,
      `Saati tutturmak burada ilçeden değil, merkezin hangi tarafından buluşulacağından çıkar.`,
      `${city.name} sayfasında uzun bir ilçe listesi beklemem. ${label} ilanı merkezle birlikte okunur.`,
    ]);
    const close = pick(city.slug, 6, [
      `${label} ilanında mahalleyi yazmak, bu ilde yeter.`,
      `Kısa yazan, ${city.name} merkezinde hangi tarafta olduğunu da yazar.`,
      `${label} kaydını açınca merkeze bir kez daha bakarım.`,
    ]);
    return `${open} ${fact} ${mid} ${offerLine(city, label, list)} ${close}`.replace(/\s+/g, " ").trim();
  }
  const open = pick(city.slug, 1, [
    `${label} bakarken tek bir sokağa sıkışmamak gerekir. ${list} bu ilde ayrı ayrı aranır.`,
    `${city.name} içinde ${label} ilanı açan kişi önce ${list} ayrımını görür.`,
    `Ben ${city.name} sayfasını ${list} üzerinden okurum. ${label} araması da bu ilçelerde toplanır.`,
    `${list}, ${city.name} escort ilanında en çok karşıma çıkan ilçeler. ${label} yazısı bu ilçelerden birine düşer.`,
    `${city.name} küçük bir nokta değil. ${label} ilanı ${list} tarafında ayrı durur.`,
    `${label} için ${city.name} denince aklıma önce ${list} gelir.`,
    `Sayfayı ${list} diye ayırırım. ${city.name} escort arayan kişi de aynı ayrımı görsün diye.`,
    `${city.name} escort vitrininde ${list} yan yana durmaz. ${label} kaydı hangi ilçedeyse orada okunur.`,
  ]);
  const mid = pick(city.slug, 2, [
    `${districts[0]} ile ${districts[1]} aynı ilin içindedir ama yol aynı değildir. Akşam saatinde birinden diğerine geçmek, mesajda yazılan saati kaydırır.`,
    `${city.region} bölgesinde ${city.name} kendi temposunu tutar. ${list} içinden birini seçmeden yola çıkmam.`,
    `İlçe yazılmamış bir ${label} ilanı bana eksik gelir. ${list} gibi duraklar birbirinin yerine geçmez.`,
    `${city.name} merkezine yakın olanla dışarıda kalan ilçe aynı yazıda eritilmemeli. ${list} bu yüzden ayrı anılır.`,
    `Buluşma yerini ${districts[0] || "merkez"} sanıp ${districts[districts.length - 1] || "başka ilçe"} çıkması, ${city.name} içinde en sık olan karışıklıktır.`,
    `${list} arasında tercih, fotoğraftan önce gelir. ${city.name} böyle okununca ${label} ilanı da yerine oturur.`,
    `Gündüz sakin olan ilçe akşam başka dolar. ${city.name} için bunu ${list} hattında görürsün.`,
    `${city.name} sayfasında ilçe adı süs değildir. ${list} gerçekten ayrı yerlerdir.`,
  ]);
  const close = pick(city.slug, 3, [
    `${label} ilanında ilçe baştan yazılırsa yol uzamaz.`,
    `Kısa yazan, ${city.name} içinde hangi ilçede olduğunu da yazar.`,
    `${label} kaydını açınca ilçeye bir kez daha bakarım.`,
    `Saat tutsun istiyorsan ${city.name} ilçesini mesajın ilk cümlesine koy.`,
    `${label} araması ilçe ile birlikte yapılınca liste sadeleşir.`,
    `${city.name} içinde kaybolmamak, ilçeyi baştan söylemekten geçer.`,
  ]);
  return `${open} ${fact} ${mid} ${offerLine(city, label, list)} ${close}`.replace(/\s+/g, " ").trim();
}

function offerLine(city: City, label: string, list: string) {
  return pick(city.slug, 7, [
    `${label} bayanlar elden ödemeyle çalışır. Adresinize gelir ya da kendi evinde görüşme sağlar. Görüntüler gerçektir.`,
    `Escort bayanlar ${city.name} içinde elden ödeme alır. İsterseniz sizin adresinize gelir, isterseniz kendi evinde buluşursunuz. Fotoğraflar gerçek.`,
    `${list} tarafındaki escort bayanlar elden ödemelidir. Eve gelirler, olmazsa kendi evinde görüşme ayarlarlar. Görseller gerçek, başkasına ait değildir.`,
    `${city.name} escort bayanlar kapıda pazarlık açmaz. Ödeme elden yapılır. Adresinize gelir ya da kendi evinde ağırlar. Görüntüler ilandaki kişiye aittir.`,
    `Elden ödeme bu sayfada esastır. ${label} bayanlar adresinize gelir, istemezseniz görüşme kendi evinde olur. Görüntüler gerçektir.`,
    `${label} ilanındaki bayanlar elden ödemeyle yazar. Buluşma sizin adresinizde de olur, kendi evinde de. Fotoğraflar gerçek görüntüdür.`,
  ]);
}

function mainDistricts(slug: string) {
  const all = districtsFor(slug);
  const named = all.filter((item) => item !== "Merkez");
  return (named.length ? named : all).slice(0, 3);
}

function joinTr(items: string[]) {
  if (items.length <= 1) return items[0] || "merkez";
  if (items.length === 2) return `${items[0]} ve ${items[1]}`;
  return `${items.slice(0, -1).join(", ")} ve ${items[items.length - 1]}`;
}

function firstSentence(text: string) {
  const sentence = text.split(/(?<=\.)\s/)[0]?.trim() || "";
  return sentence.endsWith(".") ? sentence : `${sentence}.`;
}

function pick(seed: string, salt: number, list: string[]) {
  let n = salt + 13;
  for (let i = 0; i < seed.length; i += 1) n = (n * 33 + seed.charCodeAt(i)) >>> 0;
  return list[n % list.length];
}

export function listingCityArticle(cityName: string, listingName: string, section: CitySection) {
  return `${listingName}, ${cityName} escort sayfasında kendi ilanıyla durur. ${section.heading}. ${section.body}`.replace(/\s+/g, " ").trim();
}

export function cityContent(city: City): CityContent {
  return (
    CITY_CONTENT[city.slug] ?? {
      description: city.blurb,
      sections: [],
    }
  );
}
