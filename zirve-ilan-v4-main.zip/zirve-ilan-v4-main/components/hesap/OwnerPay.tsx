"use client";

import { ListingPulse } from "@/components/hesap/ListingPulse";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatUsd, PAY_PLANS, type PayPlan } from "@/lib/pay-plans";

type PayState = "none" | "waiting" | "rejected";

type Item = {
  id: string;
  displayName: string;
  category: string;
  ended: boolean;
  live: boolean;
  hidden: boolean;
  payment: PayState;
  plan: PayPlan | null;
  amountUsd: number | null;
  note: string;
  startedAt: string | null;
  expiresAt: string | null;
  waToday: number;
  waWeek: number;
};

export function OwnerPay({ items, address }: { items: Item[]; address: string }) {
  const router = useRouter();
  const due = items.filter((item) => item.ended && item.payment !== "waiting");
  const [open, setOpen] = useState(due.length > 0);
  const [selected, setSelected] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [plan, setPlan] = useState<PayPlan | null>(null);
  const [note, setNote] = useState("");

  const current = items.find((item) => item.id === selected) ?? null;

  function openPay(id: string) {
    setSelected(id);
    setError("");
    setCopied(false);
    setPlan(null);
    setNote("");
    setOpen(true);
  }

  async function markPaid() {
    if (!current) return;
    if (!plan) {
      setError("1 hafta veya 1 ay seç.");
      return;
    }
    setBusy(true);
    setError("");
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listingId: current.id, plan, note }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(json.error || "Kaydedilemedi.");
      return;
    }
    setSelected(null);
    setOpen(false);
    router.refresh();
  }

  async function copyAddress() {
    try {
      await navigator.clipboard.writeText(address);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <>
      {items.length ? (
        items.map((item) => (
          <article className="panel-card owner-listing" key={item.id}>
            <div className="panel-row">
              <div>
                <h2>{item.displayName}</h2>
                <p className="muted">
                  {item.category} ·{" "}
                  {item.live
                    ? "Yayında"
                    : item.hidden
                      ? "Gizli"
                      : item.ended && item.payment === "waiting"
                        ? "Onay bekleniyor"
                        : item.ended
                          ? "Süresi doldu"
                          : "Taslak"}
                </p>
              </div>
              <div className="row-actions">
                {item.ended ? (
                  <button className="btn" type="button" onClick={() => openPay(item.id)}>
                    {item.payment === "waiting" ? "Ödeme durumu" : "Ödeme yap"}
                  </button>
                ) : null}
                <a className="btn ghost" href={`/hesap/ilan/${item.id}/`}>
                  Düzenle
                </a>
              </div>
            </div>
            <ListingPulse startedAt={item.startedAt} expiresAt={item.expiresAt} waToday={item.waToday} waWeek={item.waWeek} />
          </article>
        ))
      ) : (
        <div className="panel-card">
          <p>Sana henüz ilan atanmadı. Yönetici ilanı açıp bu hesaba tanımlar.</p>
        </div>
      )}

      {open ? (
        <div className="pay-modal" role="dialog" aria-modal="true" aria-labelledby="pay-title">
          <div className="pay-card">
            {!current ? (
              <>
                <p className="eyebrow">Süre doldu</p>
                <h2 id="pay-title">İlanın bitti</h2>
                <p>Yayında kalması için Bitcoin TRC20 ile ödeme yap. 1 hafta {formatUsd(PAY_PLANS.week.amountUsd)}, 1 ay {formatUsd(PAY_PLANS.month.amountUsd)}.</p>
                <ul className="pay-list">
                  {due.map((item) => (
                    <li key={item.id}>
                      <span>{item.displayName}</span>
                      <button className="btn" type="button" onClick={() => openPay(item.id)}>
                        Ödeme yap
                      </button>
                    </li>
                  ))}
                </ul>
                <button className="btn ghost" type="button" onClick={() => setOpen(false)}>
                  Kapat
                </button>
              </>
            ) : current.payment === "waiting" ? (
              <>
                <p className="eyebrow">{current.displayName}</p>
                <h2 id="pay-title">Yönetici onayı bekleniyor</h2>
                <p>
                  {current.plan ? `${PAY_PLANS[current.plan].label} · ${formatUsd(current.amountUsd || PAY_PLANS[current.plan].amountUsd)}` : "Ödeme bildirimin alındı."} Onaylandığı saatten itibaren seçilen süre başlar ve aynı saatte biter.
                </p>
                {current.note ? <p>Not: {current.note}</p> : null}
                <button className="btn ghost" type="button" onClick={() => setOpen(false)}>
                  Kapat
                </button>
              </>
            ) : (
              <>
                <p className="eyebrow">{current.displayName}</p>
                <h2 id="pay-title">Bitcoin TRC20 ile ödeme</h2>
                <p>Süreyi seç, tutarı TRC20 ağıyla gönder. Adres T ile başlar.</p>
                {current.payment === "rejected" ? <p className="err">Önceki bildirim reddedildi. Yeniden bildirebilirsin.</p> : null}
                {address ? (
                  <div className="pay-address">
                    <code>{address}</code>
                    <button className="btn ghost" type="button" onClick={copyAddress}>
                      {copied ? "Kopyalandı" : "Adresi kopyala"}
                    </button>
                  </div>
                ) : (
                  <p className="err">Ödeme adresi henüz tanımlanmadı. Yönetici adres ekleyince burada görünür.</p>
                )}
                <div className="pay-plans">
                  {(Object.keys(PAY_PLANS) as PayPlan[]).map((id) => (
                    <button key={id} className={plan === id ? "pay-plan on" : "pay-plan"} type="button" onClick={() => setPlan(id)}>
                      <strong>{PAY_PLANS[id].label}</strong>
                      <span>{formatUsd(PAY_PLANS[id].amountUsd)}</span>
                    </button>
                  ))}
                </div>
                <label className="pay-note-label">
                  Ödeme notu
                  <textarea className="pay-note" maxLength={300} value={note} placeholder="İsteğe bağlı. İşlem notu yazabilirsin." onChange={(event) => setNote(event.target.value)} />
                </label>
                {error ? <p className="err">{error}</p> : null}
                <div className="row-actions">
                  <button className="btn" type="button" disabled={busy || !address || !plan} onClick={markPaid}>
                    {busy ? "Kaydediliyor" : plan ? `Ödeme yaptım · ${formatUsd(PAY_PLANS[plan].amountUsd)}` : "Ödeme yaptım"}
                  </button>
                  <button className="btn ghost" type="button" onClick={() => setSelected(null)}>
                    Geri
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      ) : null}
    </>
  );
}
