import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { reorderListings } from "@/lib/store";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json()) as { ids?: string[] };
  if (!body.ids?.length) return NextResponse.json({ error: "Sıra listesi yok." }, { status: 400 });
  return NextResponse.json(reorderListings(body.ids));
}
