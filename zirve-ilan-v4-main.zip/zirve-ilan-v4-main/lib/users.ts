import { randomUUID } from "crypto";
import path from "path";
import { readJsonFile, writeJsonFile } from "./json-file";
import { sessionUserId } from "./session-token";

export type Owner = {
  id: string;
  username: string;
  passwordHash: string;
  name: string;
  createdAt: string;
};

const file = path.join(process.cwd(), "data", "users.json");

function readUsers(): Owner[] {
  const raw = readJsonFile<Owner[]>(file, []);
  return Array.isArray(raw) ? raw : [];
}

function writeUsers(users: Owner[]) {
  writeJsonFile(file, users);
}

export function getOwners() {
  return readUsers();
}

export function ownerById(id: string) {
  return readUsers().find((item) => item.id === id) ?? null;
}

export function ownerByUsername(username: string) {
  return readUsers().find((item) => item.username.toLocaleLowerCase("tr-TR") === username.trim().toLocaleLowerCase("tr-TR")) ?? null;
}

function validUsername(username: string) {
  return /^[\p{L}\p{N}._-]{3,32}$/u.test(username);
}

export function createOwner(input: { username: string; name: string }) {
  const username = input.username.trim();
  if (!validUsername(username)) return { error: "Kullanıcı adı 3-32 karakter olmalı." as const };
  const users = readUsers();
  if (ownerByUsername(username)) return { error: "Bu kullanıcı adı var." as const };
  const owner: Owner = {
    id: randomUUID(),
    username,
    passwordHash: "",
    name: input.name.trim() || username,
    createdAt: new Date().toISOString(),
  };
  users.push(owner);
  writeUsers(users);
  return { owner };
}

export function deleteOwner(id: string) {
  const users = readUsers();
  const index = users.findIndex((item) => item.id === id);
  if (index < 0) return { error: "Hesap yok." as const };
  users.splice(index, 1);
  writeUsers(users);
  return { ok: true as const };
}

export function verifyOwnerLogin(username: string) {
  const name = username.trim();
  if (!validUsername(name)) return null;
  return ownerByUsername(name);
}

export async function ownerFromToken(token: string | undefined) {
  const userId = await sessionUserId(token);
  if (!userId) return null;
  return ownerById(userId);
}
