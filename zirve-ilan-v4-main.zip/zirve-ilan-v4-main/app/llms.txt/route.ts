import { cities } from "@/lib/cities";
import { getSettings } from "@/lib/settings";
import { cityPagePath, rehberOrigin, rehberUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export function GET() {
  const origin = rehberOrigin();
  const lines = [
    "# Zirve Rehber",
    "",
    `> ${getSettings().rehberDescription}`,
    "",
    "Türkiye'nin 81 ili için escort ilan rehberi. Her ilin kendi sayfası vardır. İlanı açınca fotoğraf, yaş ve iletişim numarası görünür. Yazışma doğrudan ilan sahibiyle kurulur. Buluşma ve ödeme elden yapılır.",
    "",
    "## Sayfalar",
    "",
    `- [Ana sayfa](${origin}/): 81 ilin güncel ilanları ve sık sorulan sorular`,
    ...cities.map((city) => `- [${city.name} escort](${rehberUrl(cityPagePath(city.slug))}): ${city.name} ilanları, ${city.region}`),
    "",
    "## Kaynak",
    "",
    `- [Site haritası](${origin}/sitemap.xml)`,
    "",
  ];
  return new Response(lines.join("\n"), {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "public, max-age=3600",
    },
  });
}
