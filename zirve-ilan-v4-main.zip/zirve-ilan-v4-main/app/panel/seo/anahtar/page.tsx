import { CityKeywordsForm } from "@/components/panel/CityKeywords";
import { allCityKeywords } from "@/lib/seo-keywords";

export const dynamic = "force-dynamic";

export default function CityKeywordsPage() {
  const cities = allCityKeywords();
  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Seo ayarları</p>
          <h1>Anahtar kelimeler</h1>
          <p className="muted">Her ilin kendi kelimeleri vardır. İl, gerçek escort ve en büyük ilçeler hazır gelir. Yeni kelime ekleyip var olanı silebilirsin.</p>
        </div>
      </div>
      <CityKeywordsForm cities={cities} />
    </>
  );
}
