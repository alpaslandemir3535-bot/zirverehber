import type { MetadataRoute } from "next";
import { headers } from "next/headers";
import { cities } from "@/lib/cities";
import { isListingLive } from "@/lib/listing-types";
import { cityPosts } from "@/lib/seo";
import { cityPagePath, rehberOrigin, rehberUrl, resolveSite } from "@/lib/site";
import { getAllListings } from "@/lib/store";

function stamp(value?: string | number) {
  if (!value) return undefined;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? undefined : date;
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const host = (await headers()).get("host");
  const site = resolveSite(host);

  if (site !== "rehber") return [];

  // lastmod yalnızca gerçekten değişen sayfa için yazılır. Tüm ilanlar her ili kapsadığı için
  // ilan güncellemesi 81 sayfanın hepsine aynı günü basardı; Google toplu damgayı güvenilmez sayıp
  // alanı yok sayar. Ana sayfa vitrinin son değişimini taşır, il sayfası yalnızca o ilin kayıtlı
  // yazısı değişince tarih alır, tarihi bilinmeyen sayfada alan hiç yazılmaz.
  let newestOverall = 0;
  for (const listing of getAllListings()) {
    if (!isListingLive(listing)) continue;
    const at = new Date(listing.updatedAt).getTime();
    if (Number.isFinite(at) && at > newestOverall) newestOverall = at;
  }
  const home: MetadataRoute.Sitemap = [
    {
      url: `${rehberOrigin()}/`,
      lastModified: stamp(newestOverall),
      changeFrequency: "hourly",
      priority: 1,
    },
  ];

  const postsByCity = new Map(cities.map((city) => [city.slug, cityPosts(city)]));
  const newestPost = (slug: string) =>
    (postsByCity.get(slug) ?? []).reduce((max, post) => {
      const at = post.updatedAt ? new Date(post.updatedAt).getTime() : 0;
      return Number.isFinite(at) && at > max ? at : max;
    }, 0) || undefined;

  const cityPages = cities.map((city) => ({
    url: rehberUrl(cityPagePath(city.slug)),
    lastModified: stamp(newestPost(city.slug)),
    changeFrequency: "daily" as const,
    priority: 0.9,
  }));

  const postPages = cities.flatMap((city) =>
    cityPosts(city).map((post) => ({
      url: rehberUrl(post.path),
      lastModified: stamp(post.updatedAt),
      changeFrequency: "weekly" as const,
      priority: 0.5,
    })),
  );

  return [...home, ...cityPages, ...postPages];
}
