"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  shuffleListings: boolean;
  rotatePhotos: boolean;
  expiryNotifyDays: number;
};

export function ListingPrefs(props: Props) {
  const router = useRouter();
  const [shuffle, setShuffle] = useState(props.shuffleListings);
  const [rotate, setRotate] = useState(props.rotatePhotos);
  const [days, setDays] = useState(String(props.expiryNotifyDays));
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ shuffleListings: shuffle, rotatePhotos: rotate, expiryNotifyDays: Number(days) }),
    });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Kaydedildi." : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <label className="check-line">
        <input type="checkbox" checked={shuffle} onChange={(event) => setShuffle(event.target.checked)} />
        Her yenilemede ilanları karıştır
      </label>
      <label className="check-line">
        <input type="checkbox" checked={rotate} onChange={(event) => setRotate(event.target.checked)} />
        İlan fotoğrafları 2 saniyede bir dönsün
      </label>
      <label>
        Bitime kaç gün kala haber ver
        <input type="number" min={1} max={14} value={days} onChange={(event) => setDays(event.target.value)} />
      </label>
      <div>
        <button className="btn" type="submit" disabled={busy}>
          {busy ? "Kaydediliyor" : "Kaydet"}
        </button>
      </div>
      {message ? <p className="full">{message}</p> : null}
    </form>
  );
}
