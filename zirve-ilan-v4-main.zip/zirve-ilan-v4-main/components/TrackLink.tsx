"use client";

import { trackClient } from "@/components/AnalyticsBeacon";
import type { ReactNode } from "react";

export function TrackLink({
  href,
  type,
  listingId,
  city,
  className,
  children,
  target,
}: {
  href: string;
  type: "listing" | "whatsapp";
  listingId: string;
  city?: string;
  className?: string;
  children: ReactNode;
  target?: string;
}) {
  return (
    <a
      href={href}
      className={className}
      target={target}
      rel={target === "_blank" ? "noreferrer" : undefined}
      onClick={() => trackClient(type, listingId, city)}
    >
      {children}
    </a>
  );
}
