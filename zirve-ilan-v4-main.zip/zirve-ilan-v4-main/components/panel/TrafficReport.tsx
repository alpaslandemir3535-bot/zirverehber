"use client";

import { useState } from "react";
import type { TrafficSlice } from "@/lib/analytics";

type Span = "today" | "week" | "month";

const SPANS: { id: Span; label: string }[] = [
  { id: "today", label: "Günlük" },
  { id: "week", label: "Haftalık" },
  { id: "month", label: "Aylık" },
];

function Row({ label, value }: { label: string; value: number }) {
  return (
    <li>
      <span>{label}</span>
      <strong>{value.toLocaleString("tr-TR")}</strong>
    </li>
  );
}

export function TrafficReport({ stats }: { stats: Record<Span, TrafficSlice> }) {
  const [span, setSpan] = useState<Span>("today");
  const data = stats[span];
  const people = data.mobile + data.desktop;

  return (
    <>
      <div className="span-picks" role="group" aria-label="Giriş aralığı">
        {SPANS.map((item) => (
          <button key={item.id} type="button" className={span === item.id ? "btn" : "btn secondary"} onClick={() => setSpan(item.id)}>
            {item.label}
          </button>
        ))}
      </div>
      <section className="dash-grid">
        <div className="panel-card">
          <h2>Cihaz</h2>
          <ul className="stat-list">
            <Row label="Mobil" value={data.mobile} />
            <Row label="Masaüstü" value={data.desktop} />
            <Row label="Toplam kişi" value={people} />
          </ul>
        </div>
        <div className="panel-card">
          <h2>Nereden geldi</h2>
          <ul className="stat-list">
            <Row label="Doğrudan" value={data.direct} />
            <Row label="Google araması" value={data.google} />
            <Row label="Diğer arama" value={data.arama} />
            <Row label="Başka siteden" value={data.yonlendirme} />
          </ul>
        </div>
      </section>
    </>
  );
}
