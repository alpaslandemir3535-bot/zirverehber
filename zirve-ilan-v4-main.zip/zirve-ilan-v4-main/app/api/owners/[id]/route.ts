import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { detachOwner } from "@/lib/store";
import { deleteOwner } from "@/lib/users";
import { NextResponse } from "next/server";

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const result = deleteOwner(id);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  const detached = detachOwner(id);
  return NextResponse.json({ ok: true, detached });
}
