import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { parseLedgerAmount } from "@/lib/ledger";
import { deleteMarketProduct, updateMarketProduct } from "@/lib/market";
import { NextResponse } from "next/server";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Ctx) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const body = (await request.json().catch(() => null)) as {
    name?: string;
    priceUsd?: unknown;
    stock?: unknown;
    image?: string;
    active?: boolean;
  } | null;
  let priceUsd: number | undefined;
  if (body?.priceUsd != null && body.priceUsd !== "") {
    if (Number(body.priceUsd) === 0) priceUsd = 0;
    else {
      const parsed = parseLedgerAmount(body.priceUsd);
      if (parsed == null) return NextResponse.json({ error: "Fiyat geçersiz." }, { status: 400 });
      priceUsd = parsed;
    }
  }
  const stock = body?.stock == null || body.stock === "" ? undefined : Number(body.stock);
  const result = updateMarketProduct(id, {
    name: body?.name,
    priceUsd,
    stock,
    image: body?.image,
    active: body?.active,
  });
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: Request, { params }: Ctx) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const result = deleteMarketProduct(id);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}
