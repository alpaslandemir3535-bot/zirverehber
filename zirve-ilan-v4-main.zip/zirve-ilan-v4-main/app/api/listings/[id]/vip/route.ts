import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { setListingFeatured } from "@/lib/store";
import { NextResponse } from "next/server";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(request: Request, { params }: Ctx) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const body = (await request.json().catch(() => null)) as { featured?: boolean } | null;
  if (!body || typeof body.featured !== "boolean") return NextResponse.json({ error: "Eksik." }, { status: 400 });
  const listing = setListingFeatured(id, body.featured);
  if (!listing) return NextResponse.json({ error: "İlan yok." }, { status: 404 });
  return NextResponse.json(listing);
}
