import { formatClock, remainingText } from "./listing-clock";
import { isListingLive } from "./listing-types";
import { getSettings, saveSettings } from "./settings";
import { markExpiryNotices, readListings } from "./store";
import { sendTelegramMessage } from "./telegram";
import { ownerById } from "./users";

const DAY = 24 * 60 * 60 * 1000;

export function expiryLabel(iso: string) {
  const when = formatClock(iso);
  if (new Date(iso).getTime() <= Date.now()) return `${when} saatinde doldu`;
  return `${remainingText(iso)} kaldı · ${when}`;
}

export function expiringListings(days = getSettings().expiryNotifyDays || 2) {
  const now = Date.now();
  const horizon = now + days * DAY;
  return readListings().filter((item) => {
    if (!isListingLive(item) || !item.expiresAt) return false;
    const at = new Date(item.expiresAt).getTime();
    return at > now && at <= horizon;
  });
}

export async function notifyExpiringListings() {
  const due = expiringListings().filter((item) => !item.expiryNoticeAt);
  if (!due.length) return { ok: true as const, sent: 0 };

  const lines = due.slice(0, 30).map((item) => {
    const owner = item.ownerId ? ownerById(item.ownerId) : null;
    const who = owner ? owner.username : "sahip atanmamış";
    return `• ${item.displayName} — ${expiryLabel(item.expiresAt || "")} — ${who}${item.phone ? ` — ${item.phone}` : ""}`;
  });
  const result = await sendTelegramMessage(["İlan süresi bitiyor", ...lines].join("\n"), { stamp: false });
  if (!result.ok) {
    if (result.error === "Bot token veya chat id yok.") return { ok: true as const, sent: 0, skipped: true as const };
    return result;
  }
  const at = new Date().toISOString();
  markExpiryNotices(due.map((item) => item.id), at);
  saveSettings({ lastExpiryNotifyAt: at });
  return { ok: true as const, sent: due.length };
}
