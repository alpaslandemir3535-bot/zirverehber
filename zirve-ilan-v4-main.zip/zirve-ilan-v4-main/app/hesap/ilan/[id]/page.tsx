import { ListingPulse } from "@/components/hesap/ListingPulse";
import { ListingForm } from "@/components/panel/ListingForm";
import { whatsappForListing } from "@/lib/analytics";
import { ownerTokenFromCookie } from "@/lib/auth";
import { listingById } from "@/lib/store";
import { ownerFromToken } from "@/lib/users";
import { notFound, redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function OwnerEditPage({ params }: { params: Promise<{ id: string }> }) {
  const owner = await ownerFromToken(await ownerTokenFromCookie());
  if (!owner) redirect("/hesap/login/");
  const { id } = await params;
  const listing = listingById(id);
  if (!listing || listing.ownerId !== owner.id) notFound();
  const wa = whatsappForListing(listing.id);

  return (
    <>
      <div className="panel-row">
        <h1>İlanı düzenle</h1>
        <a className="btn secondary" href="/hesap/">
          Listeye dön
        </a>
      </div>
      <section className="panel-card owner-listing">
        <ListingPulse
          startedAt={listing.startedAt}
          expiresAt={listing.expiresAt}
          waToday={wa.today}
          waWeek={wa.week}
        />
      </section>
      <ListingForm listing={listing} mode="owner" redirectTo="/hesap/" />
    </>
  );
}
