import { isAdmin } from "@/lib/auth";
import { cities } from "@/lib/cities";
import { seoPostsForCity } from "@/lib/seo-store";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const citySlug = new URL(request.url).searchParams.get("city");
  const city = cities.find((item) => item.slug === citySlug);
  if (!city) return NextResponse.json({ error: "Şehir seç." }, { status: 400 });
  return NextResponse.json(seoPostsForCity(city));
}
