import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { decideMarketOrder } from "@/lib/market";
import { NextResponse } from "next/server";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(request: Request, { params }: Ctx) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const body = (await request.json().catch(() => null)) as { action?: string; delivery?: string } | null;
  if (body?.action !== "approve" && body?.action !== "reject") {
    return NextResponse.json({ error: "İşlem seç." }, { status: 400 });
  }
  const result = decideMarketOrder(id, body.action, body.delivery);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true, status: result.order.status });
}
