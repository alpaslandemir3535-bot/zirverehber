import { randomUUID } from "crypto";
import { existsSync, readFileSync } from "fs";
import path from "path";
import { writeJsonFile } from "./json-file";
import { PAY_PLANS, type MoneyCurrency, type PayPlan } from "./pay-plans";

export type LedgerKind = "income" | "expense";

export type LedgerEntry = {
  id: string;
  kind: LedgerKind;
  amountUsd: number;
  currency: MoneyCurrency;
  note: string;
  at: string;
  source: "payment" | "manual";
  paymentId: string | null;
  ownerUsername: string;
};

export type MoneySplit = { usd: number; tl: number };

export type LedgerBoard = {
  label: string;
  income: MoneySplit;
  expense: MoneySplit;
  net: MoneySplit;
  entries: LedgerEntry[];
};

const file = path.join(process.cwd(), "data", "ledger.json");

function readLedger(): LedgerEntry[] {
  if (!existsSync(file)) return [];
  try {
    const raw = JSON.parse(readFileSync(file, "utf8")) as unknown;
    if (!Array.isArray(raw)) return [];
    return raw.filter(isEntry).map((item) => ({
      ...item,
      ownerUsername: typeof item.ownerUsername === "string" ? item.ownerUsername : "",
      currency: item.currency === "tl" ? "tl" : "usd",
    }));
  } catch {
    return [];
  }
}

function writeLedger(items: LedgerEntry[]) {
  writeJsonFile(file, items);
}

function isEntry(value: unknown): value is LedgerEntry {
  if (!value || typeof value !== "object") return false;
  const item = value as LedgerEntry;
  return (
    typeof item.id === "string" &&
    (item.kind === "income" || item.kind === "expense") &&
    typeof item.amountUsd === "number" &&
    typeof item.note === "string" &&
    typeof item.at === "string" &&
    (item.source === "payment" || item.source === "manual")
  );
}

export function istanbulYmd(date: Date) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Istanbul",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function addDays(ymd: string, days: number) {
  const [y, m, d] = ymd.split("-").map(Number);
  const next = new Date(Date.UTC(y, m - 1, d + days));
  const yy = next.getUTCFullYear();
  const mm = String(next.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(next.getUTCDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}

function mondayOf(ymd: string) {
  const [y, m, d] = ymd.split("-").map(Number);
  const weekday = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return addDays(ymd, -((weekday + 6) % 7));
}

function formatDay(ymd: string) {
  const [y, m, d] = ymd.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12)).toLocaleDateString("tr-TR", {
    timeZone: "UTC",
    day: "numeric",
    month: "long",
  });
}

function formatMonth(ymd: string) {
  const [y, m, d] = ymd.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12)).toLocaleDateString("tr-TR", {
    timeZone: "UTC",
    month: "long",
    year: "numeric",
  });
}

function roundMoney(value: number) {
  return Math.round(value * 100) / 100;
}

function split(entries: LedgerEntry[], kind: LedgerKind): MoneySplit {
  const usd = roundMoney(entries.filter((item) => item.kind === kind && item.currency !== "tl").reduce((sum, item) => sum + item.amountUsd, 0));
  const tl = roundMoney(entries.filter((item) => item.kind === kind && item.currency === "tl").reduce((sum, item) => sum + item.amountUsd, 0));
  return { usd, tl };
}

function board(entries: LedgerEntry[], label: string, start: string, end: string): LedgerBoard {
  const picked = entries
    .filter((item) => {
      const day = istanbulYmd(new Date(item.at));
      return day >= start && day <= end;
    })
    .sort((a, b) => +new Date(b.at) - +new Date(a.at));
  const income = split(picked, "income");
  const expense = split(picked, "expense");
  return {
    label,
    income,
    expense,
    net: { usd: roundMoney(income.usd - expense.usd), tl: roundMoney(income.tl - expense.tl) },
    entries: picked,
  };
}

function monthEnd(ymd: string) {
  const nextMonth = addDays(`${ymd.slice(0, 8)}01`, 32);
  return addDays(`${nextMonth.slice(0, 8)}01`, -1);
}

export function ledgerBoards(now = new Date()) {
  const today = istanbulYmd(now);
  const weekStart = mondayOf(today);
  const monthStart = `${today.slice(0, 8)}01`;
  const entries = readLedger();
  return {
    today,
    week: board(entries, `${formatDay(weekStart)} – ${formatDay(addDays(weekStart, 6))}`, weekStart, addDays(weekStart, 6)),
    month: board(entries, formatMonth(today), monthStart, monthEnd(today)),
  };
}

export function parseLedgerAmount(value: unknown) {
  const raw = typeof value === "number" ? value : Number(String(value ?? "").replace(",", "."));
  if (!Number.isFinite(raw) || raw <= 0 || raw > 100_000_000) return null;
  return roundMoney(raw);
}

export function parseLedgerDate(value: unknown, now = new Date()) {
  const ymd = typeof value === "string" && value ? value : istanbulYmd(now);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ymd)) return null;
  const today = istanbulYmd(now);
  if (ymd < "2020-01-01" || ymd > addDays(today, 366)) return null;
  return new Date(`${ymd}T09:00:00.000Z`).toISOString();
}

export function cleanLedgerNote(value: unknown, max = 300) {
  if (typeof value !== "string") return "";
  return value.replace(/[\u0000-\u001F]+/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
}

export function recordPaymentIncome(input: {
  id: string;
  listingName: string;
  ownerUsername: string;
  plan: PayPlan;
  amountUsd: number;
  note: string;
  at: string;
}) {
  const items = readLedger();
  if (items.some((item) => item.paymentId === input.id)) return;
  const plan = PAY_PLANS[input.plan].label;
  const note = [input.listingName, plan, input.note].filter(Boolean).join(" · ");
  items.unshift({
    id: randomUUID(),
    kind: "income",
    amountUsd: input.amountUsd,
    currency: "usd",
    note,
    at: input.at,
    source: "payment",
    paymentId: input.id,
    ownerUsername: input.ownerUsername,
  });
  writeLedger(items);
}

export function recordSaleIncome(input: { id: string; ownerUsername: string; amountUsd: number; note: string; at: string }) {
  const items = readLedger();
  if (items.some((item) => item.paymentId === input.id)) return;
  items.unshift({
    id: randomUUID(),
    kind: "income",
    amountUsd: input.amountUsd,
    currency: "usd",
    note: input.note,
    at: input.at,
    source: "payment",
    paymentId: input.id,
    ownerUsername: input.ownerUsername,
  });
  writeLedger(items);
}

export function addManualEntry(input: { kind: LedgerKind; amountUsd: number; currency: MoneyCurrency; note: string; at: string }) {
  const entry: LedgerEntry = {
    id: randomUUID(),
    kind: input.kind,
    amountUsd: input.amountUsd,
    currency: input.currency,
    note: input.note,
    at: input.at,
    source: "manual",
    paymentId: null,
    ownerUsername: "",
  };
  const items = readLedger();
  items.unshift(entry);
  writeLedger(items);
  return entry;
}

export function deleteManualEntry(id: string) {
  const items = readLedger();
  const current = items.find((item) => item.id === id);
  if (!current) return { error: "Kayıt yok." as const };
  if (current.source !== "manual") return { error: "Onaylı ödeme kaydı silinemez." as const };
  writeLedger(items.filter((item) => item.id !== id));
  return { ok: true as const };
}
