import { SortableList } from "@/components/panel/SortableList";
import { getDashboardStats } from "@/lib/analytics";
import { getAllListings } from "@/lib/store";

export const dynamic = "force-dynamic";

export default function ListingsAdminPage() {
  const listings = getAllListings();
  const stats = getDashboardStats();

  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Vitrin</p>
          <h1>İlanlar ({listings.length})</h1>
        </div>
        <a className="btn" href="/panel/ilan/yeni/">
          Yeni ilan
        </a>
      </div>
      <SortableList
        listings={listings}
        listingClicks={stats.month.listingTotals}
        whatsappClicks={stats.month.waTotals}
      />
    </>
  );
}
