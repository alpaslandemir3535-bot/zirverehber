export const CATEGORIES = [
  "VİP ESCORT",
  "ÜNİVERSİTELİ ESCORT",
  "ÖĞRENCİ ESCORT",
  "POPÜLER ESCORT",
  "SINIRSIZ ESCORT",
] as const;

export type Category = (typeof CATEGORIES)[number];
export type ListingStatus = "draft" | "published" | "hidden";
export type ListingDuration = "days3" | "week" | "month";

export type Listing = {
  id: string;
  slug: string;
  name: string;
  displayName: string;
  category: Category;
  phone: string;
  phoneDigits: string;
  age: number;
  height: number;
  weight: number;
  bio: string;
  cover: string;
  gallery: string[];
  cities: string[];
  districts: string[];
  ownerId: string | null;
  featured: boolean;
  gold: boolean;
  yeni: boolean;
  eldenOdeme: boolean;
  evOtelApart: boolean;
  gercekGoruntu: boolean;
  extraMarks: string[];
  sortOrder: number;
  status: ListingStatus;
  duration: ListingDuration;
  startedAt: string | null;
  expiresAt: string | null;
  createdAt: string;
  updatedAt: string;
  expiryNoticeAt?: string | null;
};

export type ListingInput = {
  name: string;
  displayName: string;
  category: Category;
  phone: string;
  age: number;
  height: number;
  weight: number;
  bio: string;
  cover: string;
  gallery: string[];
  cities: string[];
  districts: string[];
  ownerId: string | null;
  featured: boolean;
  gold: boolean;
  yeni: boolean;
  eldenOdeme: boolean;
  evOtelApart: boolean;
  gercekGoruntu: boolean;
  extraMarks: string[];
  sortOrder: number;
  status: ListingStatus;
  duration: ListingDuration;
};

export function durationMs(duration: ListingDuration) {
  if (duration === "days3") return 3 * 24 * 60 * 60 * 1000;
  if (duration === "week") return 7 * 24 * 60 * 60 * 1000;
  return 30 * 24 * 60 * 60 * 1000;
}

export function durationLabel(duration: ListingDuration) {
  if (duration === "days3") return "3 gün";
  if (duration === "week") return "1 hafta";
  return "1 ay";
}

export function isListingLive(listing: Listing, now = Date.now()) {
  if (listing.status !== "published") return false;
  if (listing.expiresAt && new Date(listing.expiresAt).getTime() <= now) return false;
  return true;
}

export function isListingEnded(listing: Listing, now = Date.now()) {
  if (listing.status !== "published" || !listing.expiresAt) return false;
  return new Date(listing.expiresAt).getTime() <= now;
}

export function toPhoneDigits(phone: string) {
  const raw = phone.trim();
  let digits = raw.replace(/\D/g, "");
  if (!digits) return "";

  const explicitIntl = raw.startsWith("+") || digits.startsWith("00");
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (explicitIntl) return digits;

  if (digits.startsWith("90") && digits.length >= 12) return digits;
  if (digits.startsWith("0") && digits.length >= 10 && digits.length <= 11) {
    return `90${digits.slice(1)}`;
  }
  if (digits.length === 10 && digits.startsWith("5")) return `90${digits}`;
  return digits;
}

export const DEFAULT_WA_LISTING_MESSAGE = "Merhaba, {ad} {sehir} Escort sayfanızdan yazıyorum.";
const LEGACY_WA_LISTING_MESSAGE = "Merhaba, {sehir} sayfanızdan yazıyorum.";

export function waListingMessageText(value?: string) {
  const text = (value || "").trim();
  if (!text || text === LEGACY_WA_LISTING_MESSAGE) return DEFAULT_WA_LISTING_MESSAGE;
  return text;
}

export function whatsappHref(listing: Listing, cityName?: string, template?: string) {
  const city = cityName?.trim() || "";
  const name = listing.name.trim() || listing.displayName.trim();
  const raw = waListingMessageText(template)
    .replaceAll("{sehir}", city)
    .replaceAll("{ad}", name)
    .replace(/[ \t]{2,}/g, " ")
    .trim();
  return `https://wa.me/${listing.phoneDigits}?text=${encodeURIComponent(raw)}`;
}

export function sortListings(items: Listing[]) {
  return [...items].sort((a, b) => {
    if (a.sortOrder !== b.sortOrder) return a.sortOrder - b.sortOrder;
    if (a.featured !== b.featured) return a.featured ? -1 : 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });
}

export function locationLabel(listing: Listing, cityName?: string, citySlug?: string) {
  const names = listing.districts
    .filter((key) => !citySlug || key.startsWith(`${citySlug}:`))
    .map((key) => key.split(":").slice(1).join(":"))
    .filter(Boolean);
  const unique = [...new Set(names)];
  if (cityName && unique.length) return `${cityName} / ${unique.join(", ")}`;
  if (cityName) return cityName;
  if (unique.length) return unique.join(", ");
  return "";
}
