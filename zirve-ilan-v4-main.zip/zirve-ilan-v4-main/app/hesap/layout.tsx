import { OwnerNav } from "@/components/hesap/OwnerNav";
import { ownerTokenFromCookie } from "@/lib/auth";
import { ownerFromToken } from "@/lib/users";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import "../panel/panel.css";

export const metadata: Metadata = {
  robots: { index: false, follow: false },
  title: "İlan sahibi",
};

export default async function OwnerLayout({ children }: { children: React.ReactNode }) {
  const owner = await ownerFromToken(await ownerTokenFromCookie());
  const gate = (await headers()).get("x-zirve-gate");
  if (gate === "owner" && !owner) redirect("/hesap/login/");

  return (
    <div className={owner ? "panel panel-app" : "panel panel-auth"}>
      {owner ? (
        <aside className="panel-side">
          <a className="panel-brand" href="/hesap/">
            <span className="panel-brand-mark">İ</span>
            <span>
              <strong>Zirve</strong>
              <em>İlan sahibi</em>
            </span>
          </a>
          <OwnerNav />
          <div className="panel-side-foot">
            <p className="muted">{owner.name}</p>
            <form action="/api/auth/logout" method="post">
              <button className="btn ghost" type="submit">
                Çıkış
              </button>
            </form>
          </div>
        </aside>
      ) : null}
      <div className={owner ? "panel-wrap" : "panel-auth-wrap"}>{children}</div>
    </div>
  );
}
