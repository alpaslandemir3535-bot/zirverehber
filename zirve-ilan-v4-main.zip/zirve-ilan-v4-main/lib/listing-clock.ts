import { durationMs, type ListingDuration } from "./listing-types";

const ISTANBUL = "Europe/Istanbul";

export function expiryFrom(startedAt: string | Date, duration: ListingDuration) {
  const start = new Date(startedAt).getTime();
  return new Date(start + durationMs(duration)).toISOString();
}

export function formatClock(iso: string) {
  return new Date(iso).toLocaleString("tr-TR", {
    timeZone: ISTANBUL,
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function remainingParts(iso: string, now = Date.now()) {
  const ms = new Date(iso).getTime() - now;
  if (ms <= 0) return { ended: true, days: 0, hours: 0, minutes: 0 };
  const minutes = Math.floor(ms / 60000);
  return {
    ended: false,
    days: Math.floor(minutes / (60 * 24)),
    hours: Math.floor((minutes % (60 * 24)) / 60),
    minutes: minutes % 60,
  };
}

export function remainingText(iso: string, now = Date.now()) {
  const left = remainingParts(iso, now);
  if (left.ended) return "Süresi doldu";
  if (left.days > 0) return `${left.days} gün ${left.hours} saat`;
  if (left.hours > 0) return `${left.hours} saat ${left.minutes} dk`;
  return `${left.minutes} dk`;
}
