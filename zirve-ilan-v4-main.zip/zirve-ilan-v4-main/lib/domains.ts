import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "fs";
import path from "path";

export type DomainConfig = {
  rehberHost: string;
  panoHost: string;
  ilanHost: string;
};

export const DEFAULT_DOMAINS: DomainConfig = {
  rehberHost: "zirverehber.com",
  panoHost: "zirvepano.xyz",
  ilanHost: "zirveilan.xyz",
};

const file = path.join(process.cwd(), "data", "domains.json");

let cache: { mtimeMs: number; domains: DomainConfig } | null = null;

export function cleanHost(value: string) {
  let raw = value.trim().toLowerCase();
  raw = raw.replace(/^https?:\/\//, "").replace(/\/.*$/, "").replace(/:\d+$/, "");
  if (raw.startsWith("www.")) raw = raw.slice(4);
  if (!/^[a-z0-9.-]{4,253}$/.test(raw)) return "";
  if (raw.includes("..") || raw.startsWith(".") || raw.endsWith(".") || raw.startsWith("-") || raw.endsWith("-")) {
    return "";
  }
  const labels = raw.split(".");
  if (labels.length < 2) return "";
  if (labels.some((label) => !label || label.length > 63 || label.startsWith("-") || label.endsWith("-"))) return "";
  if (!/^[a-z]{2,24}$/.test(labels[labels.length - 1] || "")) return "";
  return raw;
}

function normalize(input: Partial<DomainConfig> | null): DomainConfig | null {
  const rehberHost = cleanHost(input?.rehberHost || "");
  const panoHost = cleanHost(input?.panoHost || "");
  const ilanHost = cleanHost(input?.ilanHost || "");
  if (!rehberHost || !panoHost || !ilanHost) return null;
  if (new Set([rehberHost, panoHost, ilanHost]).size !== 3) return null;
  return { rehberHost, panoHost, ilanHost };
}

export function getDomains(): DomainConfig {
  try {
    const stat = statSync(file);
    if (cache && cache.mtimeMs === stat.mtimeMs) return cache.domains;
    const domains = normalize(JSON.parse(readFileSync(file, "utf8")) as Partial<DomainConfig>);
    if (!domains) return { ...DEFAULT_DOMAINS };
    cache = { mtimeMs: stat.mtimeMs, domains };
    return domains;
  } catch {
    return { ...DEFAULT_DOMAINS };
  }
}

export function saveDomains(input: Partial<DomainConfig>) {
  const domains = normalize({ ...getDomains(), ...input });
  if (!domains) return { error: "Üç alan adı da geçerli ve birbirinden farklı olmalı." as const };
  mkdirSync(path.dirname(file), { recursive: true });
  writeFileSync(file, JSON.stringify(domains, null, 2), "utf8");
  cache = null;
  if (existsSync(file)) cache = { mtimeMs: statSync(file).mtimeMs, domains };
  return domains;
}
