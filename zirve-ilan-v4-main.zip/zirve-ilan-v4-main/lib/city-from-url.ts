import { cities, cityByEscortSlug, cityBySlug } from "./cities";
import { toSlug } from "./to-slug";

export function citySlugFromLocation(pathname: string, search = "") {
  const escort = pathname.match(/\/([a-z0-9-]+)-escort(?:\/|$)/i);
  if (escort) {
    const city = cityByEscortSlug(escort[1]);
    if (city) return city.slug;
  }
  const query = search.startsWith("?") ? search.slice(1) : search;
  const sehir = new URLSearchParams(query).get("sehir")?.trim();
  if (!sehir) return null;
  const lower = sehir.toLocaleLowerCase("tr-TR");
  const byName = cities.find((city) => city.name.toLocaleLowerCase("tr-TR") === lower);
  if (byName) return byName.slug;
  return cityBySlug(toSlug(sehir))?.slug ?? null;
}
