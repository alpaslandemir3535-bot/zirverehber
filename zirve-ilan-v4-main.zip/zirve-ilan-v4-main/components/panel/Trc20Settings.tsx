"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function Trc20Settings({ trc20Address }: { trc20Address: string }) {
  const router = useRouter();
  const [address, setAddress] = useState(trc20Address);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ trc20Address: address }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    setMessage(res.ok ? "Adres kaydedildi. İlan sahipleri bu adresi görür." : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <p className="full muted">
        Süresi biten ilanda sahip bu adrese Bitcoin TRC20 gönderir. Adres T ile başlayan 34 karakter olmalı.
      </p>
      <label className="full">
        Bitcoin TRC20 adresi
        <input
          value={address}
          onChange={(event) => setAddress(event.target.value.trim())}
          placeholder="T ile başlayan TRC20 adresi"
          spellCheck={false}
          autoComplete="off"
        />
      </label>
      <div>
        <button className="btn" type="submit" disabled={busy}>
          {busy ? "Kaydediliyor" : "Adresi kaydet"}
        </button>
      </div>
      {message ? <p className="full">{message}</p> : null}
    </form>
  );
}
