import { VitrinHome } from "@/components/VitrinHome";
import { homeFaqs } from "@/lib/faq";
import { faqNode, jsonLdScript, organizationNode, websiteNode } from "@/lib/site-schema";
import { VisitorCity } from "@/components/VisitorCity";
import { getPublishedListings } from "@/lib/store";
import { getSettings } from "@/lib/settings";
import { rehberOrigin } from "@/lib/site";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const canonical = `${rehberOrigin()}/`;
  const title = "Zirve Rehber | Güncel Escort İlanları";
  const description = getSettings().rehberDescription;
  return {
    title,
    description,
    alternates: { canonical },
    robots: { index: true, follow: true },
    openGraph: {
      title,
      description,
      url: canonical,
      locale: "tr_TR",
      type: "website",
      siteName: "Zirve Rehber",
    },
  };
}

export default function RehberHomePage() {
  const live = getPublishedListings();
  const jsonLdHtml = jsonLdScript({
    "@context": "https://schema.org",
    "@graph": [organizationNode(), websiteNode(), faqNode(homeFaqs(live.length))],
  });
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLdHtml }} />
      <VisitorCity />
      <VitrinHome title="Zirve Escort" kicker="ZİRVE ESCORT - VİP - GERÇEK BAYANLAR" listings={live} />
    </>
  );
}