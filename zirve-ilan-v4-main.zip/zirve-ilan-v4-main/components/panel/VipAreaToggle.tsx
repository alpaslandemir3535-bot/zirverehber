"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function VipAreaToggle({ enabled }: { enabled: boolean }) {
  const router = useRouter();
  const [on, setOn] = useState(enabled);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(next: boolean) {
    setOn(next);
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/prefs/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ vipArea: next }),
    });
    const json = await res.json().catch(() => null);
    setBusy(false);
    setMessage(res.ok ? (next ? "VIP alanı açık." : "VIP alanı kapalı.") : json?.error || "Kaydedilemedi.");
    if (!res.ok) setOn(!next);
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card vip-toggle">
      <label className="check-line">
        <input type="checkbox" checked={on} disabled={busy} onChange={(event) => save(event.target.checked)} />
        VIP ilan alanı
      </label>
      <p className="muted">Açıkken VIP işaretli ilanlar vitrinin üstünde altın panoda durur. Kapalıyken o pano çıkmaz.</p>
      {message ? <p>{message}</p> : null}
    </form>
  );
}
