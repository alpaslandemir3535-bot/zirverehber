import type { City } from "./cities";

export type Faq = { q: string; a: string };

// Cevaplar kısa ve doğrudan; soru başlık, ilk cümle cevap. Sayılar canlı veriden gelir.
export function homeFaqs(liveCount: number): Faq[] {
  return [
    {
      q: "Zirve Rehber'de şu an kaç ilan var?",
      a: `Şu an ${liveCount} ilan yayında. İlanlar süreleri dolunca kalkar, yenilenince geri gelir; sayı bu yüzden günden güne değişir.`,
    },
    {
      q: "Hangi illerde escort ilanı bulabilirim?",
      a: "Türkiye'nin 81 ili için ayrı bir sayfa var. Sayfanın altındaki il listesinden şehrini seçip o ildeki ilanlara geçebilirsin.",
    },
    {
      q: "İlan sahibiyle nasıl iletişim kurulur?",
      a: "İlan kartına dokunup detay sayfasını aç. Orada ilanın numarası ve WhatsApp bağlantısı durur; yazışmayı doğrudan o numaradan kurarsın. Rehber araya girmez.",
    },
    {
      q: "Buluşma ve ödeme nasıl yapılır?",
      a: "Buluşma ve ödeme ilan sahibiyle yüz yüze, elden yapılır. Rehber ziyaretçiden ön ödeme istemez.",
    },
    {
      q: "Rehberde ilan nasıl verilir?",
      a: "Sayfanın üstündeki İLAN VER şeridine dokununca WhatsApp açılır. İlan süresi 3 gün, 1 hafta veya 1 ay olarak seçilir.",
    },
    {
      q: "Siteye girmek için yaş sınırı var mı?",
      a: "Evet. Site 18 yaşından küçük kullanıcılar için önerilmez ve ilanlardaki kişilerin tamamı 18 yaş ve üzerindedir.",
    },
  ];
}

export function cityFaqs(city: City, liveCount: number): Faq[] {
  return [
    {
      q: `${city.name} escort sayfasında kaç ilan var?`,
      a: `${city.name} sayfasında şu an ${liveCount} ilan yayında. ${city.name}, ${city.region} bölgesinde yer alır; ilanlar süreleri dolunca kalkar, yenilenince geri gelir.`,
    },
    {
      q: `${city.name} ilanlarıyla nasıl iletişim kurulur?`,
      a: "İlan kartına dokunup detay sayfasını aç. Orada numara ve WhatsApp bağlantısı durur; yazışma doğrudan ilan sahibiyle kurulur.",
    },
    {
      q: `${city.name} ilanlarında ödeme nasıl yapılır?`,
      a: "Buluşma ve ödeme ilan sahibiyle yüz yüze, elden yapılır. Rehber ön ödeme istemez.",
    },
  ];
}
