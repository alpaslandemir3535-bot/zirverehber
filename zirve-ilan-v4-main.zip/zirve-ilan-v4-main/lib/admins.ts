import { randomUUID } from "crypto";
import path from "path";
import { adminPassword, hashPassword, passwordsMatch } from "./auth";
import { readJsonFile, writeJsonFile } from "./json-file";
import { sessionUserId } from "./session-token";

export type Admin = {
  id: string;
  username: string;
  passwordHash: string;
  name: string;
  createdAt: string;
};

const file = path.join(process.cwd(), "data", "admins.json");

function readAdmins(): Admin[] {
  const raw = readJsonFile<Admin[]>(file, []);
  return Array.isArray(raw) ? raw : [];
}

function writeAdmins(admins: Admin[]) {
  writeJsonFile(file, admins);
}

export function ensureDefaultAdmin() {
  const admins = readAdmins();
  if (admins.length) return admins;
  if (process.env.NODE_ENV === "production" && !adminPassword()) return [];
  const admin: Admin = {
    id: randomUUID(),
    username: "admin",
    passwordHash: hashPassword(adminPassword()),
    name: "Yönetici",
    createdAt: new Date().toISOString(),
  };
  writeAdmins([admin]);
  return [admin];
}

export function getAdmins() {
  return ensureDefaultAdmin();
}

export function adminById(id: string) {
  return getAdmins().find((item) => item.id === id) ?? null;
}

export function adminByUsername(username: string) {
  return getAdmins().find(
    (item) => item.username.toLocaleLowerCase("tr-TR") === username.trim().toLocaleLowerCase("tr-TR"),
  ) ?? null;
}

export function createAdmin(input: { username: string; password: string; name: string }) {
  const admins = getAdmins();
  if (adminByUsername(input.username)) return { error: "Bu kullanıcı adı var." as const };
  const admin: Admin = {
    id: randomUUID(),
    username: input.username.trim(),
    passwordHash: hashPassword(input.password),
    name: input.name.trim() || input.username.trim(),
    createdAt: new Date().toISOString(),
  };
  admins.push(admin);
  writeAdmins(admins);
  return { admin };
}

export function updateAdmin(
  id: string,
  input: { username?: string; password?: string; name?: string },
) {
  const admins = getAdmins();
  const index = admins.findIndex((item) => item.id === id);
  if (index < 0) return { error: "Yönetici yok." as const };
  const username = input.username?.trim();
  if (username) {
    const taken = admins.some(
      (item) =>
        item.id !== id &&
        item.username.toLocaleLowerCase("tr-TR") === username.toLocaleLowerCase("tr-TR"),
    );
    if (taken) return { error: "Bu kullanıcı adı var." as const };
    admins[index].username = username;
  }
  if (input.name !== undefined) admins[index].name = input.name.trim() || admins[index].username;
  if (input.password?.trim()) admins[index].passwordHash = hashPassword(input.password);
  writeAdmins(admins);
  return { admin: admins[index] };
}

export function deleteAdmin(id: string) {
  const admins = getAdmins();
  if (admins.length <= 1) return { error: "Son yönetici silinemez." as const };
  if (!admins.some((item) => item.id === id)) return { error: "Yönetici yok." as const };
  writeAdmins(admins.filter((item) => item.id !== id));
  return { ok: true as const };
}

export function verifyAdminLogin(username: string, password: string) {
  const admin = adminByUsername(username);
  if (admin && passwordsMatch(password, admin.passwordHash)) {
    if (!admin.passwordHash.startsWith("s2.")) {
      updateAdmin(admin.id, { password });
      return adminById(admin.id);
    }
    return admin;
  }
  const envPassword = adminPassword();
  if (!envPassword || password !== envPassword) return null;
  const target = adminByUsername("admin") || admin || ensureDefaultAdmin()[0];
  if (!target) return null;
  updateAdmin(target.id, { password });
  return adminById(target.id);
}

export async function adminFromToken(token: string | undefined) {
  const userId = await sessionUserId(token);
  if (!userId) return null;
  return adminById(userId);
}

export function publicAdmin(admin: Admin) {
  const { passwordHash: _h, ...row } = admin;
  return row;
}
