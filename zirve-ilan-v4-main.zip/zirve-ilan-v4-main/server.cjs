const { createServer } = require("http");
const { parse } = require("url");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const next = require("next");

const ADMIN_COOKIE = "zirve_admin";
const OWNER_COOKIE = "zirve_owner";
const DEFAULTS = {
  rehberHost: "zirverehber.com",
  panoHost: "zirvepano.xyz",
  ilanHost: "zirveilan.xyz",
};

const rawPort = process.env.PORT || "3000";
const numericPort = Number(rawPort);
const port = Number.isFinite(numericPort) ? numericPort : 3000;

(function pinBuildDir() {
  const manifestPath = path.join(__dirname, ".next", "required-server-files.json");
  if (!fs.existsSync(manifestPath)) return;
  const data = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  if (typeof data.appDir === "string" && !data.appDir.includes(":\\") && data.appDir === __dirname.replace(/\\/g, "/")) return;
  const builtOn = "C:\\Users\\efe_c\\OneDrive\\Masaüstü\\Zirve İlan V3";
  const dir = __dirname.replace(/\\/g, "/");
  const relocate = (value) => (typeof value === "string" ? value.split(builtOn).join(dir).split("\\").join("/") : value);
  if (data.config) {
    data.config.outputFileTracingRoot = dir;
    if (data.config.turbopack) data.config.turbopack.root = dir;
  }
  data.appDir = dir;
  if (Array.isArray(data.files)) data.files = data.files.map(relocate);
  fs.writeFileSync(manifestPath, JSON.stringify(data));
})();

const app = next({ dev: false, dir: __dirname, port });
const handle = app.getRequestHandler();
const publicRoot = path.join(__dirname, "public");

const MIME = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".avif": "image/avif",
  ".ico": "image/x-icon",
  ".bmp": "image/bmp",
};

function loadDomains() {
  try {
    const raw = JSON.parse(fs.readFileSync(path.join(__dirname, "data", "domains.json"), "utf8"));
    const rehberHost = String(raw.rehberHost || DEFAULTS.rehberHost).toLowerCase();
    const panoHost = String(raw.panoHost || DEFAULTS.panoHost).toLowerCase();
    const ilanHost = String(raw.ilanHost || DEFAULTS.ilanHost).toLowerCase();
    return {
      rehberHost,
      panoHost,
      ilanHost,
      rehberOrigin: `https://${rehberHost}`,
      panoOrigin: `https://${panoHost}`,
      ilanOrigin: `https://${ilanHost}`,
    };
  } catch {
    return {
      ...DEFAULTS,
      rehberOrigin: `https://${DEFAULTS.rehberHost}`,
      panoOrigin: `https://${DEFAULTS.panoHost}`,
      ilanOrigin: `https://${DEFAULTS.ilanHost}`,
    };
  }
}

function servePublic(req, res) {
  let pathname = "/";
  try {
    pathname = decodeURIComponent(parse(req.url || "/").pathname || "/");
  } catch {
    return false;
  }
  if (!pathname.includes(".") || pathname.includes("..") || pathname.includes("\\")) return false;
  const filePath = path.normalize(path.join(publicRoot, pathname));
  const rel = path.relative(publicRoot, filePath);
  if (rel.startsWith("..") || path.isAbsolute(rel)) return false;
  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) return false;
  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, {
    "Content-Type": MIME[ext] || "application/octet-stream",
    "Cache-Control": "public, max-age=86400",
    "X-Content-Type-Options": "nosniff",
  });
  fs.createReadStream(filePath).pipe(res);
  return true;
}

function cookieValue(req, name) {
  const raw = req.headers.cookie || "";
  const match = raw.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : "";
}

function secret() {
  return process.env.ADMIN_SECRET || process.env.ADMIN_PASSWORD || "";
}

function recordExists(fileName, userId) {
  try {
    const items = JSON.parse(fs.readFileSync(path.join(__dirname, "data", fileName), "utf8"));
    return Array.isArray(items) && items.some((item) => item && item.id === userId);
  } catch {
    return false;
  }
}

function validSession(token, fileName) {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [userId, exp, stamp] = parts;
  const key = secret();
  if (!userId || !exp || !stamp || !key || !/^\d+$/.test(exp)) return false;
  if (Number(exp) < Date.now()) return false;
  const expected = crypto.createHmac("sha256", key).update(`${userId}.${exp}`).digest("base64url");
  if (expected.length !== stamp.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i += 1) diff |= expected.charCodeAt(i) ^ stamp.charCodeAt(i);
  return diff === 0 && recordExists(fileName, userId);
}

function bareHost(host) {
  return String(host || "")
    .toLowerCase()
    .replace(/:\d+$/, "")
    .replace(/^www\./, "");
}

function resolveSite(host, domains) {
  const bare = bareHost(host);
  const raw = String(host || "");
  if (bare === domains.ilanHost || raw.includes(":3002")) return "ilan";
  if (bare === domains.panoHost || bare === "vitrinpano.site" || raw.includes(":3001")) return "pano";
  if (bare === domains.rehberHost || bare === "zirverehber.site" || bare === "localhost" || bare === "127.0.0.1") {
    return "rehber";
  }
  return "pano";
}

function isLocal(host) {
  const bare = bareHost(host);
  return bare === "localhost" || bare === "127.0.0.1";
}

function isCityEscortPath(pathname) {
  return /^\/[a-z0-9-]+-escort(?:\/[a-z0-9-]+)?(?:\/amp)?\/?$/.test(pathname);
}

function isSearchBot(ua) {
  return /Googlebot|Google-InspectionTool|GoogleOther|bingbot|BingPreview|YandexBot|DuckDuckBot|Baiduspider|Slurp|Applebot|facebookexternalhit/i.test(ua || "");
}

const { browserCity, knownCity, slug: citySlug, cityForVisitor, clientIp } = require("./lib/visitor-city.cjs");
const TIKTOK_COOKIE = "zirve_tt";

// TikTok penceresi konum izni sormaz. Kayıtlı il yoksa IP'den il bulunur.
const TIKTOK_UA = /TikTok|musical_ly|BytedanceWebview|ByteLocale/i;

function isTikTokBrowser(req) {
  return TIKTOK_UA.test(String(req.headers["user-agent"] || ""));
}

function isTikTokVisit(req, search) {
  if (cookieValue(req, TIKTOK_COOKIE) === "1") return true;
  const referer = String(req.headers.referer || req.headers.referrer || "");
  try {
    const host = new URL(referer).hostname.toLowerCase();
    if (host === "tiktok.com" || host.endsWith(".tiktok.com")) return true;
  } catch {
    /* referer yok */
  }
  if (isTikTokBrowser(req)) return true;
  const params = new URLSearchParams(String(search || "").replace(/^\?/, ""));
  if (params.get("ttclid")) return true;
  return String(params.get("utm_source") || "").toLowerCase().includes("tiktok");
}

function cityCookieHeader(name, local) {
  if (!name) return "";
  const secure = local ? "" : "; Secure";
  return `zirve_konum=${encodeURIComponent(name)}; Path=/; Max-Age=2592000; SameSite=Lax; HttpOnly${secure}`;
}

function tiktokCookieHeader(local) {
  const secure = local ? "" : "; Secure";
  return `${TIKTOK_COOKIE}=1; Path=/; Max-Age=86400; SameSite=Lax; HttpOnly${secure}`;
}

function redirect(res, location, extra) {
  res.writeHead(302, {
    Location: location,
    "Cache-Control": "private, no-store",
    "CDN-Cache-Control": "no-store",
    Vary: "CF-Connecting-IP, X-Real-IP, Referer, Cookie",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    ...(extra || {}),
  });
  res.end();
}

function rewrite(req, pathname, search) {
  req.url = pathname + (search || "");
}

function citySlugFromPath(pathname) {
  const match = String(pathname || "").match(/^\/([a-z0-9-]+)-escort(?:\/|$)/);
  return match ? match[1] : "";
}

function listingsUrl(domains, cityValue, search) {
  const params = new URLSearchParams(String(search || "").replace(/^\?/, ""));
  if (cityValue) params.set("sehir", cityValue);
  const query = params.toString();
  return `${domains.panoOrigin}/ilanlar/${query ? `?${query}` : ""}`;
}

async function route(req, res) {
  const domains = loadDomains();
  const parsed = parse(req.url || "/", true);
  const pathname = parsed.pathname || "/";
  const search = parsed.search || "";
  if (pathname.startsWith("/_next") || pathname.startsWith("/api") || pathname.includes(".")) {
    return false;
  }

  if (pathname.startsWith("/panel")) {
    const isLogin = pathname.startsWith("/panel/login");
    const admin = validSession(cookieValue(req, ADMIN_COOKIE), "admins.json");
    req.headers["x-zirve-gate"] = isLogin ? "login" : "panel";
    if (!isLogin && !admin) {
      redirect(res, "/panel/login/");
      return true;
    }
    if (isLogin && admin) {
      redirect(res, "/panel/");
      return true;
    }
    return false;
  }

  if (pathname.startsWith("/hesap")) {
    const isLogin = pathname.startsWith("/hesap/login");
    const owner = validSession(cookieValue(req, OWNER_COOKIE), "users.json");
    req.headers["x-zirve-gate"] = isLogin ? "owner-login" : "owner";
    if (!isLogin && !owner) {
      redirect(res, "/hesap/login/");
      return true;
    }
    if (isLogin && owner) {
      redirect(res, "/hesap/");
      return true;
    }
    return false;
  }

  if (pathname.startsWith("/sikayet") || pathname.startsWith("/rehber") || pathname.startsWith("/vitrin")) {
    return false;
  }

  const host = req.headers.host || "";
  const site = resolveSite(host, domains);
  const local = isLocal(host);
  const bot = isSearchBot(req.headers["user-agent"]);
  const tiktok = isTikTokVisit(req, search);

  function cityPageUrl(cityName) {
    const slug = citySlug(cityName);
    if (!slug) return "";
    const cityPath = `/${slug}-escort/`;
    return local ? cityPath : `${domains.rehberOrigin}${cityPath}`;
  }

  function sendToCity(cityName, extraHeaders) {
    const location = cityPageUrl(cityName);
    if (!location) return false;
    const cookies = [cityCookieHeader(cityName, local)];
    if (tiktok) cookies.push(tiktokCookieHeader(local));
    redirect(res, location, { "Set-Cookie": cookies, ...(extraHeaders || {}) });
    return true;
  }

  // ?konum=İzmir → il sayfası. Bot/insan ayrımı yok.
  const konum = knownCity(new URLSearchParams(search.replace(/^\?/, "")).get("konum")) || "";
  if (konum && sendToCity(konum)) return true;

  if (site === "rehber") {
    if (pathname.startsWith("/ilan")) {
      if (local) {
        rewrite(req, `/vitrin${pathname}`, search);
        res.setHeader("X-Robots-Tag", "noindex, follow");
        return false;
      }
      redirect(res, `${domains.ilanOrigin}${pathname}${search}`);
      return true;
    }

    // Ana sayfa: kayıtlı il varsa o sayfaya. Yoksa ziyaretçinin kendi IP'sinden il bulunur.
    // Konum açıksa sayfa, cihazın iline geçer.
    if (pathname === "/" || pathname === "") {
      if (!bot) {
        let city = browserCity(req.headers) || "";
        if (!city) city = (await cityForVisitor(req.headers)) || "";
        if (city && sendToCity(city)) return true;
      }
      if (tiktok) res.setHeader("Set-Cookie", tiktokCookieHeader(local));
      rewrite(req, "/rehber", search);
      return false;
    }

    // /izmir-escort/ vb.: bot ve insan aynı içeriği görür.
    if (local && pathname.startsWith("/ilanlar")) {
      rewrite(req, "/vitrin/ilanlar", search);
      res.setHeader("X-Robots-Tag", "noindex, follow");
      return false;
    }
    if (tiktok) res.setHeader("Set-Cookie", tiktokCookieHeader(local));
    rewrite(req, `/rehber${pathname}`, search);
    return false;
  }

  if (site === "ilan") {
    if (pathname.startsWith("/ilan/")) {
      rewrite(req, `/vitrin${pathname}`, search);
      res.setHeader("X-Robots-Tag", "noindex, follow");
      return false;
    }
    if (isCityEscortPath(pathname)) {
      redirect(res, `${domains.rehberOrigin}${pathname}${search}`);
      return true;
    }
    if (!bot) {
      const city = browserCity(req.headers) || "";
      if (city && sendToCity(city)) return true;
    }
    if (local) {
      rewrite(req, "/vitrin/ilanlar", search);
      res.setHeader("X-Robots-Tag", "noindex, follow");
      return false;
    }
    redirect(res, listingsUrl(domains, "", search));
    return true;
  }

  // Pano domaininde *-escort yolu → herkes rehber il sayfasına.
  if (isCityEscortPath(pathname)) {
    redirect(res, `${domains.rehberOrigin}${pathname}${search}`);
    return true;
  }

  if ((pathname.startsWith("/ilan/") || pathname === "/ilan" || pathname === "/ilan/") && !local) {
    redirect(res, `${domains.ilanOrigin}${pathname}${search}`);
    return true;
  }

  // Pano ana / ilanlar: reklam doğrudan zirvepano.xyz'e geliyorsa burada kalır.
  const bareListings = pathname === "/" || pathname === "/ilanlar" || pathname === "/ilanlar/";
  if (!bot && bareListings && !new URLSearchParams(search.replace(/^\?/, "")).get("sehir")) {
    const cityValue = browserCity(req.headers) || "";
    if (cityValue) {
      const target = new URL(listingsUrl(domains, cityValue, search));
      redirect(res, local ? `${target.pathname}${target.search}` : listingsUrl(domains, cityValue, search), {
        "Set-Cookie": cityCookieHeader(cityValue, local),
      });
      return true;
    }
  }

  rewrite(req, pathname === "/" || pathname.startsWith("/ilanlar") ? "/vitrin/ilanlar" : `/vitrin${pathname}`, search);
  res.setHeader("X-Robots-Tag", "noindex, follow");
  return false;
}

function stampClientIp(req) {
  const peer = String((req.socket && req.socket.remoteAddress) || "").replace(/^::ffff:/, "");
  const behindProxy = peer === "127.0.0.1" || peer === "::1" || peer === "";
  const headerClient = clientIp(req.headers);
  const ip = behindProxy ? headerClient || "local" : peer || headerClient || "local";
  req.headers["x-zirve-ip"] = ip;
}

function bind(server) {
  if (typeof global.PhusionPassenger !== "undefined") {
    global.PhusionPassenger.configure({ autoInstall: false });
    server.listen("passenger");
    console.log("Zirve İlan passenger");
    return;
  }
  server.listen(rawPort, () => {
    console.log(`Zirve İlan ${rawPort}`);
  });
}

app
  .prepare()
  .then(() => {
    const server = createServer(async (req, res) => {
      try {
        stampClientIp(req);
        if (!res.getHeader("X-Content-Type-Options")) res.setHeader("X-Content-Type-Options", "nosniff");
        if (servePublic(req, res)) return;
        if (await route(req, res)) return;
        handle(req, res, parse(req.url, true));
      } catch (error) {
        console.error(error);
        res.statusCode = 500;
        res.end("Sunucu hatası");
      }
    });
    bind(server);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
