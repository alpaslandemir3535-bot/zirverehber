import { ownerTokenFromCookie } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { placeMarketOrder } from "@/lib/market";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { ownerFromToken } from "@/lib/users";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!rateLimit(`market:${clientIp(request)}`, 10, 15 * 60 * 1000)) {
    return NextResponse.json({ error: "Çok fazla deneme." }, { status: 429 });
  }
  const owner = await ownerFromToken(await ownerTokenFromCookie());
  if (!owner) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { productId?: string; qty?: unknown; note?: string } | null;
  if (!body?.productId) return NextResponse.json({ error: "Ürün seç." }, { status: 400 });
  const result = await placeMarketOrder({
    ownerId: owner.id,
    ownerUsername: owner.username,
    productId: body.productId,
    qty: Number(body.qty),
    note: body.note || "",
  });
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true, status: result.order.status });
}
