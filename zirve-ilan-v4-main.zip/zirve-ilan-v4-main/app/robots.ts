import type { MetadataRoute } from "next";
import { headers } from "next/headers";
import { rehberOrigin, resolveSite } from "@/lib/site";

export default async function robots(): Promise<MetadataRoute.Robots> {
  const host = (await headers()).get("host");
  const site = resolveSite(host);

  if (site !== "rehber") {
    return {
      rules: [
        {
          userAgent: "*",
          disallow: "/",
        },
      ],
    };
  }

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/panel", "/panel/", "/hesap", "/hesap/", "/sikayet", "/sikayet/", "/api", "/api/"],
      },
    ],
    sitemap: `${rehberOrigin()}/sitemap.xml`,
  };
}
