import { ListingDetail } from "@/components/ListingDetail";
import { cities } from "@/lib/cities";
import { listingBySlug } from "@/lib/store";
import { cityPagePath, rehberUrl } from "@/lib/site";
import type { Metadata } from "next";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ sehir?: string }>;
};

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug } = await params;
  const { sehir } = await searchParams;
  const listing = listingBySlug(slug);
  if (!listing) return {};
  const city = cities.find((item) => item.name === sehir);
  return {
    title: listing.displayName,
    robots: { index: false, follow: true },
    ...(city ? { alternates: { canonical: rehberUrl(cityPagePath(city.slug)) } } : {}),
  };
}

export default async function IlanPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { sehir } = await searchParams;
  const listing = listingBySlug(slug);
  if (!listing) notFound();
  const city = cities.find((item) => item.name === sehir);
  return <ListingDetail listing={listing} cityName={city?.name || sehir} />;
}
