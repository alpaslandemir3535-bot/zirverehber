import { redirect } from "next/navigation";

export default function OwnerNewListingPage() {
  redirect("/hesap/");
}
