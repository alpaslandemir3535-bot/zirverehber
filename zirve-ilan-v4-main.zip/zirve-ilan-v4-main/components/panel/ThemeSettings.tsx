"use client";

import { vitrinFontOptions, vitrinOtherDefaults, vitrinOtherFont, type VitrinOtherFont } from "@/lib/vitrin-defaults";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  vitrinBg: string;
  vitrinCard: string;
  vitrinAccent: string;
  vitrinHero: string;
  vitrinText: string;
  vitrinVip: string;
  vitrinGold: string;
  vitrinYeni: string;
  vitrinTopTier: "vip" | "gold";
  vitrinLogoText: string;
  vitrinLogoColor: string;
  vitrinBgImage: string;
  vitrinOtherTitleColor: string;
  vitrinOtherTextColor: string;
  vitrinOtherMutedColor: string;
  vitrinOtherFont: VitrinOtherFont;
  vitrinFont: VitrinOtherFont;
  vitrinProfileBg: string;
  vitrinProfileColor: string;
};

const vitrinColors = [
  { key: "vitrinBg", label: "Zemin" },
  { key: "vitrinCard", label: "Kart" },
  { key: "vitrinHero", label: "Banner" },
  { key: "vitrinAccent", label: "Vurgu" },
  { key: "vitrinText", label: "Yazı" },
  { key: "vitrinVip", label: "VIP kutu" },
  { key: "vitrinGold", label: "GOLD kutu" },
  { key: "vitrinYeni", label: "YENİ kutu" },
  { key: "vitrinProfileBg", label: "Profil zemin" },
  { key: "vitrinProfileColor", label: "Profil yazı" },
] as const;

export function ThemeSettings(props: Props) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState(props);
  const [bgImage, setBgImage] = useState(props.vitrinBgImage);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  function setColor(key: (typeof vitrinColors)[number]["key"], value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    await persist(form, "Tema kaydedildi.");
  }

  async function persist(next: Props, okText: string) {
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/prefs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(next),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    setMessage(res.ok ? okText : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  async function uploadBg(file: File) {
    setBusy(true);
    setMessage("");
    const body = new FormData();
    body.set("file", file);
    const res = await fetch("/api/theme-bg", { method: "POST", body });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setMessage(json.error || "Fotoğraf yüklenemedi.");
      return;
    }
    setBgImage(json.vitrinBgImage || "");
    setMessage("Zemin fotoğrafı temaya uygulandı.");
    router.refresh();
  }

  async function clearBg() {
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/theme-bg", { method: "DELETE" });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setMessage(json.error || "Zemin sıfırlanamadı.");
      return;
    }
    setBgImage("");
    if (fileRef.current) fileRef.current.value = "";
    setMessage("Zemin yeniden düz renge döndü.");
    router.refresh();
  }

  async function restoreOther() {
    const next = { ...form, ...vitrinOtherDefaults };
    setForm(next);
    await persist(next, "Diğer ilan yazısı varsayılana döndü.");
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <label>
        Logo yazısı
        <input
          value={form.vitrinLogoText}
          maxLength={40}
          onChange={(event) => setForm((prev) => ({ ...prev, vitrinLogoText: event.target.value }))}
        />
      </label>
      <label>
        Logo rengi
        <span className="theme-field">
          <input
            type="color"
            value={form.vitrinLogoColor}
            onChange={(event) => setForm((prev) => ({ ...prev, vitrinLogoColor: event.target.value }))}
            aria-label="Logo rengi"
          />
          <input
            value={form.vitrinLogoColor}
            onChange={(event) => setForm((prev) => ({ ...prev, vitrinLogoColor: event.target.value }))}
            spellCheck={false}
          />
        </span>
      </label>
      <p className="full muted">Logo yazısı ve rengi, vitrin zemini, banner, kart ve VIP, GOLD, YENİ kutuları buradan değişir. Zemin rengine fotoğraf eklersen düz rengin üstüne kaplanır.</p>
      {vitrinColors.map((field) => (
        <label key={field.key}>
          {field.label}
          <span className="theme-field">
            <input type="color" value={form[field.key]} onChange={(event) => setColor(field.key, event.target.value)} aria-label={field.label} />
            <input value={form[field.key]} onChange={(event) => setColor(field.key, event.target.value)} spellCheck={false} />
          </span>
        </label>
      ))}
      <div className="full">
        <p className="muted">Zemin fotoğrafı. PNG, JPG veya WEBP, en fazla 2 MB. Kaldırınca yeniden düz zemin rengi kalır.</p>
        {bgImage ? <img className="theme-bg-preview" src={bgImage} alt="Zemin fotoğrafı önizleme" /> : null}
        <label>
          Fotoğraf ekle
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void uploadBg(file);
            }}
          />
        </label>
        {bgImage ? (
          <button className="btn secondary" type="button" onClick={() => void clearBg()} disabled={busy}>
            Zemin fotoğrafını kaldır
          </button>
        ) : null}
      </div>
      <label>
        Yazı tipi
        <select
          value={form.vitrinFont}
          onChange={(event) =>
            setForm((prev) => ({
              ...prev,
              vitrinFont: vitrinOtherFont(event.target.value),
            }))
          }
        >
          {vitrinFontOptions.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>
      </label>
      <p className="full muted">Banner başlığı, üst satır ve Vitrin yazısı bu yazı tipiyle kaydolur. Yazının kendisi değişmez.</p>
      <label>
        Diğer ilan yazı tipi
        <select
          value={form.vitrinOtherFont}
          onChange={(event) =>
            setForm((prev) => ({
              ...prev,
              vitrinOtherFont: vitrinOtherFont(event.target.value),
            }))
          }
        >
          {vitrinFontOptions.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>
      </label>
      <label>
        Diğer ilan başlık rengi
        <span className="theme-field">
          <input type="color" value={form.vitrinOtherTitleColor} onChange={(event) => setForm((prev) => ({ ...prev, vitrinOtherTitleColor: event.target.value }))} aria-label="Diğer ilan başlık rengi" />
          <input value={form.vitrinOtherTitleColor} onChange={(event) => setForm((prev) => ({ ...prev, vitrinOtherTitleColor: event.target.value }))} spellCheck={false} />
        </span>
      </label>
      <label>
        Diğer ilan yazı rengi
        <span className="theme-field">
          <input type="color" value={form.vitrinOtherTextColor} onChange={(event) => setForm((prev) => ({ ...prev, vitrinOtherTextColor: event.target.value }))} aria-label="Diğer ilan yazı rengi" />
          <input value={form.vitrinOtherTextColor} onChange={(event) => setForm((prev) => ({ ...prev, vitrinOtherTextColor: event.target.value }))} spellCheck={false} />
        </span>
      </label>
      <label>
        Diğer ilan alt yazı rengi
        <span className="theme-field">
          <input type="color" value={form.vitrinOtherMutedColor} onChange={(event) => setForm((prev) => ({ ...prev, vitrinOtherMutedColor: event.target.value }))} aria-label="Diğer ilan alt yazı rengi" />
          <input value={form.vitrinOtherMutedColor} onChange={(event) => setForm((prev) => ({ ...prev, vitrinOtherMutedColor: event.target.value }))} spellCheck={false} />
        </span>
      </label>
      <div>
        <button className="btn secondary" type="button" onClick={() => void restoreOther()} disabled={busy}>
          Diğer ilan yazısını varsayılana döndür
        </button>
      </div>
      <label>
        Üst sıra
        <select
          value={form.vitrinTopTier}
          onChange={(event) => setForm((prev) => ({ ...prev, vitrinTopTier: event.target.value === "gold" ? "gold" : "vip" }))}
        >
          <option value="vip">VIP üstte</option>
          <option value="gold">GOLD üstte</option>
        </select>
      </label>
      <p className="muted full">VIP ve GOLD sabit kalır, karışmaz. YENİ kutusu işaretlenen ilanlarda ve son 3 gündeki ilanlarda çıkar.</p>
      {message ? <p className="muted full">{message}</p> : null}
      <div>
        <button className="btn" type="submit" disabled={busy}>
          {busy ? "Kaydediliyor" : "Temayı kaydet"}
        </button>
      </div>
    </form>
  );
}
