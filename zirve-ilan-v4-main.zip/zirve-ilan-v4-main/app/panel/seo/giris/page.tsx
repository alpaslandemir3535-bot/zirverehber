import { TrafficReport } from "@/components/panel/TrafficReport";
import { getTrafficStats } from "@/lib/analytics";

export const dynamic = "force-dynamic";

export default function TrafficPage() {
  const stats = getTrafficStats();
  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Seo ayarları</p>
          <h1>Giriş kaynağı</h1>
          <p className="muted">Aynı kişi bir günde bir kez sayılır. Doğrudan gelenlerde yönlendiren adres yoktur.</p>
        </div>
      </div>
      <TrafficReport stats={stats} />
    </>
  );
}
