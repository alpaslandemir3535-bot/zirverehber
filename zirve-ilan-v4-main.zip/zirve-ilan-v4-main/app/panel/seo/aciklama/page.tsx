import { RehberDescriptionForm } from "@/components/panel/RehberDescriptionForm";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default function RehberDescriptionPage() {
  const settings = getSettings();
  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Seo ayarları</p>
          <h1>Google açıklaması</h1>
        </div>
      </div>
      <RehberDescriptionForm description={settings.rehberDescription} />
    </>
  );
}
