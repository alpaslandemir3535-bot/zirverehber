# Zirve İlan

Tek uygulama, iki domain:

- `zirverehber.com` — il sayfaları, sitemap, Google’ın taradığı katman
- `zirvepano.xyz` — ön alan; .com tıklanınca ziyaretçi buraya gelir
- `zirveilan.xyz` — açılan ilanlar

Alan adları panel → Ayarlar’dan tek kayıtla değişir.

İkisi de aynı sunucuya bakacak. Uygulama `Host` başlığına göre sayfayı seçer. Googlebot’a ayrı HTML yok.

```bash
npm install
npm run dev
```

Yerel: http://localhost:3000/manisa-escort/ · `/panel` yönetici · `/hesap` ilan sahibi

Canlı kurulum Hostinger’da: [KURULUM.md](KURULUM.md)

Yönetici şifresi `.env.local` → `ADMIN_PASSWORD`. Canlıda varsayılan şifre kullanma. Search Console: panel → Ayarlar, sayılar `/panel/gsc`.
