import { CardSlide } from "@/components/CardSlide";
import { TrackLink } from "@/components/TrackLink";
import type { Listing } from "@/lib/listings";
import { listingCornerNotes } from "@/lib/owner-bio";
import { listingUrl } from "@/lib/site";

export function AdCard({
  listing,
  cityName,
  index = 0,
  rotatePhotos = true,
  vip = false,
}: {
  listing: Listing;
  cityName?: string;
  index?: number;
  rotatePhotos?: boolean;
  vip?: boolean;
}) {
  return (
    <div className={vip ? "grid-item vip-item" : "grid-item"}>
      <div className="ads-itemm">
        <TrackLink href={listingUrl(listing.slug, cityName)} type="listing" listingId={listing.id} city={cityName}>
          <div className="ads-itemm-photo">
            <div className="ads-itemm-photo__marks">
              {listingCornerNotes(listing).map((note) => (
                <span key={note}>{note}</span>
              ))}
            </div>
            <CardSlide
              images={listing.gallery.length ? listing.gallery : listing.cover ? [listing.cover] : []}
              alt={`${cityName ? `${cityName} Escort ` : ""}${listing.name}`}
              eager={index < 2}
              rotate={rotatePhotos}
            />
          </div>
          <div className="ads-item2__Content">
            <div className="ads-itemm-title">
              <div className="ads-item2--title">{listing.displayName}</div>
            </div>
          </div>
        </TrackLink>
      </div>
    </div>
  );
}
