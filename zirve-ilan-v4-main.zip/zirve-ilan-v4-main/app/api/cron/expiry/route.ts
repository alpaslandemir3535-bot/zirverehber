import { notifyExpiringListings } from "@/lib/expiry";
import { safeEqual } from "@/lib/http";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const secret = new URL(request.url).searchParams.get("secret") || "";
  const expected = process.env.CRON_SECRET || "";
  if (!expected || !secret || !safeEqual(secret, expected)) {
    return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  }
  const result = await notifyExpiringListings();
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json(result);
}
