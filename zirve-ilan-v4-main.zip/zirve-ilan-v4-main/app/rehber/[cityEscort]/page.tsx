import { VitrinHome } from "@/components/VitrinHome";
import { VisitorCity } from "@/components/VisitorCity";
import { cityFaqs } from "@/lib/faq";
import { faqNode, jsonLdScript, ORGANIZATION_ID, organizationNode, WEBSITE_ID } from "@/lib/site-schema";
import { cities } from "@/lib/cities";
import { listingsForCity } from "@/lib/listings";
import { splitVipListings } from "@/lib/vip";
import { keywordsForCity } from "@/lib/seo-keywords";
import { cityFromEscortParam, citySeoDescription, citySeoTitle, nearbyCities } from "@/lib/seo";
import { cityPagePath, rehberOrigin, rehberUrl } from "@/lib/site";
import type { Metadata } from "next";
import { notFound } from "next/navigation";

type Props = { params: Promise<{ cityEscort: string }> };

export const revalidate = 300;

export function generateStaticParams() {
  return cities.map((city) => ({ cityEscort: `${city.slug}-escort` }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { cityEscort } = await params;
  const city = cityFromEscortParam(cityEscort);
  if (!city) return {};
  const path = cityPagePath(city.slug);
  return {
    title: citySeoTitle(city),
    description: citySeoDescription(city),
    keywords: keywordsForCity(city),
    alternates: { canonical: rehberUrl(path) },
    robots: { index: true, follow: true },
    icons: { other: [{ rel: "amphtml", url: `${rehberOrigin()}${path}amp/` }] },
    openGraph: {
      title: citySeoTitle(city),
      description: citySeoDescription(city),
      url: rehberUrl(path),
      locale: "tr_TR",
      type: "website",
      siteName: "Zirve Rehber",
    },
  };
}

export default async function CityPage({ params }: Props) {
  const { cityEscort } = await params;
  const city = cityFromEscortParam(cityEscort);
  if (!city) notFound();

  const { vip, rest } = splitVipListings(listingsForCity(city));
  const related = nearbyCities(city, 6);

  const faqs = cityFaqs(city, vip.length + rest.length);
  const jsonLdHtml = jsonLdScript({
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "CollectionPage",
        name: citySeoTitle(city),
        description: citySeoDescription(city),
        url: rehberUrl(cityPagePath(city.slug)),
        isFamilyFriendly: false,
        isPartOf: { "@id": WEBSITE_ID() },
        publisher: { "@id": ORGANIZATION_ID() },
        about: related.map((item) => ({
          "@type": "Place",
          name: item.name,
        })),
      },
      organizationNode(),
      faqNode(faqs),
    ],
  });

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLdHtml }} />
      <VisitorCity correct />
      <VitrinHome
        title={`${city.name} Escort`}
        kicker={`${city.name.toLocaleUpperCase("tr-TR")} ESCORT - VİP - GERÇEK BAYANLAR`}
        listings={[...vip, ...rest]}
        cityName={city.name}
        city={city}
      />
    </>
  );
}
