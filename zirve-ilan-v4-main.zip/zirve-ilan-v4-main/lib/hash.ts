export function simpleHash(raw: string) {
  let hash = 0;
  for (let i = 0; i < raw.length; i += 1) {
    hash = (Math.imul(31, hash) + raw.charCodeAt(i)) | 0;
  }
  return `t${Math.abs(hash).toString(16)}${raw.length}`;
}
