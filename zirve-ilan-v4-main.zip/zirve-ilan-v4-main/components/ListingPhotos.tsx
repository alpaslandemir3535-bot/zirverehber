"use client";

import { useEffect, useState } from "react";

export function ListingPhotos({
  images,
  name,
  badge,
  kind,
}: {
  images: string[];
  name: string;
  badge: string;
  kind: string;
}) {
  const photos = images.filter(Boolean);
  const [active, setActive] = useState(0);
  const [open, setOpen] = useState(false);
  const current = photos[active] || photos[0] || "";

  useEffect(() => {
    if (!open) return;
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
      if (event.key === "ArrowRight") setActive((value) => (value + 1) % photos.length);
      if (event.key === "ArrowLeft") setActive((value) => (value - 1 + photos.length) % photos.length);
    }
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, photos.length]);

  if (!current) return null;

  return (
    <>
      <button type="button" className="ilan-hero" onClick={() => setOpen(true)} aria-label={`${name} fotoğrafını büyüt`}>
        {kind ? <span className={`vitrin-badge badge-${kind}`}>{badge}</span> : null}
        <img src={current} alt={name} />
      </button>
      {photos.length > 1 ? (
        <div className="ilan-thumbs">
          {photos.map((src, index) => (
            <button key={`${src}-${index}`} type="button" className={index === active ? "is-on" : ""} onClick={() => setActive(index)}>
              <img src={src} alt="" />
            </button>
          ))}
        </div>
      ) : null}
      {open ? (
        <div className="lightbox" role="dialog" aria-modal="true" aria-label={`${name} fotoğraf`}>
          <button type="button" className="lightbox-backdrop" aria-label="Kapat" onClick={() => setOpen(false)} />
          <figure>
            <img src={current} alt={name} />
            <button type="button" className="lightbox-close" onClick={() => setOpen(false)}>
              Kapat
            </button>
          </figure>
        </div>
      ) : null}
    </>
  );
}
