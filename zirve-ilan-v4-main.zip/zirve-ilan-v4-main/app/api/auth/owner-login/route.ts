import { cookieOptions, OWNER_COOKIE, signOwnerToken } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { loginBanned, noteLoginFailure, noteLoginSuccess } from "@/lib/login-guard";
import { clientIp } from "@/lib/rate-limit";
import { verifyOwnerLogin } from "@/lib/users";
import { NextResponse } from "next/server";

const locked = NextResponse.json({ error: "Bu adresten giriş kapatıldı." }, { status: 403 });

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  const ip = clientIp(request);
  if (loginBanned(ip)) return locked;
  const body = (await request.json().catch(() => null)) as { username?: string } | null;
  const owner = verifyOwnerLogin(body?.username || "");
  if (!owner) {
    if (noteLoginFailure(ip)) return locked;
    return NextResponse.json({ error: "Giriş yapılamadı." }, { status: 401 });
  }
  noteLoginSuccess(ip);
  const response = NextResponse.json({ ok: true });
  response.cookies.set(OWNER_COOKIE, await signOwnerToken(owner.id), cookieOptions());
  return response;
}
