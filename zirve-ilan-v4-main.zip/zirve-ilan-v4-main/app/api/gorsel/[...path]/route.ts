import { createReadStream, existsSync, statSync } from "fs";
import path from "path";
import { Readable } from "stream";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const MIME: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".avif": "image/avif",
  ".bmp": "image/bmp",
  ".ico": "image/x-icon",
};

const root = path.join(process.cwd(), "public", "uploads");

export async function GET(_: Request, { params }: { params: Promise<{ path: string[] }> }) {
  const { path: parts } = await params;
  const file = path.normalize(path.join(root, ...parts.map((part) => decodeURIComponent(part))));
  const rel = path.relative(root, file);
  if (rel.startsWith("..") || path.isAbsolute(rel)) return new NextResponse(null, { status: 404 });
  const type = MIME[path.extname(file).toLowerCase()];
  if (!type || !existsSync(file) || !statSync(file).isFile()) return new NextResponse(null, { status: 404 });
  const stream = Readable.toWeb(createReadStream(file)) as ReadableStream;
  return new NextResponse(stream, {
    headers: {
      "Content-Type": type,
      "Content-Length": String(statSync(file).size),
      "Cache-Control": "public, max-age=86400",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
