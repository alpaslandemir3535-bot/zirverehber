import { copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, statSync, unlinkSync, writeFileSync } from "fs";
import path from "path";

function pause(ms: number) {
  try {
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
  } catch {
    /* bekleme desteklenmiyorsa hemen tekrar dene */
  }
}

/** Bozuk dosyayı silmeden yanına kopyalar; sonraki yazma üzerine yazsa bile veri kaybolmaz. */
function quarantine(file: string) {
  try {
    const copy = path.join(path.dirname(file), `${path.basename(file)}.bozuk-${Math.round(statSync(file).mtimeMs)}`);
    if (!existsSync(copy)) copyFileSync(file, copy);
  } catch {
    /* kopya alınamazsa sessiz geç */
  }
}

/**
 * Metnin başındaki ilk eksiksiz JSON değerini döner. İki yazma üst üste binince dosyanın sonuna
 * eski verinin artığı yapışabilir; baştaki geçerli kısım bu sayede kurtarılır.
 */
function firstJsonValue(text: string): string | null {
  const start = text.search(/[\[{]/);
  if (start !== 0) return null;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === "{" || ch === "[") depth += 1;
    else if (ch === "}" || ch === "]") {
      depth -= 1;
      if (depth === 0) return text.slice(0, i + 1);
    }
  }
  return null;
}

/**
 * JSON dosyasını güvenle okur. Dosya yoksa, yarım yazılmışsa ya da bozuksa panel çökmesin diye
 * `fallback` döner. Başındaki BOM işareti temizlenir. Bozuk dosya `.bozuk-...` adıyla saklanır.
 */
export function readJsonFile<T>(file: string, fallback: T): T {
  if (!existsSync(file)) return fallback;
  let last: unknown = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const text = readFileSync(file, "utf8").replace(/^\uFEFF/, "");
      if (!text.trim()) throw new Error("Dosya boş.");
      return JSON.parse(text) as T;
    } catch (error) {
      last = error;
      if (attempt < 2) pause(40);
    }
  }
  try {
    const text = readFileSync(file, "utf8").replace(/^\uFEFF/, "");
    const head = firstJsonValue(text);
    if (head) {
      const value = JSON.parse(head) as T;
      console.error(`[json-file] ${file} sonunda artık veri vardı; baştaki geçerli kısım kullanıldı.`);
      quarantine(file);
      return value;
    }
  } catch {
    /* kurtarılamadı */
  }
  console.error(`[json-file] ${file} okunamadı:`, last instanceof Error ? last.message : last);
  quarantine(file);
  return fallback;
}

/** Önce geçici dosyaya yazıp yeniden adlandırır; eşzamanlı okuyan yarım dosya görmez. */
export function writeJsonFile(file: string, data: unknown, pretty = true) {
  mkdirSync(path.dirname(file), { recursive: true });
  const text = pretty ? JSON.stringify(data, null, 2) : JSON.stringify(data);
  const tmp = `${file}.tmp-${process.pid}`;
  try {
    writeFileSync(tmp, text, "utf8");
    renameSync(tmp, file);
  } catch {
    try {
      unlinkSync(tmp);
    } catch {
      /* geçici dosya yoksa sorun değil */
    }
    writeFileSync(file, text, "utf8");
  }
}
