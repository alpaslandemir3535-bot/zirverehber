import type { CSSProperties } from "react";
import type { AppSettings } from "./settings";
import { vitrinOtherFontFamily, vitrinOtherFontWeight } from "./vitrin-defaults";

export function vitrinStyle(settings: AppSettings) {
  return {
    "--vitrin-bg": settings.vitrinBg,
    "--vitrin-card": settings.vitrinCard,
    "--vitrin-accent": settings.vitrinAccent,
    "--vitrin-hero": settings.vitrinHero,
    "--vitrin-text": settings.vitrinText,
    "--vitrin-vip": settings.vitrinVip,
    "--vitrin-gold": settings.vitrinGold,
    "--vitrin-yeni": settings.vitrinYeni,
    "--vitrin-bg-image": settings.vitrinBgImage ? `url("${settings.vitrinBgImage}")` : "none",
    "--vitrin-other-title": settings.vitrinOtherTitleColor,
    "--vitrin-other-text": settings.vitrinOtherTextColor,
    "--vitrin-other-muted": settings.vitrinOtherMutedColor,
    "--vitrin-other-font": vitrinOtherFontFamily(settings.vitrinOtherFont),
    "--vitrin-other-font-weight": vitrinOtherFontWeight(settings.vitrinOtherFont),
    "--vitrin-font": vitrinOtherFontFamily(settings.vitrinFont),
    "--vitrin-font-weight": vitrinOtherFontWeight(settings.vitrinFont),
    "--vitrin-profile-bg": settings.vitrinProfileBg,
    "--vitrin-profile-color": settings.vitrinProfileColor,
  } as CSSProperties;
}
