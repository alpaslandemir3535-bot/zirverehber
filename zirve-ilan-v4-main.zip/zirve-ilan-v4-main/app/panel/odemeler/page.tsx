import { LedgerBook } from "@/components/panel/LedgerBook";
import { PaymentDecision } from "@/components/panel/PaymentDecision";
import { ledgerBoards } from "@/lib/ledger";
import { getPayments } from "@/lib/payments";
import { formatUsd, PAY_PLANS } from "@/lib/pay-plans";
import { ownerById } from "@/lib/users";

export const dynamic = "force-dynamic";

export default function PaymentsPage() {
  const payments = getPayments();
  const waiting = payments.filter((item) => item.status === "waiting");
  const books = ledgerBoards();

  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">TRC20</p>
          <h1>Ödeme onayları</h1>
        </div>
      </div>
      <div className="panel-card">
        {waiting.length ? (
          <table>
            <thead>
              <tr>
                <th>İlan</th>
                <th>Sahip</th>
                <th>Süre</th>
                <th>Tutar</th>
                <th>Not</th>
                <th>Bildirim</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {waiting.map((item) => {
                const owner = ownerById(item.ownerId);
                return (
                  <tr key={item.id}>
                    <td>
                      <strong>{item.listingName}</strong>
                    </td>
                    <td>{owner ? owner.username : "Silinmiş hesap"}</td>
                    <td>{PAY_PLANS[item.plan].label}</td>
                    <td>{formatUsd(item.amountUsd)}</td>
                    <td>{item.note || "—"}</td>
                    <td>{new Date(item.createdAt).toLocaleString("tr-TR")}</td>
                    <td>
                      <PaymentDecision id={item.id} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <p>Onay bekleyen ödeme yok.</p>
        )}
      </div>

      <div className="panel-row" style={{ marginTop: 22 }}>
        <div>
          <p className="eyebrow">Kasa</p>
          <h2>Gelir gider</h2>
        </div>
      </div>
      <LedgerBook week={books.week} month={books.month} today={books.today} />

      {payments.some((item) => item.status !== "waiting") ? (
        <div className="panel-card" style={{ marginTop: 16 }}>
          <h2>Ödeme geçmişi</h2>
          <table>
            <thead>
              <tr>
                <th>İlan</th>
                <th>Süre</th>
                <th>Tutar</th>
                <th>Durum</th>
                <th>Tarih</th>
              </tr>
            </thead>
            <tbody>
              {payments
                .filter((item) => item.status !== "waiting")
                .slice(0, 20)
                .map((item) => (
                  <tr key={item.id}>
                    <td>{item.listingName}</td>
                    <td>{PAY_PLANS[item.plan].label}</td>
                    <td>{formatUsd(item.amountUsd)}</td>
                    <td>{item.status === "approved" ? "Onaylandı" : "Reddedildi"}</td>
                    <td>{item.decidedAt ? new Date(item.decidedAt).toLocaleString("tr-TR") : ""}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </>
  );
}
