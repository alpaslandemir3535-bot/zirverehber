"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  telegramChatId: string;
  telegramDaily: boolean;
  telegramReady: boolean;
  telegramBotTokenMasked: string;
  lastTelegramAt: string | null;
  cronHint: string;
};

export function TelegramSettings(props: Props) {
  const router = useRouter();
  const [token, setToken] = useState("");
  const [chatId, setChatId] = useState(props.telegramChatId);
  const [daily, setDaily] = useState(props.telegramDaily);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/telegram/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        telegramBotToken: token || props.telegramBotTokenMasked,
        telegramChatId: chatId,
        telegramDaily: daily,
      }),
    });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Kaydedildi." : json.error || "Kaydedilemedi.");
    if (res.ok) {
      setToken("");
      router.refresh();
    }
  }

  async function sendNow() {
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/telegram/send", { method: "POST" });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Telegram’a gönderildi." : json.error || "Gönderilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <div className="full help-box">
        <p>BotFather’dan bot oluşturup token’ı yapıştır. Bota bir mesaj yaz, Chat ID’yi al.</p>
        <p>
          Otomatik özet 6 saatte bir tek mesaj gider. Cron
          <code> {props.cronHint} </code>
          adresini her saat çağırsın. Token’ı panelde kayıtlı tut.
        </p>
      </div>
      <label>
        Bot token
        <input
          type="password"
          value={token}
          onChange={(event) => setToken(event.target.value)}
          placeholder={props.telegramBotTokenMasked || "123456:ABC..."}
        />
      </label>
      <label>
        Chat ID
        <input value={chatId} onChange={(event) => setChatId(event.target.value)} placeholder="-100..." />
      </label>
      <label className="check-line">
        <input type="checkbox" checked={daily} onChange={(event) => setDaily(event.target.checked)} />
          Her 6 saatte bir özet gönder
      </label>
      <div className="full row-actions">
        <button className="btn" type="submit" disabled={busy}>
          Kaydet
        </button>
        <button className="btn secondary" type="button" onClick={sendNow} disabled={busy || !props.telegramReady}>
          Özeti şimdi gönder
        </button>
        <span className={props.telegramReady ? "badge published" : "badge draft"}>
          {props.telegramReady ? "Bağlı" : "Eksik"}
        </span>
        {props.lastTelegramAt ? (
          <span className="muted">Son: {new Date(props.lastTelegramAt).toLocaleString("tr-TR")}</span>
        ) : null}
      </div>
      {message ? <p className="full muted">{message}</p> : null}
    </form>
  );
}
