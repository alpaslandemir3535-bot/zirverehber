import { rejectCrossOrigin } from "@/lib/http";
import { parseListingInput } from "@/lib/listing-input";
import { currentActor } from "@/lib/session";
import { deleteListing, listingById, listingsForOwner, updateListing } from "@/lib/store";
import { ownerFromToken } from "@/lib/users";
import { ownerTokenFromCookie } from "@/lib/auth";
import { NextResponse } from "next/server";

type Ctx = { params: Promise<{ id: string }> };

function canTouch(actor: Awaited<ReturnType<typeof currentActor>>, ownerId: string | null) {
  if (actor.role === "admin") return true;
  return actor.role === "owner" && ownerId === actor.owner.id;
}

export async function GET(_: Request, { params }: Ctx) {
  const actor = await currentActor();
  const { id } = await params;
  const listing = listingById(id);
  if (!listing) return NextResponse.json({ error: "İlan yok." }, { status: 404 });
  if (!canTouch(actor, listing.ownerId)) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json(listing);
}

export async function PUT(request: Request, { params }: Ctx) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  const actor = await currentActor();
  const { id } = await params;
  const current = listingById(id);
  if (!current) return NextResponse.json({ error: "İlan yok." }, { status: 404 });
  if (!canTouch(actor, current.ownerId)) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json()) as Partial<import("@/lib/listing-types").ListingInput> & { asOwner?: boolean };
  const parsed = parseListingInput(body);
  if (typeof parsed === "string") return NextResponse.json({ error: parsed }, { status: 400 });
  const owner = await ownerFromToken(await ownerTokenFromCookie());
  const actingAsOwner = actor.role === "owner" || (body.asOwner === true && owner?.id === current.ownerId);
  if (!actingAsOwner && actor.role !== "admin") return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  if (actingAsOwner) {
    parsed.ownerId = current.ownerId;
    parsed.featured = current.featured;
    parsed.gold = current.gold;
    parsed.yeni = current.yeni;
    parsed.sortOrder = current.sortOrder;
    parsed.duration = current.duration;
    parsed.status = current.status;
  } else if (parsed.ownerId && listingsForOwner(parsed.ownerId).some((item) => item.id !== id)) {
    return NextResponse.json({ error: "Bu ilan sahibinin zaten bir ilanı var." }, { status: 400 });
  }
  const listing = updateListing(id, parsed, actingAsOwner);
  return NextResponse.json(listing);
}

export async function DELETE(request: Request, { params }: Ctx) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  const actor = await currentActor();
  if (actor.role !== "admin") return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  if (!deleteListing(id)) return NextResponse.json({ error: "İlan yok." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
