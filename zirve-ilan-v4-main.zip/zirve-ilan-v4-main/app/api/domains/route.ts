import { isAdmin } from "@/lib/auth";
import { getDomains, saveDomains } from "@/lib/domains";
import { rejectCrossOrigin } from "@/lib/http";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json(getDomains());
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as {
    rehberHost?: string;
    panoHost?: string;
    ilanHost?: string;
  } | null;
  const saved = saveDomains({
    rehberHost: body?.rehberHost,
    panoHost: body?.panoHost,
    ilanHost: body?.ilanHost,
  });
  if ("error" in saved) return NextResponse.json({ error: saved.error }, { status: 400 });
  return NextResponse.json(saved);
}
