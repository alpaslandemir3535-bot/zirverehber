import {
  Anton,
  Archivo_Black,
  Barlow_Condensed,
  Encode_Sans_Condensed,
  Fjalla_One,
  Kanit,
  Oswald,
  Passion_One,
  Russo_One,
  Saira_Condensed,
  Staatliches,
  Teko,
} from "next/font/google";

const oswald = Oswald({
  weight: ["600", "700"],
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-oswald",
  preload: false,
});

const anton = Anton({
  weight: "400",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-anton",
  preload: false,
});

const fjalla = Fjalla_One({
  weight: "400",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-fjalla",
  preload: false,
});

const staatliches = Staatliches({
  weight: "400",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-staatliches",
  preload: false,
});

const teko = Teko({
  weight: "700",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-teko",
  preload: false,
});

const barlow = Barlow_Condensed({
  weight: "700",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-barlow",
  preload: false,
});

const saira = Saira_Condensed({
  weight: "700",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-saira",
  preload: false,
});

const encode = Encode_Sans_Condensed({
  weight: "700",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-encode",
  preload: false,
});

const passion = Passion_One({
  weight: "700",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-passion",
  preload: false,
});

const russo = Russo_One({
  weight: "400",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-russo",
  preload: false,
});

const archivo = Archivo_Black({
  weight: "400",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-archivo",
  preload: false,
});

const kanit = Kanit({
  weight: "700",
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-kanit",
  preload: false,
});

export const sharpFontClass = [
  oswald.variable,
  anton.variable,
  fjalla.variable,
  staatliches.variable,
  teko.variable,
  barlow.variable,
  saira.variable,
  encode.variable,
  passion.variable,
  russo.variable,
  archivo.variable,
  kanit.variable,
].join(" ");
