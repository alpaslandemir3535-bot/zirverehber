"use client";

import { useEffect } from "react";

function cityFromPage() {
  if (typeof window === "undefined") return "";
  const sehir = new URLSearchParams(window.location.search).get("sehir");
  if (sehir) return sehir;
  const match = window.location.pathname.match(/\/([a-z0-9-]+)-escort/);
  return match?.[1] || "";
}

function visitorId() {
  const key = "zirve_vid";
  const existing = localStorage.getItem(key);
  if (existing) return existing;
  const id = crypto.randomUUID();
  localStorage.setItem(key, id);
  return id;
}

function trafficFacts() {
  const params = new URLSearchParams(window.location.search);
  let host = "";
  let referrerTerm = "";
  try {
    if (document.referrer) {
      const referrer = new URL(document.referrer);
      host = referrer.hostname.replace(/^www\./, "");
      referrerTerm = referrer.searchParams.get("q") || referrer.searchParams.get("query") || referrer.searchParams.get("p") || "";
      if (/zirverehber\.|zirvepano\.|zirveilan\.|vitrinpano\.|localhost|127\.0\.0\.1/.test(host)) host = "";
    }
  } catch {
    host = "";
  }
  const medium = (params.get("utm_medium") || "").toLowerCase();
  const sourceName = (params.get("utm_source") || "").toLowerCase();
  const term = (params.get("utm_term") || params.get("q") || referrerTerm).replace(/\s+/g, " ").trim().slice(0, 80);
  const googleAd = Boolean(params.get("gclid") || params.get("gbraid") || params.get("wbraid"));
  const otherPaid = Boolean(
    params.get("fbclid") || params.get("msclkid") || medium === "cpc" || medium === "ppc" || medium === "paid" || medium === "ads",
  );
  let source = "direct";
  if (host.includes("google.") || sourceName === "google" || googleAd) source = "google";
  else if (/bing\.|yandex\.|duckduckgo\.|yahoo\./.test(host) || params.get("msclkid")) source = "arama";
  else if (host || otherPaid) source = "yonlendirme";
  const mobile = window.matchMedia("(max-width: 900px)").matches || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
  return { device: mobile ? "mobile" : "desktop", source, term };
}

export function trackClient(type: "view" | "listing" | "whatsapp", listingId?: string, city?: string) {
  const payload = JSON.stringify({
    type,
    listingId,
    city: city || cityFromPage(),
    visitorId: visitorId(),
    ...(type === "view" ? trafficFacts() : {}),
  });
  if (navigator.sendBeacon) {
    navigator.sendBeacon("/api/track", new Blob([payload], { type: "text/plain" }));
    return;
  }
  void fetch("/api/track", {
    method: "POST",
    body: payload,
    headers: { "Content-Type": "text/plain" },
    keepalive: true,
  });
}

export function AnalyticsBeacon() {
  useEffect(() => {
    const path = window.location.pathname;
    if (path.startsWith("/panel") || path.startsWith("/hesap") || path.startsWith("/api")) return;
    trackClient("view");
  }, []);
  return null;
}
