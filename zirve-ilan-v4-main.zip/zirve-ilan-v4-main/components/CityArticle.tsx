import type { City } from "@/lib/cities";
import { cityContent } from "@/lib/city-content";

export function CityArticle({ city }: { city: City }) {
  const { sections } = cityContent(city);

  if (!sections.length) return null;

  return (
    <section className="city-article">
      {sections.map((section) => (
        <article key={section.heading}>
          <h2>{section.heading}</h2>
          <p>{section.body}</p>
        </article>
      ))}
    </section>
  );
}
