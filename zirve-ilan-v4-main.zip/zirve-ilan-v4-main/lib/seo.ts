import { cities, cityBySlug, type City } from "./cities";
import { cityContent } from "./city-content";
import { seoPostBySlug, seoPostsForCity, type SeoPost } from "./seo-store";

export type CityPost = {
  slug: string;
  name: string;
  title: string;
  path: string;
  body: string;
  updatedAt?: string;
};

export function citySeoTitle(city: City) {
  return `${city.name} Escort İlanları | Zirve Rehber`;
}

// Her ilin kendi elle yazılmış metni. Şablon paylaşmaz, 81 sayfa 81 ayrı açıklama verir.
export function citySeoDescription(city: City) {
  return cityContent(city).description;
}

export function toCityPost(city: City, post: SeoPost): CityPost {
  return {
    slug: post.slug,
    name: post.name,
    title: post.title,
    path: `/${city.slug}-escort/${post.slug}/`,
    body: post.body,
    updatedAt: post.updatedAt,
  };
}

export function cityPosts(city: City): CityPost[] {
  return seoPostsForCity(city, "public").map((post) => toCityPost(city, post));
}

export function cityPostBySlug(city: City, postSlug: string) {
  const post = seoPostBySlug(city, postSlug, "public");
  return post ? toCityPost(city, post) : undefined;
}

export function cityFromEscortParam(param: string) {
  return cityBySlug(param.replace(/-escort$/, ""));
}

export function nearbyCities(city: City, count = 8) {
  const index = cities.findIndex((item) => item.slug === city.slug);
  return Array.from({ length: count }, (_, offset) => cities[(index + offset + 1) % cities.length]);
}

export function cityPostBody(_city: City, post: CityPost) {
  return post.body;
}
