const SHARED_BIO = "burada olmak benim için hep başka";

export type BioSource = {
  id?: string;
  name: string;
  displayName?: string;
  age?: number;
  category?: string;
  phone?: string;
  eldenOdeme?: boolean;
  evOtelApart?: boolean;
  gercekGoruntu?: boolean;
};

export function isSharedBio(text: string) {
  const value = text.trim();
  return !value || value.includes(SHARED_BIO);
}

const PROFILE_ARTICLES: Record<string, string> = {
  hande:
    "Hande’nin {şehir} escort ilanı popüler başlıkta ve 23 yaşında. Günü tek görüşmeye ayırır. O saat doluyken ikinci bir mesaja dönmez, sırayı kendi koyar. {şehir} içinde yer ev, otel ya da apart olabilir. Bunu kapıda değil, yazışırken söyler. Ödemeyi elden alır. Fotoğraflar kendisine aittir. Saat ve yer yazılması dönüş için yeter.",
  busra:
    "Büşra, {şehir} escort vitrininde vip ilanla duruyor. 22 yaşında. Şartı son anda değiştirmez. Mesajda ne konuşulduysa buluşma da öyle olur. Yanına ikinci bir kişi almaz. {şehir} tarafında eve, otele ve aparte gelir. Ödeme elden. Görseller kendi çekimi. Zirve Escort sayfasından yazıldığını söyleyen kişiyi ilandan tanır. Müsait olmadığı saati baştan yazar.",
  tugce:
    "Tuğçe’nin {şehir} escort ilanı vip. 25 yaşında. İlk yazıda saat yoksa sohbeti uzatmaz. Süre uzayacaksa bunu buluşmadan belirtir. {şehir} içinde ev, otel ve apartın üçüne de gider, hangisi olacağı önceden bellidir. Ödeme elden alınır. Resimler gerçek ve kendisinindir. Uygun değilse sessiz kalmaz, başka bir saat önerir.",
  gonca:
    "Gonca, {şehir} escort sayfasında 23 yaşında popüler ilanıyla yazıyor. Acele ettirmeden konuşur. Bir kişi, bir saat, belli bir adres ister. Dönüşü hızlıdır ama iki randevuyu aynı saate koymaz. {şehir} içinde eve, otele ve aparte gelir. Ödeme elden yapılır. Fotoğraflar Gonca’ya aittir. Numaradan yazan kişi bu sayfadaki ilana ulaşmış olur.",
  pelin:
    "Pelin’in {şehir} escort ilanı üniversiteli. 24 yaşında. Sabah ve öğlen daha rahattır. Akşam da yazar, ders varsa saati kaydırır ve bunu gizlemez. Yazışması yer ile saatten ibarettir. {şehir} içinde eve, otele ya da aparte gelir. Ödemeyi elden alır. Fotoğraflardaki kişi kendisidir. Uygunsa aynı gün döner, değilse ertesi gün için net bir saat bırakır.",
};

export function listingProfileArticle(
  listing: { slug?: string; name: string; displayName?: string; age?: number; category?: string },
  cityName: string,
) {
  const key = (listing.slug || "").toLocaleLowerCase("tr");
  const name = (listing.displayName || listing.name).trim();
  const place = cityName.trim() || "şehir";
  const raw =
    PROFILE_ARTICLES[key] ||
    `${name}, ${place} escort ilanında kendi sayfasıyla durur. ${listing.age && listing.age >= 21 ? `${listing.age} yaşında. ` : ""}${listing.category ? `${listing.category} profilindedir. ` : ""}${place} içinde yeri ve saati mesajda konuşur.`;
  return raw.replaceAll("{şehir}", place).replaceAll("{sehir}", place).replace(/\s+/g, " ").trim();
}

export function listingBio(city?: string) {
  return listingArticle({ name: "" }, city);
}

export function listingArticle(source: BioSource, city?: string) {
  const place = city?.trim() || "{şehir}";
  const name = (source.displayName || source.name).trim() || "ben";
  const seed = `${source.name}|${source.phone || ""}|${source.category || ""}`;
  const age = source.age && source.age >= 21 && source.age <= 99 ? source.age : 0;
  const opening = pick(seed, 1, [
    `Merhaba, ben ${name}. ${place} escort ilanım bu sayfada duruyor.`,
    `${place} escort arayanlara kendimi ${name} diye yazıyorum.`,
    `Ben ${name}. ${place} içinde buluşmayı baştan netleştiririm.`,
    `${name} adıyla ${place} escort ilanındayım. Saat ve yer ilk mesajda konuşulur.`,
    `${place} sayfasında ${name} olarak duruyorum. Acele ettirmeden, açık konuşarak ilerlerim.`,
    `İlanımın adı ${name}. ${place} escort görüşmesinde gizliliği en başta sorarım.`,
  ]);
  const pace = pick(seed, 2, [
    "İlk yazışmada ne istediğini söylemen yeterli, gerisini ben toparlarım.",
    "Kısa ve düzgün yazanlarla daha rahat anlaşırım.",
    "Randevuyu aynı gün de kurarım, ertesi güne de bırakırım.",
    "Kalabalığı sevmem. Bir kişi, bir saat, net bir yer.",
    "Mesajda isim ve saat varsa dönüşüm hızlı olur.",
    "Uzun soru listesine gerek yok. Yeri ve saati yazman yeter.",
  ]);
  const profile = profileLine(source.category, place, pickIndex(seed, 3, 6));
  const years = age ? pick(seed, 4, [` ${age} yaşındayım.`, ` Yaşım ${age}.`, ` ${age} yaşında bu ilanda yazıyorum.`]) : "";
  const facts = [
    source.eldenOdeme ? "Ödeme elden yapılır." : "",
    source.evOtelApart ? "Eve, otele ve aparte gelirim." : "",
    source.gercekGoruntu ? "Fotoğraflar bana aittir." : "",
  ].filter(Boolean);
  const closing = pick(seed, 5, [
    `${place} içinde görüşmeyi temiz ve sakince tutarım.`,
    "Kapıda sürpriz çıkarmam. Konuştuğumuz gibi gelirim.",
    "Numaradan yazman yeterli. Sayfadaki ilan benim.",
    `${place} escort yazışmasında Zirve Rehber’den geldiğini söylemen yeter.`,
    "Uygun değilsem bunu baştan yazarım, oyalmam.",
    "Buluşma kısa sürsün, uzun sürsün, bunu önceden konuşuruz.",
  ]);
  const first = [opening, pace, profile, years.trim()].filter(Boolean).join(" ");
  const second = [...facts, closing].join(" ");
  return `${first}\n\n${second}`.replace(/[ \t]{2,}/g, " ").trim();
}

function profileLine(category: string | undefined, place: string, index: number) {
  const key = (category || "").toLocaleUpperCase("tr");
  const lines: Record<string, string[]> = {
    "VİP ESCORT": [
      "Vip başlığını gösteriş için değil, özen için kullanırım.",
      `${place} içinde vip görüşmeyi sakin ve özel tutarım.`,
      "Vip ilanımda acele pazarlık olmaz, şart baştan bellidir.",
    ],
    "ÜNİVERSİTELİ ESCORT": [
      "Üniversiteli profilim, gün içindeki boş saate göre randevu verir.",
      "Ders temposundan dolayı saati önceden netleştiririm.",
      "Üniversiteli ilanımda yazışmayı kısa tutarım.",
    ],
    "ÖĞRENCİ ESCORT": [
      "Öğrenci ilanımda randevuyu gün içine yayarım.",
      "Akşam saatleri bende daha rahattır, onu yazmana gerek kalmadan söylüyorum.",
      "Öğrenci profilinde süreyi baştan konuşuruz.",
    ],
    "POPÜLER ESCORT": [
      "Popüler ilanda aynı gün birden fazla yazı gelir, sırayı ben veririm.",
      "Yoğun günde herkese aynı saati vermem.",
      "Popüler başlık, dönüşümün hızlı olduğu anlamına gelir.",
    ],
    "SINIRSIZ ESCORT": [
      "Sınırsız başlığı, süreyi kapıda değil mesajda konuştuğumuz anlamına gelir.",
      "Sınırsız ilanda neyin dahil olduğunu baştan yazarım.",
      "Süre uzayacaksa bunu buluşmadan önce söylerim.",
    ],
  };
  const pool = lines[key] || [
    `${place} escort ilanımda şartları baştan yazarım.`,
    "Ne aradığını açık yazarsan dönüşüm de açık olur.",
    "İlanımda yazmayan bir şeyi sonradan eklemem.",
  ];
  return pool[index % pool.length];
}

function mix(seed: string, salt: number) {
  let n = salt + 17;
  for (let i = 0; i < seed.length; i += 1) n = (n * 33 + seed.charCodeAt(i)) >>> 0;
  return n;
}

function pick(seed: string, salt: number, list: string[]) {
  return list[mix(seed, salt) % list.length];
}

function pickIndex(seed: string, salt: number, size: number) {
  return mix(seed, salt) % size;
}

export function listingCornerNotes(input: {
  category: string;
  eldenOdeme?: boolean;
  evOtelApart?: boolean;
  gercekGoruntu?: boolean;
  extraMarks?: string[];
}) {
  const notes = [input.category];
  if (input.eldenOdeme) notes.push("ELDEN ÖDEME");
  if (input.evOtelApart) notes.push("EV-OTEL-APART");
  if (input.gercekGoruntu) notes.push("GERÇEK GÖRÜNTÜ");
  for (const mark of input.extraMarks || []) {
    const text = mark.trim();
    if (!text) continue;
    const key = text.toLocaleLowerCase("tr");
    if (notes.some((item) => item.toLocaleLowerCase("tr") === key)) continue;
    notes.push(text);
  }
  return notes;
}

export function ownerBio(input: { displayName: string; name: string; age: number; category: string; phone?: string }) {
  return listingArticle(input);
}
