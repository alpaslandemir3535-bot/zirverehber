import { cities } from "./cities";
import { whatsappHref, type Listing } from "./listing-types";
import { getSettings } from "./settings";

export function cityNameForListing(listing: Listing, cityName?: string) {
  if (cityName?.trim()) return cityName.trim();
  const slug = listing.cities[0];
  return cities.find((item) => item.slug === slug)?.name || "";
}

export function listingWhatsAppHref(listing: Listing, cityName?: string) {
  return whatsappHref(
    listing,
    cityNameForListing(listing, cityName),
    getSettings().waListingMessage,
  );
}
