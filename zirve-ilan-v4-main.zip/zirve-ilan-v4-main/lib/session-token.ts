export const ADMIN_COOKIE = "zirve_admin";
export const OWNER_COOKIE = "zirve_owner";

function secret() {
  const value = process.env.ADMIN_SECRET || process.env.ADMIN_PASSWORD || "";
  if (process.env.NODE_ENV === "production" && (!value || value === "zirve-dev-secret")) {
    return "";
  }
  return value || (process.env.NODE_ENV === "production" ? "" : "zirve-dev-secret");
}

function toBase64Url(buf: ArrayBuffer) {
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (const byte of bytes) bin += String.fromCharCode(byte);
  return btoa(bin).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

async function hmac(value: string) {
  const keyRaw = secret();
  if (!keyRaw) return "";
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(keyRaw),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return toBase64Url(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}

const SESSION_MS = 14 * 24 * 60 * 60 * 1000;

export async function signSessionToken(userId: string) {
  const exp = String(Date.now() + SESSION_MS);
  const stamp = await hmac(`${userId}.${exp}`);
  if (!userId || !stamp) throw new Error("Oturum anahtarı eksik. ADMIN_SECRET tanımla.");
  return `${userId}.${exp}.${stamp}`;
}

export async function sessionUserId(token: string | undefined) {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [userId, exp, stamp] = parts;
  if (!userId || !exp || !stamp || userId.includes("/") || !/^\d+$/.test(exp)) return null;
  if (Number(exp) < Date.now()) return null;
  const expected = await hmac(`${userId}.${exp}`);
  if (!expected || expected.length !== stamp.length) return null;
  let diff = 0;
  for (let i = 0; i < expected.length; i += 1) {
    diff |= expected.charCodeAt(i) ^ stamp.charCodeAt(i);
  }
  return diff === 0 ? userId : null;
}

export async function isValidSessionToken(token: string | undefined) {
  return Boolean(await sessionUserId(token));
}
