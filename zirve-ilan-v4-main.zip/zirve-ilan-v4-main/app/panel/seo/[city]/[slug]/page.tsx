import { cityBySlug } from "@/lib/cities";
import { seoPostBySlug } from "@/lib/seo-store";
import { notFound } from "next/navigation";
import { SeoPostForm } from "@/components/panel/SeoPostForm";

export const dynamic = "force-dynamic";

export default async function SeoEditPage({
  params,
}: {
  params: Promise<{ city: string; slug: string }>;
}) {
  const { city: citySlug, slug } = await params;
  const city = cityBySlug(citySlug);
  if (!city) notFound();
  const post = seoPostBySlug(city, slug);
  if (!post) notFound();

  return (
    <>
      <div className="panel-row">
        <h1>{post.title}</h1>
        <a className="btn secondary" href={`/panel/seo/${city.slug}/`}>
          Listeye dön
        </a>
      </div>
      <SeoPostForm post={post} />
    </>
  );
}
