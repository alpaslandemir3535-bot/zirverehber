"use client";

import { useState } from "react";

export function SikayetForm() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    const res = await fetch("/api/complaints", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone, message }),
    });
    if (!res.ok) {
      setError("Mesaj gönderilemedi.");
      return;
    }
    setDone(true);
  }

  if (done) return <p>Mesaj alındı. En kısa sürede bakılacak.</p>;

  return (
    <form className="form-grid" style={{ gridTemplateColumns: "1fr" }} onSubmit={submit}>
      <label>
        Ad
        <input value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <label>
        Telefon
        <input value={phone} onChange={(e) => setPhone(e.target.value)} />
      </label>
      <label>
        Mesaj
        <textarea rows={5} value={message} onChange={(e) => setMessage(e.target.value)} required />
      </label>
      {error ? <p className="err">{error}</p> : null}
      <button className="btn" type="submit">
        Gönder
      </button>
    </form>
  );
}
