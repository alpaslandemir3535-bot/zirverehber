"use client";

import type { SeoPost } from "@/lib/seo-store";
import { useRouter } from "next/navigation";
import { useState } from "react";

export function SeoPostForm({ post }: { post: SeoPost }) {
  const router = useRouter();
  const [title, setTitle] = useState(post.title);
  const [name, setName] = useState(post.name);
  const [body, setBody] = useState(post.body);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    const res = await fetch("/api/seo/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...post, title, name, body }),
    });
    setSaving(false);
    if (!res.ok) {
      setError("Kaydedilemedi.");
      return;
    }
    router.push(`/panel/seo/${post.citySlug}/`);
    router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <label>
        Kısa ad
        <input value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <label className="full">
        Başlık
        <input value={title} onChange={(e) => setTitle(e.target.value)} required />
      </label>
      <label className="full">
        Metin
        <textarea rows={8} value={body} onChange={(e) => setBody(e.target.value)} required />
      </label>
      {error ? <p className="err full">{error}</p> : null}
      <div className="full">
        <button className="btn" disabled={saving}>
          {saving ? "Kaydediliyor..." : "Kaydet"}
        </button>
      </div>
    </form>
  );
}
