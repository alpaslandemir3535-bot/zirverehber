import { sortListings, type Listing } from "./listing-types";
import { vipBoardOpen } from "./settings";

export function splitVipListings(listings: Listing[]) {
  if (!vipBoardOpen()) return { vip: [] as Listing[], rest: listings };
  const vip = sortListings(listings.filter((item) => item.featured)).slice(0, 2);
  const ids = new Set(vip.map((item) => item.id));
  return { vip, rest: listings.filter((item) => !ids.has(item.id)) };
}
