import { FaqList } from "@/components/FaqList";
import { homeFaqs } from "@/lib/faq";

export function HomeInfo({ liveCount }: { liveCount: number }) {
  return (
    <div className="home-info">
      <section className="faq-block">
        <h2>Zirve Rehber nedir?</h2>
        <p>
          Zirve Rehber, Türkiye'nin 81 ili için güncel escort ilanlarını tek yerde toplayan bir ilan rehberidir.
          Her ilin kendi sayfası vardır; ilanlar il sayfasında listelenir, kart açılınca fotoğraflar, yaş ve konum
          bilgisi ile iletişim numarası görünür.
        </p>
      </section>
      <section className="faq-block">
        <h2>Escort ilanları nasıl bulunur?</h2>
        <p>
          Aşağıdaki il listesinden şehrini seç ya da ana sayfadaki ilanlara göz at. Beğendiğin ilana dokun, detay
          sayfasında WhatsApp bağlantısını kullanarak ilan sahibine doğrudan yaz. VIP alanındaki ilanlar sayfanın en
          üstünde ayrı gösterilir.
        </p>
      </section>
      <FaqList title="Sık sorulan sorular" faqs={homeFaqs(liveCount)} />
    </div>
  );
}
