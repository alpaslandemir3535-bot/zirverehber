import { CityLinks, SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { rehberOrigin } from "@/lib/site";

export default function NotFound() {
  return (
    <main>
      <SiteHeader title="Zirve Escort" href={`${rehberOrigin()}/`} />
      <header className="archive-page-header">
        <h1>Sayfa yok</h1>
        <p className="archive-description">Aradığın adres bulunamadı. İllerden birine geç.</p>
      </header>
      <CityLinks />
      <SiteFooter />
    </main>
  );
}
