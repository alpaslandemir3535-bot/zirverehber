"use client";

import { useState } from "react";
import { usePathname } from "next/navigation";

const links = [
  { href: "/panel/", label: "Dashboard", match: (path: string) => path === "/panel" || path === "/panel/" },
  { href: "/panel/gsc/", label: "Search Console", match: (path: string) => path.startsWith("/panel/gsc") },
  { href: "/panel/ilanlar/", label: "İlanlar", match: (path: string) => path.startsWith("/panel/ilanlar") || path.startsWith("/panel/ilan/") },
  { href: "/panel/sahipler/", label: "İlan sahipleri", match: (path: string) => path.startsWith("/panel/sahipler") },
  { href: "/panel/odemeler/", label: "Ödemeler", match: (path: string) => path.startsWith("/panel/odemeler") },
  { href: "/panel/yoneticiler/", label: "Yöneticiler", match: (path: string) => path.startsWith("/panel/yoneticiler") },
  { href: "/panel/ayarlar/", label: "Ayarlar", match: (path: string) => path.startsWith("/panel/ayarlar") },
];

const seoLinks = [
  {
    href: "/panel/seo/",
    label: "Seo ilan yazıları",
    match: (path: string) =>
      path.startsWith("/panel/seo") &&
      !path.startsWith("/panel/seo/aciklama"),
  },
  { href: "/panel/seo/aciklama/", label: "Google açıklaması", match: (path: string) => path.startsWith("/panel/seo/aciklama") },
];

export function PanelNav({ siteHref = "/ilanlar/" }: { siteHref?: string }) {
  const pathname = usePathname();
  const seoHere = pathname.startsWith("/panel/seo");
  const [seoOpen, setSeoOpen] = useState(seoHere);
  const beforeSettings = links.filter((link) => link.href !== "/panel/ayarlar/");
  const settings = links.find((link) => link.href === "/panel/ayarlar/");

  return (
    <aside className="panel-side">
      <a className="panel-brand" href="/panel/">
        <span className="panel-brand-mark">Z</span>
        <span>
          <strong>Zirve</strong>
          <em>Yönetim</em>
        </span>
      </a>
      <nav>
        {beforeSettings.map((link) => (
          <a key={link.href} href={link.href} className={link.match(pathname) ? "on" : ""}>
            {link.label}
          </a>
        ))}
        <div className={`nav-group${seoOpen || seoHere ? " open" : ""}`}>
          <button type="button" className={seoHere ? "on" : ""} onClick={() => setSeoOpen((open) => !open)} aria-expanded={seoOpen || seoHere}>
            Seo ayarları
          </button>
          {seoOpen || seoHere ? (
            <div className="nav-sub">
              {seoLinks.map((link) => (
                <a key={link.href} href={link.href} className={link.match(pathname) ? "on" : ""}>
                  {link.label}
                </a>
              ))}
            </div>
          ) : null}
        </div>
        {settings ? (
          <a href={settings.href} className={settings.match(pathname) ? "on" : ""}>
            {settings.label}
          </a>
        ) : null}
      </nav>
      <div className="panel-side-foot">
        <a href="/panel/ilan/yeni/" className="btn">
          Yeni ilan
        </a>
        <a className="side-quiet" href={siteHref} target="_blank" rel="noreferrer">
          Siteyi aç
        </a>
        <form action="/api/auth/logout" method="post">
          <button className="btn ghost" type="submit">
            Çıkış
          </button>
        </form>
      </div>
    </aside>
  );
}
