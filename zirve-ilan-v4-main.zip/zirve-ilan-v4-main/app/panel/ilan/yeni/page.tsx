import { ListingForm } from "@/components/panel/ListingForm";
import { getOwners } from "@/lib/users";

export const dynamic = "force-dynamic";

export default function NewListingPage() {
  const owners = getOwners().map(({ passwordHash: _h, ...owner }) => owner);
  return (
    <>
      <div className="panel-row">
        <h1>Yeni ilan</h1>
        <a className="btn secondary" href="/panel/ilanlar/">
          Listeye dön
        </a>
      </div>
      <ListingForm owners={owners} />
    </>
  );
}
