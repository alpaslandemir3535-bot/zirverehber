import { randomUUID } from "crypto";
import path from "path";
import type { City } from "./cities";
import { readJsonFile, writeJsonFile } from "./json-file";
import { expiryFrom } from "./listing-clock";
import {
  isListingLive,
  sortListings,
  toPhoneDigits,
  type Listing,
  type ListingDuration,
  type ListingInput,
} from "./listing-types";
import { getSettings, saveSettings } from "./settings";
import { toSlug } from "./to-slug";

const dataDir = path.join(process.cwd(), "data");
const dataFile = path.join(dataDir, "listings.json");

function uniqueSlug(base: string, listings: Listing[], ignoreId?: string) {
  let slug = base || "ilan";
  let n = 2;
  while (listings.some((item) => item.slug === slug && item.id !== ignoreId)) {
    slug = `${base}-${n}`;
    n += 1;
  }
  return slug;
}

function schedule(
  input: ListingInput,
  previous?: Listing,
): Pick<Listing, "startedAt" | "expiresAt" | "expiryNoticeAt"> {
  if (input.status !== "published") {
    return {
      startedAt: previous?.startedAt ?? null,
      expiresAt: previous?.expiresAt ?? null,
      expiryNoticeAt: previous?.expiryNoticeAt ?? null,
    };
  }
  const reset =
    !previous ||
    previous.status !== "published" ||
    previous.duration !== input.duration ||
    !previous.expiresAt ||
    new Date(previous.expiresAt).getTime() <= Date.now();
  const startedAt = reset ? new Date().toISOString() : previous.startedAt || new Date().toISOString();
  return {
    startedAt,
    expiresAt: expiryFrom(startedAt, input.duration),
    expiryNoticeAt: reset ? null : previous?.expiryNoticeAt ?? null,
  };
}

function normalize(input: ListingInput, previous?: Listing, existing: Listing[] = []): Listing {
  const now = new Date().toISOString();
  const gallery = input.gallery.filter(Boolean);
  const cover = input.cover || gallery[0] || "";
  const images = coverFirst(cover, gallery);
  const { startedAt, expiresAt, expiryNoticeAt } = schedule(input, previous);
  return {
    id: previous?.id ?? randomUUID(),
    slug: uniqueSlug(toSlug(input.name), existing, previous?.id),
    name: input.name.trim(),
    displayName: input.displayName.trim() || input.name.trim(),
    category: input.category,
    phone: input.phone.trim(),
    phoneDigits: toPhoneDigits(input.phone),
    age: Number(input.age) || 21,
    height: Number(input.height) || 0,
    weight: Number(input.weight) || 0,
    bio: input.bio.trim(),
    cover,
    gallery: images,
    cities: [...new Set(input.cities)],
    districts: [...new Set(input.districts || [])],
    ownerId: input.ownerId || null,
    featured: Boolean(input.featured),
    gold: Boolean(input.gold),
    yeni: Boolean(input.yeni),
    eldenOdeme: Boolean(input.eldenOdeme),
    evOtelApart: Boolean(input.evOtelApart),
    gercekGoruntu: Boolean(input.gercekGoruntu),
    extraMarks: input.extraMarks || [],
    sortOrder: Number(input.sortOrder) || 0,
    status: input.status,
    duration: input.duration,
    startedAt,
    expiresAt,
    createdAt: previous?.createdAt ?? now,
    updatedAt: now,
    expiryNoticeAt,
  };
}

// Kapak her yerde ilk sırada dursun: vitrin kartı listenin başındaki fotoğrafı gösterir.
function coverFirst(cover: string, gallery: string[]) {
  const rest = gallery.filter((item) => item && item !== cover);
  return cover ? [cover, ...rest] : rest;
}

function migrate(listing: Listing): Listing {
  const gallery = Array.isArray(listing.gallery) ? listing.gallery.filter(Boolean) : [];
  const cover = listing.cover || gallery[0] || "";
  return {
    ...listing,
    cover,
    gallery: coverFirst(cover, gallery),
    districts: listing.districts || [],
    ownerId: listing.ownerId ?? null,
    gold: Boolean(listing.gold),
    yeni: Boolean(listing.yeni),
    height: Number(listing.height) || 0,
    weight: Number(listing.weight) || 0,
    eldenOdeme: listing.eldenOdeme ?? true,
    evOtelApart: listing.evOtelApart ?? false,
    gercekGoruntu: listing.gercekGoruntu ?? false,
    extraMarks: Array.isArray(listing.extraMarks) ? listing.extraMarks : [],
    expiryNoticeAt: listing.expiryNoticeAt ?? null,
  };
}

function shuffleListings<T>(items: T[]) {
  const next = [...items];
  for (let i = next.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = next[i];
    next[i] = next[j];
    next[j] = tmp;
  }
  return next;
}

function liveListings() {
  return readListings().filter((item) => isListingLive(item));
}

export function readListings(): Listing[] {
  const raw = readJsonFile<Listing[]>(dataFile, []);
  return (Array.isArray(raw) ? raw : []).filter((item) => item && typeof item === "object").map(migrate);
}

function writeListings(listings: Listing[]) {
  writeJsonFile(dataFile, listings);
}

export function getAllListings() {
  return sortListings(readListings());
}

export function getPublishedListings() {
  const live = liveListings();
  if (getSettings().shuffleListings !== false) return shuffleListings(live);
  return sortListings(live);
}

export function listingsForCity(city: City | null) {
  const live = getPublishedListings();
  if (!city) return live;
  return live.filter((item) => item.cities.includes(city.slug));
}

export function listingBySlug(slug: string) {
  return liveListings().find((item) => item.slug === slug) ?? null;
}

export function markExpiryNotices(ids: string[], at: string) {
  if (!ids.length) return;
  const wanted = new Set(ids);
  const listings = readListings();
  let changed = false;
  for (const item of listings) {
    if (!wanted.has(item.id)) continue;
    item.expiryNoticeAt = at;
    changed = true;
  }
  if (changed) writeListings(listings);
}

export function listingById(id: string) {
  return readListings().find((item) => item.id === id) ?? null;
}

export function createListing(input: ListingInput) {
  const listings = readListings();
  const listing = normalize(input, undefined, listings);
  listings.unshift(listing);
  writeListings(listings);
  return listing;
}

export function updateListing(id: string, input: ListingInput, keepSchedule = false) {
  const listings = readListings();
  const index = listings.findIndex((item) => item.id === id);
  if (index < 0) return null;
  const previous = listings[index];
  const listing = normalize(input, previous, listings);
  if (keepSchedule) {
    listing.startedAt = previous.startedAt;
    listing.expiresAt = previous.expiresAt;
    listing.expiryNoticeAt = previous.expiryNoticeAt;
    listing.duration = previous.duration;
    listing.status = previous.status;
  }
  listings[index] = listing;
  writeListings(listings);
  if (listing.featured && !previous.featured) saveSettings({ vipArea: true });
  return listing;
}

export function setListingFeatured(id: string, featured: boolean) {
  const listings = readListings();
  const index = listings.findIndex((item) => item.id === id);
  if (index < 0) return null;
  const previous = listings[index];
  listings[index] = { ...previous, featured, updatedAt: new Date().toISOString() };
  writeListings(listings);
  if (featured && !previous.featured) saveSettings({ vipArea: true });
  return listings[index];
}

export function setListingStatus(id: string, status: Listing["status"]) {
  const current = listingById(id);
  if (!current) return null;
  return updateListing(id, { ...current, status });
}

export function deleteListing(id: string) {
  const listings = readListings();
  const next = listings.filter((item) => item.id !== id);
  if (next.length === listings.length) return false;
  writeListings(next);
  return true;
}

export function renewListing(id: string, duration?: ListingDuration) {
  const listings = readListings();
  const index = listings.findIndex((item) => item.id === id);
  if (index < 0) return null;
  const current = listings[index];
  const nextDuration = duration === "days3" || duration === "week" || duration === "month" ? duration : current.duration;
  const startedAt = new Date().toISOString();
  listings[index] = {
    ...current,
    status: "published",
    duration: nextDuration,
    startedAt,
    expiresAt: expiryFrom(startedAt, nextDuration),
    expiryNoticeAt: null,
    updatedAt: startedAt,
  };
  writeListings(listings);
  return listings[index];
}

export function listingsForOwner(ownerId: string) {
  return sortListings(readListings().filter((item) => item.ownerId === ownerId));
}

export function detachOwner(ownerId: string) {
  const listings = readListings();
  const now = new Date().toISOString();
  let count = 0;
  for (const item of listings) {
    if (item.ownerId !== ownerId) continue;
    item.ownerId = null;
    item.updatedAt = now;
    count += 1;
  }
  if (count) writeListings(listings);
  return count;
}

export function reorderListings(ids: string[]) {
  const listings = readListings();
  const byId = new Map(listings.map((item) => [item.id, item]));
  ids.forEach((id, index) => {
    const item = byId.get(id);
    if (item) item.sortOrder = index;
  });
  writeListings(listings);
  return getAllListings();
}
