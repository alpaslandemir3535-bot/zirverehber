import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { isTrc20Address } from "@/lib/payments";
import { saveSettings } from "@/lib/settings";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { marketTrc20Address?: string } | null;
  const address = (body?.marketTrc20Address || "").trim();
  if (address && !isTrc20Address(address)) {
    return NextResponse.json({ error: "TRC20 adresi T ile başlayan 34 karakter olmalı." }, { status: 400 });
  }
  saveSettings({ marketTrc20Address: address });
  return NextResponse.json({ ok: true });
}
