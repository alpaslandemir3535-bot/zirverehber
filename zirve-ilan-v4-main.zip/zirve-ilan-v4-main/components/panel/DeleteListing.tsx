"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function DeleteListing({ id }: { id: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function remove() {
    if (!confirm("İlan silinsin mi? Yayından kaldırmak için durumu Gizli yapman yeterli.")) return;
    setBusy(true);
    const res = await fetch(`/api/listings/${id}`, { method: "DELETE" });
    setBusy(false);
    if (res.ok) {
      router.push("/panel/");
      router.refresh();
    }
  }

  return (
    <button className="btn danger" type="button" onClick={remove} disabled={busy}>
      {busy ? "Siliniyor..." : "İlanı sil"}
    </button>
  );
}
