import { AnalyticsBeacon } from "@/components/AnalyticsBeacon";
import { GoogleAnalytics } from "@/components/GoogleAnalytics";
import { faviconHref, getSettings } from "@/lib/settings";
import { rehberOrigin } from "@/lib/site";
import type { Metadata, Viewport } from "next";
import type { CSSProperties } from "react";
import { sharpFontClass } from "@/lib/vitrin-fonts";
import { Playfair_Display, Righteous } from "next/font/google";
import "./globals.css";

const righteous = Righteous({
  weight: "400",
  subsets: ["latin"],
  display: "swap",
  variable: "--font-righteous",
  preload: true,
});

const playfair = Playfair_Display({
  weight: ["500", "600"],
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-playfair",
});

export const dynamic = "force-dynamic";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export function generateMetadata(): Metadata {
  const icon = faviconHref();
  return {
    metadataBase: new URL(rehberOrigin()),
    title: "Zirve İlan",
    description: "Güncel escort ilan vitrini",
    icons: {
      icon: [{ url: icon }],
      shortcut: icon,
      apple: icon,
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const settings = getSettings();
  const icon = faviconHref();
  const theme = {
    "--theme-color": settings.themeColor,
    "--text-color": settings.textColor,
    "--ilan-ver": settings.ilanVerColor,
    "--ilan-ver-text": settings.ilanVerTextColor,
    "--side-left": settings.sideLeftColor,
    "--side-right": settings.sideRightColor,
    "--side-size": `${settings.sideFontSize}px`,
    "--main-color": settings.themeColor,
  } as CSSProperties;
  return (
    <html lang="tr" className={`${righteous.variable} ${playfair.variable} ${sharpFontClass}`} style={theme}>
      <head>
        <meta name="theme-color" content={settings.themeColor} />
        <link rel="icon" href={icon} />
        <link rel="apple-touch-icon" href={settings.favicon || "/apple-touch-icon.png"} />
        <meta name="rating" content="adult" />
        <meta name="mobile-web-app-capable" content="yes" />
        {settings.gscVerifyMeta ? <meta name="google-site-verification" content={settings.gscVerifyMeta} /> : null}
      </head>
      <body>
        <GoogleAnalytics measurementId={settings.gaMeasurementId} />
        <AnalyticsBeacon />
        {children}
      </body>
    </html>
  );
}
