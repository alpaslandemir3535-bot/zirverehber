import { VitrinHome } from "@/components/VitrinHome";
import { VisitorCity } from "@/components/VisitorCity";
import { cities, cityBySlug } from "@/lib/cities";
import { listingsForCity } from "@/lib/listings";
import { cityPagePath, rehberUrl } from "@/lib/site";
import { toSlug } from "@/lib/to-slug";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ sehir?: string }> };

function cityFromQuery(sehir?: string) {
  if (!sehir) return null;
  return cities.find((item) => item.name === sehir) || cityBySlug(toSlug(sehir)) || null;
}

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  const { sehir } = await searchParams;
  const city = cityFromQuery(sehir);
  if (city) {
    return {
      title: `${city.name} Escort`,
      robots: { index: false, follow: true },
      alternates: { canonical: rehberUrl(cityPagePath(city.slug)) },
    };
  }
  return {
    title: "İlanlar",
    robots: { index: false, follow: true, nocache: true },
  };
}

export default async function IlanlarPage({ searchParams }: Props) {
  const { sehir } = await searchParams;
  const city = cityFromQuery(sehir);
  const listings = listingsForCity(city);
  const title = city ? `${city.name} Escort` : "Zirve Escort";

  return (
    <main>
      <VisitorCity />
      <VitrinHome
        title={title}
        kicker={city ? `${city.name.toLocaleUpperCase("tr-TR")} ESCORT - VİP - GERÇEK BAYANLAR` : "ZİRVE ESCORT - VİP - GERÇEK BAYANLAR"}
        listings={listings}
        cityName={city?.name}
        city={city}
      />
    </main>
  );
}
