"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function RehberDescriptionForm({ description }: { description: string }) {
  const router = useRouter();
  const [text, setText] = useState(description);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/seo/description/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rehberDescription: text }),
    });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Kaydedildi." : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <p className="full muted">
        www.zirverehber.com Google aramasında başlığın altında görünen açıklama. Google genelde ilk 150–160 karakteri gösterir.
      </p>
      <label className="full">
        Google açıklaması
        <textarea rows={4} maxLength={320} value={text} onChange={(event) => setText(event.target.value)} required />
      </label>
      <p className="full muted">{text.trim().length}/320</p>
      <div className="full row-actions">
        <button className="btn" type="submit" disabled={busy}>
          Kaydet
        </button>
        {message ? <span className="muted">{message}</span> : null}
      </div>
    </form>
  );
}
