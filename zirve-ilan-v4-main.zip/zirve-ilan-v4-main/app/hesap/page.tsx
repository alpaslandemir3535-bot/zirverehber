import { OwnerPay } from "@/components/hesap/OwnerPay";
import { whatsappForListing } from "@/lib/analytics";
import { ownerTokenFromCookie } from "@/lib/auth";
import { expiryLabel, expiringListings } from "@/lib/expiry";
import { isListingEnded, isListingLive } from "@/lib/listing-types";
import { latestPaymentForListing } from "@/lib/payments";
import { isPayPlan } from "@/lib/pay-plans";
import { getSettings } from "@/lib/settings";
import { listingsForOwner } from "@/lib/store";
import { ownerFromToken } from "@/lib/users";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function OwnerHomePage() {
  const owner = await ownerFromToken(await ownerTokenFromCookie());
  if (!owner) redirect("/hesap/login/");
  const listings = listingsForOwner(owner.id);
  const soon = expiringListings().filter((item) => item.ownerId === owner.id);
  const address = getSettings().trc20Address.trim();

  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Hesabım</p>
          <h1>İlanlarım ({listings.length})</h1>
        </div>
      </div>
      {soon.length ? (
        <div className="warn-banner">
          <strong>Süresi bitmek üzere</strong>
          <ul>
            {soon.map((item) => (
              <li key={item.id}>
                {item.displayName} — {item.expiresAt ? expiryLabel(item.expiresAt) : ""}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      <OwnerPay
        address={address}
        items={listings.map((listing) => {
          const payment = latestPaymentForListing(listing.id, owner.id);
          const state = payment?.status === "waiting" || payment?.status === "rejected" ? payment.status : "none";
          const wa = whatsappForListing(listing.id);
          return {
            id: listing.id,
            displayName: listing.displayName,
            category: listing.category,
            ended: isListingEnded(listing),
            live: isListingLive(listing),
            hidden: listing.status === "hidden",
            payment: state,
            plan: payment && isPayPlan(payment.plan) ? payment.plan : null,
            amountUsd: payment?.amountUsd ?? null,
            note: payment?.note || "",
            startedAt: listing.startedAt,
            expiresAt: listing.expiresAt,
            waToday: wa.today,
            waWeek: wa.week,
          };
        })}
      />
    </>
  );
}
