import { cities } from "./cities";

const EXTRA: Record<string, string[]> = {
  adana: ["Seyhan", "Çukurova", "Yüreğir", "Sarıçam", "Ceyhan"],
  adiyaman: ["Merkez", "Kahta", "Besni"],
  afyonkarahisar: ["Merkez", "Sandıklı", "Bolvadin"],
  agri: ["Merkez", "Doğubayazıt", "Patnos"],
  amasya: ["Merkez", "Merzifon", "Suluova"],
  ankara: ["Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Etimesgut", "Sincan", "Altındağ", "Pursaklar", "Gölbaşı", "Çayyolu"],
  antalya: ["Muratpaşa", "Konyaaltı", "Kepez", "Lara", "Alanya", "Manavgat", "Serik"],
  artvin: ["Merkez", "Hopa", "Arhavi"],
  aydin: ["Efeler", "Kuşadası", "Didim", "Söke", "Nazilli"],
  balikesir: ["Altıeylül", "Karesi", "Edremit", "Bandırma", "Ayvalık"],
  bilecik: ["Merkez", "Bozüyük"],
  bingol: ["Merkez"],
  bitlis: ["Merkez", "Tatvan"],
  bolu: ["Merkez"],
  burdur: ["Merkez"],
  bursa: ["Nilüfer", "Osmangazi", "Yıldırım", "Mudanya", "Gemlik"],
  canakkale: ["Merkez", "Kepez", "Biga"],
  cankiri: ["Merkez"],
  corum: ["Merkez"],
  denizli: ["Merkezefendi", "Pamukkale", "Çivril"],
  diyarbakir: ["Kayapınar", "Bağlar", "Yenişehir", "Sur"],
  edirne: ["Merkez", "Keşan"],
  elazig: ["Merkez"],
  erzincan: ["Merkez"],
  erzurum: ["Yakutiye", "Palandöken", "Aziziye"],
  eskisehir: ["Odunpazarı", "Tepebaşı"],
  gaziantep: ["Şahinbey", "Şehitkamil", "Oğuzeli"],
  giresun: ["Merkez"],
  gumushane: ["Merkez"],
  hakkari: ["Merkez"],
  hatay: ["Antakya", "İskenderun", "Defne", "Arsuz"],
  isparta: ["Merkez"],
  mersin: ["Yenişehir", "Mezitli", "Toroslar", "Akdeniz", "Tarsus", "Erdemli"],
  istanbul: ["Kadıköy", "Üsküdar", "Ataşehir", "Maltepe", "Pendik", "Kartal", "Beşiktaş", "Şişli", "Beyoğlu", "Bakırköy", "Bahçelievler", "Küçükçekmece", "Bağcılar", "Esenyurt", "Başakşehir", "Sarıyer", "Fatih", "Beylikdüzü"],
  izmir: ["Konak", "Karşıyaka", "Bornova", "Buca", "Bayraklı", "Çiğli", "Gaziemir", "Karabağlar", "Alsancak", "Balçova"],
  kars: ["Merkez"],
  kastamonu: ["Merkez"],
  kayseri: ["Melikgazi", "Kocasinan", "Talas"],
  kirklareli: ["Merkez", "Lüleburgaz"],
  kirsehir: ["Merkez"],
  kocaeli: ["İzmit", "Gebze", "Körfez", "Derince", "Gölcük", "Darıca"],
  konya: ["Selçuklu", "Meram", "Karatay"],
  kutahya: ["Merkez"],
  malatya: ["Battalgazi", "Yeşilyurt"],
  manisa: ["Yunusemre", "Şehzadeler", "Turgutlu", "Akhisar", "Salihli", "Alaşehir", "Sarıgöl"],
  kahramanmaras: ["Onikişubat", "Dulkadiroğlu"],
  mardin: ["Artuklu", "Kızıltepe", "Midyat"],
  mugla: ["Menteşe", "Bodrum", "Marmaris", "Fethiye", "Datça", "Milas"],
  mus: ["Merkez"],
  nevsehir: ["Merkez", "Ürgüp", "Avanos"],
  nigde: ["Merkez"],
  ordu: ["Altınordu", "Ünye", "Fatsa"],
  rize: ["Merkez"],
  sakarya: ["Adapazarı", "Serdivan", "Erenler"],
  samsun: ["İlkadım", "Atakum", "Canik", "Tekkeköy"],
  siirt: ["Merkez"],
  sinop: ["Merkez"],
  sivas: ["Merkez"],
  tekirdag: ["Süleymanpaşa", "Çorlu", "Çerkezköy"],
  tokat: ["Merkez"],
  trabzon: ["Ortahisar", "Akçaabat", "Yomra"],
  tunceli: ["Merkez"],
  sanliurfa: ["Eyyübiye", "Haliliye", "Karaköprü", "Siverek"],
  usak: ["Merkez"],
  van: ["İpekyolu", "Tuşba", "Edremit"],
  yozgat: ["Merkez"],
  zonguldak: ["Merkez", "Kozlu", "Ereğli"],
  aksaray: ["Merkez"],
  bayburt: ["Merkez"],
  karaman: ["Merkez"],
  kirikkale: ["Merkez"],
  batman: ["Merkez"],
  sirnak: ["Merkez", "Cizre"],
  bartin: ["Merkez", "Amasra"],
  ardahan: ["Merkez"],
  igdir: ["Merkez"],
  yalova: ["Merkez", "Çınarcık"],
  karabuk: ["Merkez", "Safranbolu"],
  kilis: ["Merkez"],
  osmaniye: ["Merkez", "Kadirli"],
  duzce: ["Merkez", "Konuralp"],
};

export function districtsFor(citySlug: string) {
  return EXTRA[citySlug] || ["Merkez"];
}

export function fullCoverage() {
  const slugs = cities.map((city) => city.slug);
  return {
    cities: slugs,
    districts: slugs.flatMap((slug) => districtsFor(slug).map((name) => `${slug}:${name}`)),
  };
}

export function allDistrictOptions() {
  return cities.flatMap((city) =>
    districtsFor(city.slug).map((name) => ({
      citySlug: city.slug,
      cityName: city.name,
      name,
      key: `${city.slug}:${name}`,
    })),
  );
}

export function parseDistrictKey(key: string) {
  const [citySlug, ...rest] = key.split(":");
  return { citySlug, name: rest.join(":") };
}
