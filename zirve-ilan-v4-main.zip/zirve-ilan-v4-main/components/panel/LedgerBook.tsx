"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { formatMoney, type MoneyCurrency } from "@/lib/pay-plans";
import type { LedgerBoard, LedgerKind, MoneySplit } from "@/lib/ledger";

export function LedgerBook({ week, month, today }: { week: LedgerBoard; month: LedgerBoard; today: string }) {
  const router = useRouter();
  const [span, setSpan] = useState<"week" | "month">("month");
  const [kind, setKind] = useState<LedgerKind>("expense");
  const [currency, setCurrency] = useState<MoneyCurrency>("usd");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(today);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const period = span === "week" ? week : month;

  async function add(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/ledger", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, amountUsd: amount, currency, note, date }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(json.error || "Eklenemedi.");
      return;
    }
    setAmount("");
    setNote("");
    router.refresh();
  }

  async function remove(id: string) {
    setError("");
    const res = await fetch(`/api/ledger/${id}`, { method: "DELETE" });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(json.error || "Silinemedi.");
      return;
    }
    router.refresh();
  }

  return (
    <>
      <div className="books">
        <Book title="Bu hafta" board={week} />
        <Book title="Bu ay" board={month} />
      </div>

      <div className="panel-card">
        <div className="panel-row">
          <div>
            <h2>Hareketler</h2>
            <p className="muted">{period.label}</p>
          </div>
          <div className="row-actions">
            <button className={span === "week" ? "btn" : "btn secondary"} type="button" onClick={() => setSpan("week")}>
              Haftalık
            </button>
            <button className={span === "month" ? "btn" : "btn secondary"} type="button" onClick={() => setSpan("month")}>
              Aylık
            </button>
          </div>
        </div>
        {period.entries.length ? (
          <table>
            <thead>
              <tr>
                <th>Tarih</th>
                <th>Tür</th>
                <th>Kullanıcı</th>
                <th>Tutar</th>
                <th>Not</th>
                <th>Kaynak</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {period.entries.map((item) => (
                <tr key={item.id}>
                  <td>{new Date(item.at).toLocaleString("tr-TR", { timeZone: "Europe/Istanbul" })}</td>
                  <td className={item.kind === "income" ? "money-in" : "money-out"}>{item.kind === "income" ? "Gelir" : "Gider"}</td>
                  <td>{item.ownerUsername || "—"}</td>
                  <td className={item.kind === "income" ? "money-in" : "money-out"}>{formatMoney(item.amountUsd, item.currency)}</td>
                  <td>{item.note || "—"}</td>
                  <td>{item.source === "payment" ? "Ödeme" : "Elle"}</td>
                  <td>
                    {item.source === "manual" ? (
                      <button className="btn ghost" type="button" onClick={() => remove(item.id)}>
                        Sil
                      </button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>Bu dönemde hareket yok.</p>
        )}
      </div>

      <div className="panel-card" style={{ marginTop: 16 }}>
        <h2>Elle gelir / gider</h2>
        <form className="form-grid" onSubmit={add}>
          <label>
            Tür
            <select value={kind} onChange={(event) => setKind(event.target.value as LedgerKind)}>
              <option value="income">Gelir</option>
              <option value="expense">Gider</option>
            </select>
          </label>
          <label>
            Para birimi
            <select value={currency} onChange={(event) => setCurrency(event.target.value as MoneyCurrency)}>
              <option value="usd">Dolar ($)</option>
              <option value="tl">Türk lirası (₺)</option>
            </select>
          </label>
          <label>
            Tutar
            <input inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} required placeholder={currency === "tl" ? "10000" : "400"} />
          </label>
          <label>
            Tarih
            <input type="date" value={date} onChange={(event) => setDate(event.target.value)} required />
          </label>
          <label className="full">
            Not
            <textarea className="pay-note" maxLength={300} value={note} onChange={(event) => setNote(event.target.value)} placeholder="İsteğe bağlı" />
          </label>
          {error ? <p className="err full">{error}</p> : null}
          <div>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? "Kaydediliyor" : "Ekle"}
            </button>
          </div>
        </form>
      </div>
    </>
  );
}

function moneyClass(tone: "in" | "out" | "net", value: number) {
  if (tone === "in") return "money-in";
  if (tone === "out") return "money-out";
  return value < 0 ? "money-out" : "money-in";
}

function MoneyPair({ pair, tone }: { pair: MoneySplit; tone: "in" | "out" | "net" }) {
  return (
    <strong>
      <span className={moneyClass(tone, pair.usd)}>{formatMoney(pair.usd, "usd")}</span>
      {" · "}
      <span className={moneyClass(tone, pair.tl)}>{formatMoney(pair.tl, "tl")}</span>
    </strong>
  );
}

function Book({ title, board }: { title: string; board: LedgerBoard }) {
  return (
    <article className="book">
      <p className="eyebrow">{title}</p>
      <h2>{board.label}</h2>
      <div className="book-rows">
        <div>
          <span>Gelir</span>
          <MoneyPair pair={board.income} tone="in" />
        </div>
        <div>
          <span>Gider</span>
          <MoneyPair pair={board.expense} tone="out" />
        </div>
        <div>
          <span>Net</span>
          <MoneyPair pair={board.net} tone="net" />
        </div>
      </div>
    </article>
  );
}
