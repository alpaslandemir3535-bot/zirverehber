import { PanelNav } from "@/components/panel/PanelNav";
import { isAdmin } from "@/lib/auth";
import { vitrinListingsUrl } from "@/lib/site";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import "./panel.css";

export const metadata: Metadata = {
  robots: { index: false, follow: false },
  title: "Zirve Panel",
};

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const authed = await isAdmin();
  const gate = (await headers()).get("x-zirve-gate");
  if (gate === "panel" && !authed) redirect("/panel/login/");

  return (
    <div className={authed ? "panel panel-app" : "panel panel-auth"}>
      {authed ? <PanelNav siteHref={process.env.NODE_ENV === "production" ? vitrinListingsUrl() : "/ilanlar/"} /> : null}
      <div className={authed ? "panel-wrap" : "panel-auth-wrap"}>{children}</div>
    </div>
  );
}
