import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { addMarketProduct, marketProducts } from "@/lib/market";
import { parseLedgerAmount } from "@/lib/ledger";
import { getSettings } from "@/lib/settings";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json({ products: marketProducts(), marketTrc20Address: getSettings().marketTrc20Address });
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { name?: string; priceUsd?: unknown; stock?: unknown; image?: string } | null;
  const priceUsd = parseLedgerAmount(body?.priceUsd);
  const stock = Number(body?.stock);
  if (priceUsd == null) return NextResponse.json({ error: "Fiyat 0'dan büyük olmalı." }, { status: 400 });
  const result = addMarketProduct({ name: body?.name || "", priceUsd, stock, image: body?.image || "" });
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true, id: result.product.id });
}
