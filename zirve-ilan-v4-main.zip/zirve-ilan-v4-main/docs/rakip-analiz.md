# Rakip Analiz: Elma Vitrin ağı (Manisa örneği)

Tarih: 11 Eylül 2026  
Kaynak link: Google `goto` → `https://elmavitrin142.monster/manisa-escort/`  
İnceleme yöntemi: canlı tarayıcı, sayfa kaynağı, canonical, görsel/ilan hostları, Google indeks özeti.

Bu belge rakipten **ne gördüğümüzü** ve Zirve İlan için **hangi yolu seçeceğimizi** kaydeder. Cloaking / kapı sayfası kopyası yapılmayacak.

---

## 1. Üç katmanlı yapı (asıl cevap)

Gördüğün “arkada başka, mobilde başka” etkisi tek site değil, **üç ayrı katman**:

| Katman | Domain örneği | Kim görür | Ne işe yarar |
|---|---|---|---|
| SEO kapısı | `manisaarslanyolyardim.com` | Google (başlık, snippet, indeks) | İl kelimesinde sıralama |
| Mobil AMP vitrin | `elmavitrin142.monster/manisa-escort/` | Telefondan tıklayan kullanıcı | Fotoğraflı ilan ızgarası |
| İlan motoru | `vitrinkizi56.xyz` | Kart tıklanınca | Ortak ilan havuzu, foto, WhatsApp |

Google’da görünen adres `manisaarslanyolyardim.com`.  
Mobilde açılan adres `elmavitrin142.monster`.  
Kartlar ve fotoğraflar `vitrinkizi56.xyz` üzerinden geliyor.

Aynı ilan kartları anasayfada da, Manisa sayfasında da, detayın altındaki “popülerler”de de duruyor. 81 ilde “farklı .com, aynı mobil sayfa” hissi buradan geliyor: **vitrin şablonu tek, il parametresi değişiyor.**

---

## 2. Adım adım ne oluyor

### Adım 1 — Google’da .com duruyor

Arama sonucu başlığı:

`Manisa Escort - Manisa Gerçek Escort - Manisa Vip Elit Bayan`

URL:

`https://www.manisaarslanyolyardim.com/`

Domain adı “yol yardım” gibi duruyor; başlık ise escort. Bu, yaşlı / düşmüş `.com` üzerine escort başlık basma kalıbı.

Google’ın indekslediği metin (crawler özeti) şöyle:

- H1: `Manisa Escort`
- Kısa kategori yazısı
- 6 ince yazı başlığı: Hanzade, Okyanus, Oya, Eda, Alara, Gülten
- Fotoğraf ızgarası **yok**

Yani Google önizlemesi sade bir WordPress kategori arşivi.

### Adım 2 — Kullanıcı tıklayınca AMP vitrine düşüyor

Canlı açılan sayfa:

- URL: `https://elmavitrin142.monster/manisa-escort/`
- `canonical`: `https://www.manisaarslanyolyardim.com/`
- WordPress + Better AMP (`better-amp-footer`, `amp-iframe`, `wp-theme-sos`)
- Body class: `archive category category-manisa-escort category-5525`

Üstte mavi bar (`Manisa Escort`), altta siyah “İlan & Şikayet Hattı”, ortada 2 sütun fotoğraf ızgarası.

Sayfanın **en altında** Google’ın gördüğü o 6 yazı duruyor; linkler yine `.com` yazılarına gidiyor. Yani AMP şablon = üstte vitrin + altta SEO metin.

### Adım 3 — Kartlar ortak motora gidiyor

Kart linki:

`https://www.vitrinkizi56.xyz/ilan/elif?sehir=Manisa`

Foto host:

`https://www.vitrinkizi56.xyz/uploads/ads/cover_332x552/...`

`vitrinkizi56.xyz/ilanlar` `noindex`. Bu domain Google’a satılmıyor; sadece vitrin.

### Adım 4 — İl değişince sadece etiket değişiyor

`/manisa-escort/` ile anasayfa (`elmavitrin142.monster/`) aynı kart ızgarası. Fark:

- başlık / H1 / canonical il .com’una bağlanıyor
- kart linkine `?sehir=Manisa` ekleniyor
- alt SEO yazıları il adına göre üretiliyor

81 il = 81 kapı `.com` + 1 AMP tema + 1 ilan havuzu.

---

## 3. Kullandıkları parçalar

### SEO / WordPress katmanı

- WordPress kategori arşivi (`category-manisa-escort`, id `5525`)
- Tema izi: `wp-theme-sos`
- AMP: Better AMP + `cdn.ampproject.org` (`amp-bind`, `amp-iframe`, `amp-sidebar`)
- Canonical ile güç `.com`da toplanıyor
- İnce “ilan yazısı” postları (kapı içeriği)

### Mobil vitrin şablonu

- CSS class’lar: `.ads-itemm`, `.ads-itemm-photo`, `.ads-itemm-photo__SubTitle`, `.elden-odeme`, `.ads-item2--title`, `.ads-item2--phone`, `.grid-container`, `.grid-item`
- Font: Google Fonts `Righteous`
- Renk: mavi header, siyah şikayet barı, kart altı mor/mavi gradient
- Mobilde 2 sütun, genişte 3–4 sütun
- Rozetler: `VİP ESCORT`, `ÜNİVERSİTELİ ESCORT`, `ÖĞRENCİ ESCORT`, `POPÜLER ESCORT`, `SINIRSIZ ESCORT` + `ELDEN ÖDEME`
- `amp-img` 332×552 (yaklaşık 3:5 dikey kapak)

### İlan motoru (`vitrinkizi*.xyz`)

- Sunucu render HTML (Next/Nuxt yok)
- Bootstrap 5.2.3 grid: `row-cols-2` / `md-2` / `lg-3` / `xl-5`
- Kendi CSS: `/site/template_1.css`
- Cloudflare (`cloudflareinsights`)
- `robots: noindex`
- Detay: avatar, kategori + isim, `Konum : Manisa`, yeşil WhatsApp barı, 2’li foto galeri, biyografi, altta aynı ızgara
- Numaralı `.xyz` / `.monster` — yanınca yenisi (`142`, `56`)

### Trafik

- `whos.amung.us` widget: `kirmizielma` (AMP), `burasibizim` (Google özeti)

### Ağ kalıbı (örnekler)

Aynı usul başka illerde de duruyor: masum görünen yerel `.com` + escort başlık.

- Manisa: `manisaarslanyolyardim.com`
- Benzer kapılar: `manisateknoloji.com`, `aksaraysohbet.com`, `erzurumgelinlik.com`

---

## 4. “Arkada farklı / mobilde farklı” nasıl üretiliyor

Gözlenen mekanizma:

1. Google’a satılan sayfa: ince WordPress arşiv (yazı başlıkları, az görsel).
2. Telefona satılan sayfa: AMP ızgara + aynı arşiv altta.
3. `canonical` ile iki görünüm tek `.com` altında birleştiriliyor.
4. Asıl ilan sitesi `noindex`; Google onu sıralamıyor.

Bu, kullanıcının gördüğü ile arama motorunun özetlediği içeriğin ayrılması. Google bunu cloaking / kapı sayfası olarak işler. Kısa süre sıralama getirebilir; ağ yanınca 81 domain birden düşer.

Bu katmanı kopyalamıyoruz.

---

## 5. 81 ayrı .com mı, tek .com mı?

**Tek .com üzerinden ilerle.** 81 ayrı `.com` alma.

### Neden 81 domain rakibe “yardımcı” görünüyor

- Her il için ayrı “taze” domain, `[il] escort` tam eşleşmesi
- Yaşlı / düşmüş `.com` (yol yardım, sohbet, gelinlik) eski backlink ve yaş taşır
- Yanınca sadece o ili kaybederler; AMP / `.xyz` numarasını değiştirirler

### Neden senin için çalışmaz

1. **Yeni alınan 81 `.com` onların silahı değil.** Onlar yaşlı domain + cloaking kullanıyor. Sıfırdan 81 isim almak aynı etkiyi vermez.
2. **Otorite bölünür.** 81 siteye backlink, Search Console, içerik, SSL, DNS = 81 iş. Tek markada biriken güç 81’e dağılır.
3. **Kapı ağı sinyali.** Aynı şablon + aynı ilanlar + 81 domain, Google’ın doorway / site-reputation-abuse kurallarına girer.
4. **Maliyet ve operasyon.** 81 yenileme, 81 ban, 81 yönlendirme. AMP `.monster` zaten sürekli numaralı dönüyor; bu kalıcı marka değil.
5. **İlk sıra garantisi yok.** 81 domain ≠ 81 ilde 1. sıra. Büyük illerde (İstanbul, Ankara, İzmir) rekabet ayrı; küçük ilde ince sayfa bazen çıkar, sonra düşer.

### Tek .com ile 81 ili nasıl hedeflersin

Tek marka (ör. `zirveilan.com`) + dürüst URL’ler:

- `/manisa`
- `/istanbul`
- `/izmir`
- …
- `/ilan/elif`

Aynı mobil ızgara, aynı detay, il adı title/H1/iç linkte değişir. Google’a da kullanıcıya da **aynı sayfa** gider.

Bunu güçlendirenler:

- Her il sayfasında o ile ait gerçek ilan (kopya havuz değil)
- İç link: il → ilçe → ilan
- Tek sitemap, tek Search Console, tek backlink havuzu
- Hızlı mobil sayfa (AMP şart değil; Next/normal HTML yeter)
- WhatsApp CTA, net başlık: `[İl] Escort – …`

İlk sıralar **şehir şehir**, içerik + tıklanma + süre ile gelir. 81 ilde aynı anda 1. sıra diye bir düğme yok; önce 5–10 il, sonra genişletme daha gerçekçi.

---

## 6. Zirve İlan’da kopyalanacak / kopyalanmayacak

### Yapılacak (kullanıcının gördüğü site)

- Mavi üst bar + şehir adı
- Siyah şikayet / iletişim barı
- 2 sütun dikey kapak ızgarası
- Kategori + Elden Ödeme rozeti
- İsim + telefon
- Detay: WhatsApp, galeri, konum, yazı, alt ızgara
- 81 il: tek domain, `/[il]` rotaları
- Admin: ilan ekle, şehir, kategori, foto, telefon, sıralama (VIP / popüler)

### Yapılmayacak

- Googlebot’a başka, kullanıcıya başka HTML
- 81 sahte iş `.com`’u (yol yardım, gelinlik, sohbet)
- Yaşlı domain PBN / kapı ağı
- `canonical` ile .com’a, gövdeyi .monster’a taşıma
- User-agent / bot ayrımı

---

## 7. Önerilen mimari (sonraki adım)

Tek uygulama:

- Frontend: mobil-first ızgara (rakip kart CSS’sine yakın)
- Backend: ilan + şehir + kategori
- SEO: her il için tek sayfa, doğru title, H1, canonical kendine
- İlan detay: `/ilan/[slug]?sehir=` yerine `/[il]/[slug]` (daha temiz)
- Görseller: kendi storage (rakip hostuna bağlanma)

İnceleme bu dosyayla kapandı. Onay sonrası tek `.com` üzerinden birebir **ön yüz** üretimine geçilir.
