import { redirect } from "next/navigation";

export default function OwnerMarketPage() {
  redirect("/hesap/");
}
