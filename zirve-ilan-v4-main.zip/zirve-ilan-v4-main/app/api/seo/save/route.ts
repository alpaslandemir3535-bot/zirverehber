import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { saveSeoPost, type SeoPost } from "@/lib/seo-store";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json()) as Partial<SeoPost>;
  if (!body.citySlug || !body.slug || !body.title?.trim() || !body.body?.trim()) {
    return NextResponse.json({ error: "Başlık ve metin gerekli." }, { status: 400 });
  }
  return NextResponse.json(
    saveSeoPost({
      id: body.id || `${body.citySlug}:${body.slug}`,
      citySlug: body.citySlug,
      slug: body.slug,
      name: body.name || "",
      title: body.title,
      body: body.body,
    }),
  );
}
