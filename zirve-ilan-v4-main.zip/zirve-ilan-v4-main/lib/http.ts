import { timingSafeEqual } from "crypto";
import { NextResponse } from "next/server";

export function sameOrigin(request: Request) {
  const site = request.headers.get("sec-fetch-site");
  if (site === "same-origin") return true;
  if (site === "cross-site") return false;
  const origin = request.headers.get("origin");
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host");
  if (!origin || !host) return false;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export function rejectCrossOrigin(request: Request) {
  if (sameOrigin(request)) return null;
  return NextResponse.json({ error: "Kaynak reddedildi." }, { status: 403 });
}

export function safeEqual(left: string, right: string) {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}
