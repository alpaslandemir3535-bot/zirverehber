import { cities } from "./cities";
import { districtsFor } from "./districts";

const ALIASES: Record<string, string> = {
  afyon: "Afyonkarahisar",
  urfa: "Şanlıurfa",
  icel: "Mersin",
  antakya: "Hatay",
};

function slug(input: string) {
  return String(input || "")
    .replace(/İ/g, "i")
    .replace(/I/g, "ı")
    .toLowerCase()
    .replace(/ı/g, "i")
    .replace(/ğ/g, "g")
    .replace(/ü/g, "u")
    .replace(/ş/g, "s")
    .replace(/ö/g, "o")
    .replace(/ç/g, "c")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

const bySlug = new Map(cities.map((city) => [city.slug, city.name]));
const byDistrict = new Map<string, string>();
for (const city of cities) {
  for (const name of districtsFor(city.slug)) {
    const key = slug(name);
    if (!key || key === "merkez") continue;
    const prev = byDistrict.get(key);
    if (byDistrict.has(key) && prev !== city.name) byDistrict.set(key, "");
    else if (!byDistrict.has(key)) byDistrict.set(key, city.name);
  }
}

function matchPlace(value?: string | null) {
  const key = slug(value || "");
  if (!key) return null;
  const district = byDistrict.get(key);
  return bySlug.get(key) || ALIASES[key] || district || null;
}

function nameFromPlate(regionCode: string) {
  const plate = Number(String(regionCode || "").replace(/\D/g, ""));
  if (!Number.isInteger(plate) || plate < 1 || plate > 81) return null;
  return cities.find((city) => city.plate === plate)?.name || null;
}

function headerValue(source: Headers, name: string) {
  return source.get(name) || source.get(name.toLowerCase()) || "";
}

function isPublicIp(ip: string) {
  const raw = ip.trim().replace(/^::ffff:/i, "");
  if (!raw || raw === "::1") return false;
  if (raw.includes(":")) {
    const lower = raw.toLowerCase();
    if (lower.startsWith("fe80") || lower.startsWith("fc") || lower.startsWith("fd")) return false;
    return true;
  }
  const parts = raw.split(".").map((part) => Number(part));
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  if (parts[0] === 10 || parts[0] === 127 || parts[0] === 0) return false;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return false;
  if (parts[0] === 192 && parts[1] === 168) return false;
  if (parts[0] === 169 && parts[1] === 254) return false;
  return true;
}

function firstPublicIp(source: Headers, name: string) {
  const parts = headerValue(source, name)
    .split(",")
    .map((item) => item.trim().replace(/^::ffff:/i, ""))
    .filter(Boolean);
  return parts.find((item) => isPublicIp(item)) || "";
}

// x-real-ip çoğu sunucuda makinenin kendi adresidir. Önce CDN ve X-Forwarded-For'un
// ilk halkası (gerçek ziyaretçi) kullanılır; yoksa x-real-ip'ye düşülür.
function clientIp(source: Headers) {
  return (
    firstPublicIp(source, "cf-connecting-ip") ||
    firstPublicIp(source, "true-client-ip") ||
    firstPublicIp(source, "x-forwarded-for") ||
    firstPublicIp(source, "x-real-ip")
  );
}

export function browserCity(source: Headers) {
  const raw = headerValue(source, "cookie");
  const match = raw.match(/(?:^|; )zirve_konum=([^;]*)/);
  if (!match) return null;
  try {
    return matchPlace(decodeURIComponent(match[1]));
  } catch {
    return null;
  }
}

export function knownCity(value?: string | null) {
  return matchPlace(value);
}

let devIpPromise: Promise<string> | null = null;

function devPublicIp() {
  if (!devIpPromise) {
    devIpPromise = fetch("https://api.ipify.org", { signal: AbortSignal.timeout(1500) })
      .then((res) => (res.ok ? res.text() : ""))
      .then((text) => text.trim())
      .catch(() => "");
  }
  return devIpPromise;
}

const freshCity = new Map<string, { at: number; city: string | null }>();

async function cityFromNetwork(ip: string) {
  const now = Date.now();
  const saved = freshCity.get(ip);
  if (saved && now - saved.at < 6 * 60 * 60 * 1000) return saved.city;
  try {
    const response = await fetch(`https://ipwho.is/${encodeURIComponent(ip)}`, { signal: AbortSignal.timeout(1500) });
    if (!response.ok) return null;
    const data = (await response.json()) as { success?: boolean; country_code?: string; region_code?: string; city?: string };
    if (!data.success || data.country_code !== "TR") {
      freshCity.set(ip, { at: now, city: null });
      return null;
    }
    const city = matchPlace(data.city) || nameFromPlate(data.region_code || "");
    freshCity.set(ip, { at: now, city: city || null });
    return city;
  } catch {
    return null;
  }
}

export async function visitorCityName(headers: Headers) {
  let ip = clientIp(headers);
  if (!ip && process.env.NODE_ENV !== "production") ip = await devPublicIp();
  if (!isPublicIp(ip)) return null;
  return cityFromNetwork(ip);
}
