import { cityBySlug } from "@/lib/cities";
import { seoPostsForCity } from "@/lib/seo-store";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function SeoCityPage({ params }: { params: Promise<{ city: string }> }) {
  const { city: slug } = await params;
  const city = cityBySlug(slug);
  if (!city) notFound();
  const posts = seoPostsForCity(city);
  const published = new Set(seoPostsForCity(city, "public").map((post) => post.slug));

  return (
    <>
      <div className="panel-row">
        <h1>{city.name} Seo ilan yazıları</h1>
        <a className="btn secondary" href="/panel/seo/">
          İllere dön
        </a>
      </div>
      <div className="panel-card">
        <p className="muted">
          Taslaklar sadece burada durur. Bir yazıyı kaydetmeden siteye ve site haritasına girmez.
        </p>
        <table>
          <thead>
            <tr>
              <th>Başlık</th>
              <th>Durum</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {posts.map((post) => (
              <tr key={post.slug}>
                <td>{post.title}</td>
                <td>{published.has(post.slug) ? "Yayında" : "Taslak"}</td>
                <td>
                  <a className="btn ghost" href={`/panel/seo/${city.slug}/${post.slug}/`}>
                    Düzenle
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
