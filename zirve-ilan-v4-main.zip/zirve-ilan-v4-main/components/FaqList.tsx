import type { Faq } from "@/lib/faq";

// Soru başlık (h3), ilk cümle cevap. Üstteki h2 bölümü verir.
export function FaqList({ title, faqs }: { title: string; faqs: Faq[] }) {
  return (
    <section className="faq-block">
      <h2>{title}</h2>
      {faqs.map((item) => (
        <div key={item.q} className="faq-item">
          <h3>{item.q}</h3>
          <p>{item.a}</p>
        </div>
      ))}
    </section>
  );
}
