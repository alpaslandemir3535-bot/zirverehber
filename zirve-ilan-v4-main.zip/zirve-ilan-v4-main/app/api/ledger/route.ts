import { isAdmin } from "@/lib/auth";
import {
  addManualEntry,
  cleanLedgerNote,
  parseLedgerAmount,
  parseLedgerDate,
  type LedgerKind,
} from "@/lib/ledger";
import { rejectCrossOrigin } from "@/lib/http";
import { isMoneyCurrency } from "@/lib/pay-plans";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as {
    kind?: string;
    amountUsd?: unknown;
    currency?: unknown;
    note?: unknown;
    date?: unknown;
  } | null;
  const kind: LedgerKind | null = body?.kind === "income" || body?.kind === "expense" ? body.kind : null;
  const amountUsd = parseLedgerAmount(body?.amountUsd);
  const currency = isMoneyCurrency(body?.currency) ? body.currency : null;
  const at = parseLedgerDate(body?.date);
  if (!kind) return NextResponse.json({ error: "Gelir veya gider seç." }, { status: 400 });
  if (!currency) return NextResponse.json({ error: "Dolar veya TL seç." }, { status: 400 });
  if (amountUsd == null) return NextResponse.json({ error: "Tutar 0'dan büyük olmalı." }, { status: 400 });
  if (!at) return NextResponse.json({ error: "Tarih geçersiz." }, { status: 400 });
  const entry = addManualEntry({ kind, amountUsd, currency, note: cleanLedgerNote(body?.note), at });
  return NextResponse.json({ ok: true, id: entry.id });
}
