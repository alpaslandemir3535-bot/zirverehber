import { isAdmin } from "@/lib/auth";
import { fetchGscDashboard } from "@/lib/gsc";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const data = await fetchGscDashboard();
  if (!data.ready) return NextResponse.json(data, { status: 400 });
  return NextResponse.json(data);
}
