import { rejectCrossOrigin } from "@/lib/http";
import { visitorCityName } from "@/lib/visitor-city";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Konum izni reddedildiğinde sayfanın son çare olarak sorduğu yer.
// Ziyaretçi yalnızca kendi IP'sinin ilini öğrenir; istekle IP gönderilemez.
export async function GET(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  const city = await visitorCityName(request.headers);
  return NextResponse.json({ city: city || "" }, { headers: { "Cache-Control": "no-store" } });
}
