import { deflateRawSync } from "zlib";
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from "fs";
import path from "path";
import { saveSettings } from "./settings";

const MAX_FILE = 25 * 1024 * 1024;

function crc32(buf: Buffer) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i += 1) {
    c ^= buf[i];
    for (let k = 0; k < 8; k += 1) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return (c ^ 0xffffffff) >>> 0;
}

function dosDate(date: Date) {
  const time = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const day = ((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, day };
}

export function zipFiles(files: { name: string; data: Buffer }[]) {
  const now = new Date();
  const { time, day } = dosDate(now);
  const local: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const file of files) {
    const name = Buffer.from(file.name.replace(/\\/g, "/"), "utf8");
    const deflated = deflateRawSync(file.data);
    const crc = crc32(file.data);
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(8, 8);
    localHeader.writeUInt16LE(time, 10);
    localHeader.writeUInt16LE(day, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(deflated.length, 18);
    localHeader.writeUInt32LE(file.data.length, 22);
    localHeader.writeUInt16LE(name.length, 26);
    local.push(localHeader, name, deflated);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(8, 10);
    centralHeader.writeUInt16LE(time, 12);
    centralHeader.writeUInt16LE(day, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(deflated.length, 20);
    centralHeader.writeUInt32LE(file.data.length, 24);
    centralHeader.writeUInt16LE(name.length, 28);
    centralHeader.writeUInt32LE(offset, 42);
    central.push(centralHeader, name);
    offset += localHeader.length + name.length + deflated.length;
  }
  const centralBuf = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralBuf.length, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, centralBuf, end]);
}

function walk(dir: string, base: string, out: { name: string; data: Buffer }[], skipped: string[]) {
  if (!existsSync(dir)) return;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "backups") continue;
    const abs = path.join(dir, entry.name);
    const rel = path.posix.join(base, entry.name);
    if (entry.isDirectory()) {
      walk(abs, rel, out, skipped);
      continue;
    }
    if (!entry.isFile()) continue;
    const size = statSync(abs).size;
    if (size > MAX_FILE) {
      skipped.push(rel);
      continue;
    }
    out.push({ name: rel, data: readFileSync(abs) });
  }
}

export function buildBackup() {
  const root = process.cwd();
  const files: { name: string; data: Buffer }[] = [];
  const skipped: string[] = [];
  walk(path.join(root, "data"), "data", files, skipped);
  walk(path.join(root, "public", "uploads"), "public/uploads", files, skipped);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  files.unshift({
    name: "manifest.txt",
    data: Buffer.from(
      [`Zirve İlan yedek`, stamp, `dosya: ${files.length}`, skipped.length ? `atlanan: ${skipped.join(", ")}` : "atlanan yok"].join(
        "\n",
      ),
      "utf8",
    ),
  });
  const zip = zipFiles(files);
  const filename = `zirve-yedek-${stamp}.zip`;
  saveSettings({ lastBackupAt: new Date().toISOString() });
  return { filename, zip };
}

export function saveBackupToDir(dir: string) {
  const resolved = path.resolve(dir.trim());
  if (!path.isAbsolute(resolved) || !existsSync(resolved) || !statSync(resolved).isDirectory()) {
    return { error: "Klasör bulunamadı. USB takılı ve yol doğru olmalı." as const };
  }
  if (/windows|system32|program files|programdata/i.test(resolved)) {
    return { error: "Bu klasöre yedek yazılamaz." as const };
  }
  const cwd = path.resolve(process.cwd());
  const rel = path.relative(cwd, resolved);
  if (rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel))) {
    return { error: "Yedek site klasörünün içine yazılamaz." as const };
  }
  const { filename, zip } = buildBackup();
  mkdirSync(resolved, { recursive: true });
  writeFileSync(path.join(resolved, filename), zip);
  return { filename, bytes: zip.length };
}
