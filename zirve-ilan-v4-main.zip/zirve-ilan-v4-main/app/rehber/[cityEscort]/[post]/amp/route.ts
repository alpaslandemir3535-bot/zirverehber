import { postAmpHtml } from "@/lib/amp-html";
import { listingsForCity } from "@/lib/listings";
import { cityFromEscortParam, cityPostBody, cityPostBySlug } from "@/lib/seo";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ cityEscort: string; post: string }> }) {
  const { cityEscort, post: postSlug } = await context.params;
  const city = cityFromEscortParam(cityEscort);
  const post = city ? cityPostBySlug(city, postSlug) : undefined;
  if (!city || !post) return new Response("Bulunamadı", { status: 404 });
  const html = postAmpHtml({
    city,
    title: `${post.title} | ${city.name} Escort`,
    description: cityPostBody(city, post).replace(/\s+/g, " ").slice(0, 160),
    slug: post.slug,
    listings: listingsForCity(city),
  });
  return new Response(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=300",
    },
  });
}
