import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { clearGscCache } from "@/lib/gsc";
import { gaMeasurementId, normalizeThemeColor, noteLine, publicSettings, saveSettings } from "@/lib/settings";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json(publicSettings());
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json()) as {
    telegramBotToken?: string;
    telegramChatId?: string;
    telegramDaily?: boolean;
    ilanVerPhone?: string;
    ilanVerNoteTitle?: string;
    ilanVerNoteBody?: string;
    ilanVerNoteColor?: string;
    ilanVerNoteBodyColor?: string;
    ilanVerNoteBg?: string;
    vitrinIlanTitle?: string;
    vitrinIlanTitleColor?: string;
    vitrinIlanNote?: string;
    vitrinIlanNoteColor?: string;
    vitrinIlanTitleSize?: number;
    vitrinIlanNoteSize?: number;
    waListingMessage?: string;
    gscSiteUrl?: string;
    gscClientEmail?: string;
    gscPrivateKey?: string;
    gscVerifyMeta?: string;
    gaMeasurementId?: string;
  };
  const patch: Record<string, unknown> = {};
  if (typeof body.telegramChatId === "string") {
    patch.telegramChatId = body.telegramChatId.trim();
  }
  if (typeof body.telegramDaily === "boolean") {
    patch.telegramDaily = body.telegramDaily;
  }
  if (typeof body.ilanVerPhone === "string") {
    patch.ilanVerPhone = body.ilanVerPhone.trim();
  }
  if (typeof body.ilanVerNoteTitle === "string") {
    const title = noteLine(body.ilanVerNoteTitle, "", 80);
    if (title) patch.ilanVerNoteTitle = title;
  }
  if (typeof body.ilanVerNoteBody === "string") {
    const text = noteLine(body.ilanVerNoteBody, "", 180);
    if (text) patch.ilanVerNoteBody = text;
  }
  if (typeof body.vitrinIlanTitle === "string") {
    const title = noteLine(body.vitrinIlanTitle, "", 40);
    if (title) patch.vitrinIlanTitle = title;
  }
  if (typeof body.vitrinIlanNote === "string") {
    const text = noteLine(body.vitrinIlanNote, "", 120);
    if (text) patch.vitrinIlanNote = text;
  }
  if (body.vitrinIlanTitleSize != null) {
    const size = Math.round(Number(body.vitrinIlanTitleSize));
    if (size >= 12 && size <= 40) patch.vitrinIlanTitleSize = size;
  }
  if (body.vitrinIlanNoteSize != null) {
    const size = Math.round(Number(body.vitrinIlanNoteSize));
    if (size >= 9 && size <= 22) patch.vitrinIlanNoteSize = size;
  }
  for (const key of ["ilanVerNoteColor", "ilanVerNoteBodyColor", "ilanVerNoteBg", "vitrinIlanTitleColor", "vitrinIlanNoteColor"] as const) {
    if (typeof body[key] !== "string") continue;
    const color = normalizeThemeColor(body[key]);
    if (!color) return NextResponse.json({ error: "Renk # ile başlayan 6 haneli olmalı." }, { status: 400 });
    patch[key] = color;
  }
  if (typeof body.waListingMessage === "string") {
    patch.waListingMessage = body.waListingMessage.trim();
  }
  if (body.telegramBotToken && !body.telegramBotToken.includes("•")) {
    patch.telegramBotToken = body.telegramBotToken.trim();
  }
  if (typeof body.gscSiteUrl === "string") patch.gscSiteUrl = body.gscSiteUrl.trim();
  if (typeof body.gscClientEmail === "string") patch.gscClientEmail = body.gscClientEmail.trim();
  if (typeof body.gscVerifyMeta === "string") patch.gscVerifyMeta = body.gscVerifyMeta.trim();
  if (typeof body.gaMeasurementId === "string") {
    const id = gaMeasurementId(body.gaMeasurementId);
    if (body.gaMeasurementId.trim() && !id) {
      return NextResponse.json({ error: "Ölçüm kimliği G- ile başlamalı. Örnek: G-ABC1234567" }, { status: 400 });
    }
    patch.gaMeasurementId = id;
  }
  if (typeof body.gscPrivateKey === "string" && body.gscPrivateKey.includes("BEGIN")) {
    patch.gscPrivateKey = body.gscPrivateKey.replace(/\\n/g, "\n").trim();
  }
  saveSettings(patch);
  if (patch.gscSiteUrl || patch.gscClientEmail || patch.gscPrivateKey) clearGscCache();
  return NextResponse.json(publicSettings());
}
