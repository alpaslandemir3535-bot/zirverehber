"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function GscSettings({
  gscSiteUrl,
  gscClientEmail,
  gscVerifyMeta,
  gscReady,
  gscPrivateKeyMasked,
}: {
  gscSiteUrl: string;
  gscClientEmail: string;
  gscVerifyMeta: string;
  gscReady: boolean;
  gscPrivateKeyMasked: string;
}) {
  const router = useRouter();
  const [siteUrl, setSiteUrl] = useState(gscSiteUrl);
  const [email, setEmail] = useState(gscClientEmail);
  const [key, setKey] = useState("");
  const [verify, setVerify] = useState(gscVerifyMeta);
  const [jsonText, setJsonText] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  function applyJson() {
    try {
      const parsed = JSON.parse(jsonText) as { client_email?: string; private_key?: string };
      if (parsed.client_email) setEmail(parsed.client_email);
      if (parsed.private_key) setKey(parsed.private_key);
      setMessage("JSON okundu. Kaydet’e bas.");
    } catch {
      setMessage("JSON okunamadı.");
    }
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/telegram/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        gscSiteUrl: siteUrl,
        gscClientEmail: email,
        gscVerifyMeta: verify,
        gscPrivateKey: key || undefined,
      }),
    });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Kaydedildi." : json.error || "Kaydedilemedi.");
    if (res.ok) {
      setKey("");
      setJsonText("");
      router.refresh();
    }
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <div className="full help-box">
        <p>1. Search Console’da zirverehber.com özelliğini ekle.</p>
        <p>2. Google Cloud’da Search Console API’yi aç, servis hesabı JSON indir.</p>
        <p>3. JSON’daki client_email adresini GSC → Ayarlar → Kullanıcılar’a ekle (tam yetki).</p>
        <p>4. Aşağıya site adresini yaz: https://zirverehber.com/ veya sc-domain:zirverehber.com</p>
      </div>
      <label>
        GSC site URL
        <input value={siteUrl} onChange={(e) => setSiteUrl(e.target.value)} placeholder="https://zirverehber.com/" />
      </label>
      <label>
        Servis hesabı e-posta
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="zirve@...iam.gserviceaccount.com" />
      </label>
      <label className="full">
        Doğrulama meta (google-site-verification)
        <input value={verify} onChange={(e) => setVerify(e.target.value)} placeholder="AbCdEf..." />
      </label>
      <label className="full">
        Servis hesabı JSON (yapıştır)
        <textarea rows={4} value={jsonText} onChange={(e) => setJsonText(e.target.value)} />
      </label>
      <div className="full">
        <button className="btn secondary" type="button" onClick={applyJson}>
          JSON’u doldur
        </button>
      </div>
      <label className="full">
        Private key {gscPrivateKeyMasked ? `(${gscPrivateKeyMasked})` : ""}
        <textarea
          rows={4}
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="-----BEGIN PRIVATE KEY-----"
        />
      </label>
      <div className="full row-actions">
        <button className="btn" type="submit" disabled={busy}>
          Kaydet
        </button>
        <span className={gscReady ? "badge published" : "badge draft"}>{gscReady ? "Bağlı" : "Eksik"}</span>
        {message ? <span className="muted">{message}</span> : null}
      </div>
    </form>
  );
}
