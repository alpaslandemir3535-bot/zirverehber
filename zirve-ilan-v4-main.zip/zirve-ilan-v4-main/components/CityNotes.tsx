import type { City } from "@/lib/cities";
import { cityContent } from "@/lib/city-content";

export function CityNotes({ city, photos }: { city: City; photos: string[] }) {
  const { sections } = cityContent(city);
  if (!sections.length) return null;
  const tag = `${city.name} escort`.toLocaleUpperCase("tr-TR");

  return (
    <section className="city-notes" aria-label={`${city.name} escort ilanları`}>
      <h2>{city.name} Escort İlanları</h2>
      {sections.map((section, index) => {
        const photo = photos.length ? photos[index % photos.length] : "";
        return (
          <article key={section.heading} className="city-note">
            {photo ? <img src={photo} alt="" /> : null}
            <div>
              <h3>{section.heading}</h3>
              <p>{section.body}</p>
              <span>{tag}</span>
            </div>
          </article>
        );
      })}
    </section>
  );
}
