import { adminCookie, adminPassword } from "@/lib/auth";
import { ensureDefaultAdmin, verifyAdminLogin } from "@/lib/admins";
import { rejectCrossOrigin } from "@/lib/http";
import { loginBanned, noteLoginFailure, noteLoginSuccess } from "@/lib/login-guard";
import { clientIp } from "@/lib/rate-limit";
import { NextResponse } from "next/server";

const locked = NextResponse.json({ error: "Bu adresten giriş kapatıldı." }, { status: 403 });

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  const ip = clientIp(request);
  if (loginBanned(ip)) return locked;
  const body = (await request.json().catch(() => null)) as {
    username?: string;
    password?: string;
  } | null;
  if (!body?.password?.trim()) {
    return NextResponse.json({ error: "Şifre gerekli." }, { status: 400 });
  }
  ensureDefaultAdmin();
  const username = body.username?.trim() || (body.password === adminPassword() ? "admin" : "");
  const admin = username ? verifyAdminLogin(username, body.password) : null;
  if (!admin) {
    if (noteLoginFailure(ip)) return locked;
    return NextResponse.json({ error: "Kullanıcı veya şifre yanlış." }, { status: 401 });
  }
  noteLoginSuccess(ip);
  const cookie = await adminCookie(admin);
  const response = NextResponse.json({ ok: true });
  response.cookies.set(cookie.name, cookie.value, cookie.options);
  return response;
}
