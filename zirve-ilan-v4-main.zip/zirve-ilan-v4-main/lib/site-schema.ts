import type { Faq } from "./faq";
import { getSettings } from "./settings";
import { rehberOrigin } from "./site";

export function jsonLdScript(data: unknown) {
  return JSON.stringify(data).split("<").join("\\u003c");
}

export const ORGANIZATION_ID = () => `${rehberOrigin()}/#organization`;
export const WEBSITE_ID = () => `${rehberOrigin()}/#website`;

function absolute(url: string) {
  return /^https?:\/\//i.test(url) ? url : `${rehberOrigin()}${url.startsWith("/") ? "" : "/"}${url}`;
}

// Marka varlığı: ad, adres, logo ve (panelde girildiyse) resmi profiller.
export function organizationNode() {
  const settings = getSettings();
  const node: Record<string, unknown> = {
    "@type": "Organization",
    "@id": ORGANIZATION_ID(),
    name: "Zirve Rehber",
    alternateName: "Zirve Escort",
    url: `${rehberOrigin()}/`,
    logo: { "@type": "ImageObject", url: absolute(settings.favicon || "/favicon.png") },
    description: settings.rehberDescription,
  };
  return node;
}

export function websiteNode() {
  return {
    "@type": "WebSite",
    "@id": WEBSITE_ID(),
    name: "Zirve Rehber",
    url: `${rehberOrigin()}/`,
    inLanguage: "tr-TR",
    isFamilyFriendly: false,
    publisher: { "@id": ORGANIZATION_ID() },
  };
}

export function faqNode(faqs: Faq[]) {
  return {
    "@type": "FAQPage",
    mainEntity: faqs.map((item) => ({
      "@type": "Question",
      name: item.q,
      acceptedAnswer: { "@type": "Answer", text: item.a },
    })),
  };
}
