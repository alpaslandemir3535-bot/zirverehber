import { cookies } from "next/headers";
import { scryptSync, timingSafeEqual } from "crypto";
import { simpleHash } from "./hash";
import { ADMIN_COOKIE, OWNER_COOKIE, sessionUserId, signSessionToken } from "./session-token";

export { ADMIN_COOKIE, OWNER_COOKIE };

export function adminPassword() {
  const value = process.env.ADMIN_PASSWORD || "";
  if (value) return value;
  return process.env.NODE_ENV === "production" ? "" : "zirve1234";
}

export function secret() {
  return process.env.ADMIN_SECRET || process.env.ADMIN_PASSWORD || (process.env.NODE_ENV === "production" ? "" : "zirve-dev-secret");
}

export function hashPassword(password: string) {
  const key = secret() || "zirve-dev-secret";
  return `s2.${scryptSync(`${password}::${key}`, "zirve-ilan", 32).toString("hex")}`;
}

function legacyPasswordHash(password: string) {
  return simpleHash(`${password}::${secret() || "zirve-dev-secret"}`);
}

export function passwordsMatch(password: string, stored: string) {
  if (stored.startsWith("s2.")) {
    const next = Buffer.from(hashPassword(password));
    const prev = Buffer.from(stored);
    return next.length === prev.length && timingSafeEqual(next, prev);
  }
  return stored === legacyPasswordHash(password);
}

export async function signAdminSession(userId: string) {
  return signSessionToken(userId);
}

export async function signOwnerToken(userId: string) {
  return signSessionToken(userId);
}

export function parseOwnerToken(token: string | undefined) {
  if (!token || !token.includes(".")) return null;
  return token.slice(0, token.indexOf(".")) || null;
}

export async function isAdmin() {
  const jar = await cookies();
  const token = jar.get(ADMIN_COOKIE)?.value;
  if (!(await sessionUserId(token))) return false;
  const { adminFromToken } = await import("./admins");
  return Boolean(await adminFromToken(token));
}

export async function ownerTokenFromCookie() {
  const jar = await cookies();
  return jar.get(OWNER_COOKIE)?.value;
}

export function cookieOptions(maxAge = 60 * 60 * 24 * 14) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    secure: process.env.NODE_ENV === "production",
    maxAge,
  };
}

export async function adminCookie(admin: { id: string }) {
  return {
    name: ADMIN_COOKIE,
    value: await signAdminSession(admin.id),
    options: cookieOptions(),
  };
}
