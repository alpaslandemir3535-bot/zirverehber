import { AdCard } from "@/components/AdCard";
import type { Listing } from "@/lib/listings";
import { getSettings } from "@/lib/settings";

export function VipRow({ listings, cityName }: { listings: Listing[]; cityName?: string }) {
  if (!listings.length) return null;
  const rotatePhotos = getSettings().rotatePhotos !== false;
  return (
    <div className="vip-row">
      <span className="vip-frame-label">VIP</span>
      {listings.map((listing, index) => (
        <AdCard
          key={listing.slug}
          listing={listing}
          cityName={cityName}
          index={index}
          rotatePhotos={rotatePhotos}
          vip
        />
      ))}
    </div>
  );
}
