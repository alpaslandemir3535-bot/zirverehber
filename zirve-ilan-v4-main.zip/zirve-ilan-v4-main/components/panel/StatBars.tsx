export function StatBars({
  series,
}: {
  series: { date: string; visitors: number; listingClicks: number; whatsappClicks: number }[];
}) {
  const max = Math.max(1, ...series.flatMap((day) => [day.visitors, day.listingClicks, day.whatsappClicks]));

  return (
    <div className="stat-bars">
      {series.map((day) => (
        <div key={day.date} className="stat-col" title={`${day.date}: ${day.visitors} ziyaretçi`}>
          <div className="stat-stack">
            <span style={{ height: `${(day.whatsappClicks / max) * 100}%` }} className="bar wa" />
            <span style={{ height: `${(day.listingClicks / max) * 100}%` }} className="bar click" />
            <span style={{ height: `${(day.visitors / max) * 100}%` }} className="bar visit" />
          </div>
          <em>{day.date.slice(3)}</em>
        </div>
      ))}
    </div>
  );
}
