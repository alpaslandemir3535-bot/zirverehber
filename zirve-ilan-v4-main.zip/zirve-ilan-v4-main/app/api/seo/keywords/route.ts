import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { saveCityKeywords } from "@/lib/seo-keywords";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { city?: string; keywords?: unknown } | null;
  if (!body?.city) return NextResponse.json({ error: "İl seç." }, { status: 400 });
  const keywords = saveCityKeywords(body.city, body.keywords);
  if (!keywords) return NextResponse.json({ error: "İl bulunamadı." }, { status: 404 });
  return NextResponse.json({ keywords });
}
