import path from "path";
import { readJsonFile, writeJsonFile } from "./json-file";
import { cities, type City } from "./cities";
import { isListingLive, type Listing } from "./listing-types";
import { getAllListings } from "./store";
import { toSlug } from "./to-slug";

function liveListingsForCity(city: City) {
  const seen = new Set<string>();
  const items: Listing[] = [];
  for (const listing of getAllListings()) {
    if (!isListingLive(listing) || !listing.cities.includes(city.slug)) continue;
    const name = listing.name.trim();
    const key = name.toLocaleLowerCase("tr-TR");
    if (!name || seen.has(key)) continue;
    seen.add(key);
    items.push(listing);
  }
  return items;
}

export function publishedNamesForCity(city: City) {
  return liveListingsForCity(city).map((listing) => listing.name.trim());
}

export type SeoPost = {
  id: string;
  citySlug: string;
  slug: string;
  name: string;
  title: string;
  body: string;
  updatedAt?: string;
};

const file = path.join(process.cwd(), "data", "seo-posts.json");

function defaultTitle(city: City, name: string, index: number) {
  const patterns = [
    `${city.name} Bayan Escort ${name}`,
    `${city.name} Escort Bayan ${name}`,
    `${city.name} Escort ${name}`,
  ];
  return patterns[index % patterns.length];
}

function defaultBody(city: City, name: string, title: string) {
  return `${title} ilanı ${city.name} için yayınlanır. ${name}, ${city.name} sayfasındaki güncel ilanlardandır. ${city.region} bölgesinde iletişim vitrin üzerindeki numaradan yürür.`;
}

export function defaultSeoPosts(city: City): SeoPost[] {
  return liveListingsForCity(city).map((listing, index) => {
    const name = listing.name.trim();
    const title = defaultTitle(city, name, index);
    const slug = toSlug(title);
    return {
      id: `${city.slug}:${slug}`,
      citySlug: city.slug,
      slug,
      name,
      title,
      body: defaultBody(city, name, title),
      updatedAt: listing.updatedAt,
    };
  });
}

function readOverrides(): SeoPost[] {
  const raw = readJsonFile<SeoPost[]>(file, []);
  return Array.isArray(raw) ? raw : [];
}

function writeOverrides(posts: SeoPost[]) {
  writeJsonFile(file, posts);
}

// Yayın tarafında sadece elle kaydedilmiş yazılar çıkar. Otomatik taslaklar panelde
// düzenlenmek için durur; kaydedilmeyen taslak siteye ve site haritasına girmez.
export function seoPostsForCity(city: City, mode: "public" | "editor" = "editor"): SeoPost[] {
  const overrides = readOverrides().filter((item) => item.citySlug === city.slug);
  if (mode === "public") {
    const live = new Set(publishedNamesForCity(city).map((name) => name.toLocaleLowerCase("tr-TR")));
    return overrides.filter((post) => live.has(post.name.trim().toLocaleLowerCase("tr-TR")));
  }
  return defaultSeoPosts(city).map((post) => overrides.find((item) => item.slug === post.slug) || post);
}

export function seoPostBySlug(city: City, slug: string, mode: "public" | "editor" = "editor") {
  return seoPostsForCity(city, mode).find((post) => post.slug === slug) ?? null;
}

export function saveSeoPost(input: SeoPost) {
  const posts = readOverrides().filter((item) => !(item.citySlug === input.citySlug && item.slug === input.slug));
  const saved = {
    ...input,
    title: input.title.trim(),
    name: input.name.trim(),
    body: input.body.trim(),
    updatedAt: new Date().toISOString(),
  };
  posts.push(saved);
  writeOverrides(posts);
  return saved;
}

export function allSeoCities() {
  return cities;
}
