"use client";

import { useState } from "react";

type CityKeywords = { slug: string; name: string; keywords: string[] };

export function CityKeywordsForm({ cities }: { cities: CityKeywords[] }) {
  const [rows, setRows] = useState(cities);
  const [slug, setSlug] = useState(cities[0]?.slug || "");
  const [draft, setDraft] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const current = rows.find((city) => city.slug === slug) || rows[0];

  async function save(next: string[]) {
    if (!current) return;
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/seo/keywords/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ city: current.slug, keywords: next }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setMessage(json.error || "Kaydedilemedi.");
      return;
    }
    const keywords = json.keywords as string[];
    setRows((prev) => prev.map((city) => (city.slug === current.slug ? { ...city, keywords } : city)));
    setMessage("Kaydedildi.");
  }

  function add() {
    const text = draft.replace(/\s+/g, " ").trim();
    if (!text || !current) return;
    const key = text.toLocaleLowerCase("tr-TR");
    if (current.keywords.some((item) => item.toLocaleLowerCase("tr-TR") === key)) {
      setDraft("");
      return;
    }
    setDraft("");
    void save([...current.keywords, text]);
  }

  if (!current) return null;

  return (
    <section className="panel-card">
      <label>
        İl
        <select value={current.slug} onChange={(event) => setSlug(event.target.value)}>
          {rows.map((city) => (
            <option key={city.slug} value={city.slug}>
              {city.name} ({city.keywords.length})
            </option>
          ))}
        </select>
      </label>
      <div className="mark-add" style={{ marginTop: 14 }}>
        <input
          value={draft}
          maxLength={60}
          placeholder={`${current.name} için anahtar kelime`}
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              add();
            }
          }}
        />
        <button className="btn" type="button" onClick={add} disabled={busy}>
          Ekle
        </button>
      </div>
      <ul className="mark-list">
        {current.keywords.map((keyword) => (
          <li key={keyword}>
            <span>{keyword}</span>
            <button type="button" disabled={busy} onClick={() => void save(current.keywords.filter((item) => item !== keyword))}>
              Sil
            </button>
          </li>
        ))}
      </ul>
      {message ? <p className="muted">{message}</p> : null}
    </section>
  );
}
