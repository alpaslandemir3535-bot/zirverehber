import { sortListings, type Listing } from "./listing-types";
import { getSettings } from "./settings";

export function arrangeVitrin(listings: Listing[]) {
  const top = getSettings().vitrinTopTier;
  const both = sortListings(listings.filter((item) => item.featured && item.gold));
  const vip = sortListings(listings.filter((item) => item.featured && !item.gold));
  const gold = sortListings(listings.filter((item) => item.gold && !item.featured));
  const rest = listings.filter((item) => !item.featured && !item.gold);
  const first = top === "gold" ? gold : vip;
  const second = top === "gold" ? vip : gold;
  return [...both, ...first, ...second, ...rest];
}

export function vitrinBadge(listing: Listing, now = Date.now()) {
  const top = getSettings().vitrinTopTier;
  if (listing.featured && listing.gold) return top === "gold" ? "GOLD" : "VIP";
  if (listing.featured) return "VIP";
  if (listing.gold) return "GOLD";
  if (listing.yeni) return "YENİ";
  const stamp = new Date(listing.startedAt || listing.createdAt).getTime();
  if (Number.isFinite(stamp) && now - stamp < 3 * 24 * 60 * 60 * 1000) return "YENİ";
  return "";
}
