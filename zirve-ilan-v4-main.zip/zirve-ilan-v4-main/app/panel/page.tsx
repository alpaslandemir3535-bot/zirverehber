import { ClickBoards } from "@/components/panel/ClickBoards";
import { StatBars } from "@/components/panel/StatBars";
import { getDashboardStats, topEntries } from "@/lib/analytics";
import { expiryLabel, expiringListings, notifyExpiringListings } from "@/lib/expiry";
import { fetchGscDashboard } from "@/lib/gsc";
import { getAllListings } from "@/lib/store";
import { waitingPayments } from "@/lib/payments";
import { publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

function Kpi({
  label,
  value,
  hint,
}: {
  label: string;
  value: number;
  hint?: string;
}) {
  return (
    <article className="kpi">
      <span>{label}</span>
      <strong>{value.toLocaleString("tr-TR")}</strong>
      {hint ? <em>{hint}</em> : null}
    </article>
  );
}

export default async function PanelHomePage() {
  try {
    await notifyExpiringListings();
  } catch {
    /* Telegram kapalıysa panel yine açılır. */
  }
  const stats = getDashboardStats();
  const listings = getAllListings();
  const settings = publicSettings();
  const expiring = expiringListings();
  const waiting = waitingPayments();
  const clicks = {
    today: topEntries(stats.today.listingTotals, 8),
    week: topEntries(stats.week.listingTotals, 8),
    month: topEntries(stats.month.listingTotals, 8),
  };
  const whatsapp = {
    today: topEntries(stats.today.waTotals, 8),
    week: topEntries(stats.week.waTotals, 8),
    month: topEntries(stats.month.waTotals, 8),
  };
  const gsc = await fetchGscDashboard();

  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Genel bakış</p>
          <h1>Dashboard</h1>
        </div>
        <div className="row-actions">
          <a className="btn secondary" href="/panel/gsc/">
            Search Console
          </a>
          <a className="btn secondary" href="/panel/ayarlar/">
            Ayarlar
          </a>
          <a className="btn" href="/panel/ilan/yeni/">
            Yeni ilan
          </a>
        </div>
      </div>

      {waiting.length ? (
        <p className="warn-banner">
          {waiting.length} ödeme yönetici onayı bekliyor. <a href="/panel/odemeler/">Ödemelere git</a>
        </p>
      ) : null}
      {settings.backupDue ? (
        <p className="warn-banner">
          Bu haftanın veritabanı yedeği alınmadı. <a href="/panel/ayarlar/">USB yedeğini al</a>
        </p>
      ) : null}
      {expiring.length ? (
        <div className="warn-banner">
          <strong>Süresi yaklaşan ilanlar</strong>
          <ul>
            {expiring.slice(0, 8).map((item) => (
              <li key={item.id}>
                {item.displayName} — {item.expiresAt ? expiryLabel(item.expiresAt) : ""}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <section className="kpi-grid">
        <Kpi label="Toplam ziyaretçi" value={stats.totalVisitors} hint="İlk girişten beri" />
        <Kpi label="Günlük ziyaretçi" value={stats.today.visitors} hint={`${stats.today.views} görüntüleme`} />
        <Kpi label="Haftalık ziyaretçi" value={stats.week.visitors} hint={`${stats.week.views} görüntüleme`} />
        <Kpi label="Aylık ziyaretçi" value={stats.month.visitors} hint={`${stats.month.views} görüntüleme`} />
        <Kpi
          label="WhatsApp tık"
          value={stats.month.whatsappClicks}
          hint={`Bugün ${stats.today.whatsappClicks} · hafta ${stats.week.whatsappClicks}`}
        />
        <Kpi
          label="İlan tık"
          value={stats.month.listingClicks}
          hint={`Bugün ${stats.today.listingClicks} · hafta ${stats.week.listingClicks}`}
        />
      </section>

      <section className="panel-card">
        <div className="panel-row">
          <h2>81 il · siteye girenler</h2>
        </div>
        <p className="muted">
          İl sayfası veya vitrin `?sehir=` ile açılan ziyaretçiler. Anasayfa il seçilmeden bu listeye yazılmaz.
        </p>
        <div className="city-stat-grid">
          {stats.citiesToday.map((row, index) => (
            <article key={row.slug} className="city-stat">
              <span>{row.name}</span>
              <strong>{row.visitors.toLocaleString("tr-TR")}</strong>
              <em>
                bugün {row.views} görüntüleme · ay {stats.citiesMonth[index].visitors}
              </em>
            </article>
          ))}
        </div>
      </section>

      <section className="dash-grid">
        <div className="panel-card">
          <div className="panel-row">
            <h2>Son 14 gün</h2>
            <div className="legend">
              <span className="dot visit" /> Ziyaretçi
              <span className="dot click" /> İlan
              <span className="dot wa" /> WhatsApp
            </div>
          </div>
          <StatBars series={stats.series} />
        </div>

        <div className="panel-card dash-side">
          <h2>Durum</h2>
          <ul className="stat-list">
            <li>
              <span>Toplam ilan</span>
              <strong>{listings.length}</strong>
            </li>
            <li>
              <span>Yayında</span>
              <strong>{listings.filter((item) => item.status === "published").length}</strong>
            </li>
            <li>
              <span>Telegram</span>
              <strong>{settings.telegramReady ? "Bağlı" : "Kapalı"}</strong>
            </li>
            <li>
              <span>Search Console</span>
              <strong>{gsc.ready ? `${gsc.clicks.toLocaleString("tr-TR")} tık` : "Kapalı"}</strong>
            </li>
          </ul>
        </div>
      </section>

      <ClickBoards clicks={clicks} whatsapp={whatsapp} />
    </>
  );
}
