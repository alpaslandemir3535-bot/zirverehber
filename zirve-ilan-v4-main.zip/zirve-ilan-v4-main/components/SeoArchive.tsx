import type { City } from "@/lib/cities";
import { cityPosts } from "@/lib/seo";
import { rehberUrl } from "@/lib/site";

export function SeoArchive({ city }: { city: City }) {
  const posts = cityPosts(city);

  if (!posts.length) return null;

  return (
    <div className="posts-listing posts-listing-1">
      <h2>{city.name} escort ilan yazıları</h2>
      {posts.map((post) => (
        <article key={post.slug} className="listing-item listing-1-item">
          <h3 className="post-title">
            <a href={rehberUrl(post.path)}>{post.title}</a>
          </h3>
        </article>
      ))}
    </div>
  );
}
