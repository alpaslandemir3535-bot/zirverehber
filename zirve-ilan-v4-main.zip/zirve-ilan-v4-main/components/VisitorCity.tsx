"use client";

import { nearestCity } from "@/lib/city-point";
import { cities } from "@/lib/cities";
import { useEffect } from "react";

const SESSION = "zirve_konum_ok";

function isTikTok() {
  if (typeof window === "undefined") return false;
  const ua = navigator.userAgent || "";
  if (/TikTok|musical_ly|BytedanceWebview|ByteLocale/i.test(ua)) return true;
  const params = new URLSearchParams(window.location.search);
  if (params.get("ttclid")) return true;
  return (params.get("utm_source") || "").toLowerCase().includes("tiktok");
}

function lockUrl(city: string) {
  const host = window.location.hostname.toLowerCase().replace(/^www\./, "");
  const onListings = host === "zirvepano.xyz" || host === "vitrinpano.site";
  const url = new URL(onListings ? "https://zirverehber.com/" : `${window.location.origin}/`);
  url.searchParams.set("konum", city);
  return url.toString();
}

function alreadyOn(city: string) {
  const named = cities.find((item) => item.name === city);
  if (!named) return false;
  if (new URLSearchParams(window.location.search).get("sehir") === city) return true;
  return window.location.pathname.toLowerCase().includes(`/${named.slug}-escort`);
}

function go(city: string) {
  if (!city || alreadyOn(city)) return;
  window.location.replace(lockUrl(city));
}

async function cityFromIp() {
  try {
    const response = await fetch("/api/konum", { cache: "no-store" });
    if (!response.ok) return "";
    const data = (await response.json()) as { city?: string };
    return data.city || "";
  } catch {
    return "";
  }
}

// İzin sorusu çıkmazsa (TikTok penceresi) söz boş döner. Zaman aşımı da boş sayılır.
function locate(timeout: number) {
  return new Promise<string>((resolve) => {
    if (!navigator.geolocation) {
      resolve("");
      return;
    }
    let done = false;
    const finish = (city: string) => {
      if (done) return;
      done = true;
      resolve(city);
    };
    const timer = window.setTimeout(() => finish(""), timeout);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        window.clearTimeout(timer);
        finish(nearestCity(position.coords.latitude, position.coords.longitude) || "");
      },
      () => {
        window.clearTimeout(timer);
        finish("");
      },
      { enableHighAccuracy: false, timeout, maximumAge: 60_000 },
    );
  });
}

async function locationOpen() {
  if (!navigator.geolocation) return false;
  try {
    const status = await navigator.permissions?.query({ name: "geolocation" });
    if (!status) return true;
    return status.state !== "denied";
  } catch {
    return true;
  }
}

// Konum açıksa her ziyaretçi kendi iline gider. Google'dan yanlış il sayfasına
// düşmüş olsa bile cihaz konumu onu düzeltir. Konum kapalıysa ana sayfada IP kullanılır.
// correct: il sayfasında IP ile başka ile atlama; yalnız cihaz konumu esas alınır.
export function VisitorCity({ correct = false }: { tiktokOnly?: boolean; correct?: boolean }) {
  useEffect(() => {
    if (sessionStorage.getItem(SESSION) === "1") return;
    const inApp = isTikTok();
    let cancelled = false;
    (async () => {
      const open = await locationOpen();
      const city = open ? await locate(inApp ? 1500 : 12_000) : "";
      if (cancelled) return;
      sessionStorage.setItem(SESSION, "1");
      if (city) {
        go(city);
        return;
      }
      if (correct) return;
      const ipCity = await cityFromIp();
      if (!cancelled) go(ipCity);
    })();
    return () => {
      cancelled = true;
    };
  }, [correct]);

  return null;
}
