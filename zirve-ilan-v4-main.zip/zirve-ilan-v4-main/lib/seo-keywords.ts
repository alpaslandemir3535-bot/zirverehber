import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import path from "path";
import { cities, cityBySlug, type City } from "./cities";
import { districtsFor } from "./districts";

const file = path.join(process.cwd(), "data", "seo-keywords.json");

function lower(value: string) {
  return value.trim().toLocaleLowerCase("tr-TR");
}

function unique(items: string[]) {
  const seen = new Set<string>();
  const next: string[] = [];
  for (const item of items) {
    const key = lower(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    next.push(key);
  }
  return next;
}

export function defaultCityKeywords(city: City) {
  const name = lower(city.name);
  const districts = districtsFor(city.slug);
  const named = districts.filter((item) => lower(item) !== "merkez").slice(0, 5);
  const districtKeys = named.flatMap((district) => {
    const place = lower(district);
    return [`${place} escort`, `${name} ${place} escort`];
  });
  const merkez = districts.some((item) => lower(item) === "merkez") ? [`${name} merkez escort`] : [];
  return unique([
    `${name} escort`,
    `${name} gerçek escort`,
    `${name} bayan escort`,
    `${name} vip escort`,
    ...districtKeys,
    ...merkez,
  ]);
}

export function cleanKeywordList(value: unknown) {
  if (!Array.isArray(value)) return [];
  const items = value
    .filter((item): item is string => typeof item === "string")
    .map((item) => item.replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 60))
    .filter((item) => item.length >= 2);
  return unique(items).slice(0, 40);
}

function readStore(): Record<string, string[]> {
  if (!existsSync(file)) return {};
  try {
    const raw = JSON.parse(readFileSync(file, "utf8")) as Record<string, unknown>;
    const next: Record<string, string[]> = {};
    for (const city of cities) {
      if (Array.isArray(raw[city.slug])) next[city.slug] = cleanKeywordList(raw[city.slug]);
    }
    return next;
  } catch {
    return {};
  }
}

function writeStore(store: Record<string, string[]>) {
  mkdirSync(path.dirname(file), { recursive: true });
  writeFileSync(file, JSON.stringify(store, null, 2), "utf8");
}

export function keywordsForCity(city: City) {
  const store = readStore();
  return store[city.slug] ?? defaultCityKeywords(city);
}

export function allCityKeywords() {
  const store = readStore();
  return cities.map((city) => ({
    slug: city.slug,
    name: city.name,
    keywords: store[city.slug] ?? defaultCityKeywords(city),
  }));
}

export function saveCityKeywords(slug: string, keywords: unknown) {
  const city = cityBySlug(slug);
  if (!city) return null;
  const store = readStore();
  store[city.slug] = cleanKeywordList(keywords);
  writeStore(store);
  return store[city.slug];
}
