import { CardSlide } from "@/components/CardSlide";
import { TrackLink } from "@/components/TrackLink";
import type { Listing } from "@/lib/listings";
import { listingUrl } from "@/lib/site";
import { listingWhatsAppHref } from "@/lib/whatsapp-listing";

export function VitrinCard({
  listing,
  cityName,
  cityHref,
  badge,
  views,
  rotatePhotos,
  layout = "board",
}: {
  listing: Listing;
  cityName?: string;
  cityHref?: string;
  badge: string;
  views: number;
  rotatePhotos: boolean;
  layout?: "board" | "other";
}) {
  const place = (cityName || "").toLocaleUpperCase("tr-TR");
  const images = listing.gallery.length ? listing.gallery : listing.cover ? [listing.cover] : [];
  const kind = badge === "VIP" ? "vip" : badge === "GOLD" ? "gold" : badge === "YENİ" ? "yeni" : "";
  const name = listing.displayName || listing.name;
  const otherTitle = [name, cityName, "Escort"].filter(Boolean).join(" ");
  const otherSub = [cityName, listing.category].filter(Boolean).join(" · ");
  return (
    <article className={["vitrin-card", kind ? `is-${kind}` : "", layout === "other" ? "is-other" : ""].filter(Boolean).join(" ")}>
      <TrackLink href={listingUrl(listing.slug, cityName)} type="listing" listingId={listing.id} city={cityName} className="vitrin-card-link">
        {kind ? <span className={`vitrin-badge badge-${kind}`}>{badge}</span> : null}
        <CardSlide
          images={images}
          alt={`${cityName ? `${cityName} Escort ` : ""}${listing.name}`}
          eager={badge === "VIP" || badge === "GOLD"}
          rotate={rotatePhotos}
        />
        {layout === "board" ? (
          <div className="vitrin-card-copy">
            <strong>{name}</strong>
            {place ? <em>{place}</em> : null}
            <small>Bugün {views} kişi görüntüledi</small>
          </div>
        ) : null}
      </TrackLink>
      {layout === "other" ? (
        <div className="vitrin-other-copy">
          <strong>{otherTitle}</strong>
          {otherSub ? <em>{otherSub}</em> : null}
          <small>Bugün {views} kişi görüntüledi</small>
          <div className="vitrin-other-tags">
            {cityName && cityHref ? <a href={cityHref}>{cityName} Escort</a> : null}
            {listing.category ? <span>{listing.category}</span> : null}
          </div>
        </div>
      ) : null}
      <TrackLink
        href={listingWhatsAppHref(listing, cityName)}
        type="whatsapp"
        listingId={listing.id}
        city={cityName}
        className="vitrin-wa"
        target="_blank"
      >
        <WhatsAppIcon />
        {listing.phone}
      </TrackLink>
    </article>
  );
}

function WhatsAppIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path
        fill="currentColor"
        d="M12.04 2C6.58 2 2.15 6.4 2.15 11.83c0 1.74.46 3.44 1.34 4.94L2 22l5.39-1.41a10.1 10.1 0 0 0 4.65 1.12h.01c5.46 0 9.89-4.4 9.89-9.83C21.94 6.4 17.5 2 12.04 2zm5.76 13.9c-.24.68-1.4 1.3-1.94 1.38-.5.08-1.12.11-1.81-.11-.41-.14-.95-.31-1.64-.61-2.88-1.25-4.76-4.15-4.9-4.34-.14-.2-1.16-1.54-1.16-2.94 0-1.4.73-2.09 1-2.37.24-.26.64-.38.85-.38h.6c.19 0 .45-.07.7.53.26.63.88 2.16.96 2.32.08.16.03.35-.07.52l-.3.4c-.13.16-.27.36-.12.6.17.3.76 1.25 1.63 2.03 1.12 1 2.06 1.31 2.36 1.46.3.15.47.13.64-.08.17-.2.74-.86.94-1.16.2-.3.4-.24.67-.14.27.1 1.7.8 1.99.95.29.14.48.22.55.34.07.12.07.7-.17 1.38z"
      />
    </svg>
  );
}
