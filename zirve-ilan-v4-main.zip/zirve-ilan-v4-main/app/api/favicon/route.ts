import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { saveSettings } from "@/lib/settings";
import { mkdirSync, readdirSync, unlinkSync, writeFileSync } from "fs";
import path from "path";
import { NextResponse } from "next/server";

const MAX_BYTES = 512 * 1024;
const dir = path.join(process.cwd(), "public", "uploads", "site");

function sniff(buf: Buffer) {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.length >= 4 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "png";
  if (buf.length >= 4 && buf[0] === 0 && buf[1] === 0 && buf[2] === 1 && buf[3] === 0) return "ico";
  if (buf.length >= 12 && buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WEBP") {
    return "webp";
  }
  return null;
}

function clearOld() {
  mkdirSync(dir, { recursive: true });
  for (const name of readdirSync(dir)) {
    if (name.startsWith("favicon.")) unlinkSync(path.join(dir, name));
  }
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "Görsel seç." }, { status: 400 });
  if (file.size > MAX_BYTES) return NextResponse.json({ error: "Favicon en fazla 512 KB." }, { status: 400 });
  const buf = Buffer.from(await file.arrayBuffer());
  const ext = sniff(buf);
  if (!ext) return NextResponse.json({ error: "PNG, ICO, JPG veya WEBP yükle." }, { status: 400 });
  clearOld();
  const name = `favicon.${ext}`;
  writeFileSync(path.join(dir, name), buf);
  const favicon = `/uploads/site/${name}?v=${Date.now()}`;
  saveSettings({ favicon });
  return NextResponse.json({ ok: true, favicon });
}

export async function DELETE(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  clearOld();
  saveSettings({ favicon: "" });
  return NextResponse.json({ ok: true, favicon: "/favicon.png" });
}
