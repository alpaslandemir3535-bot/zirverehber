import { VitrinCard } from "@/components/VitrinCard";
import { todayListingClicks } from "@/lib/analytics";
import { cities, type City } from "@/lib/cities";
import { cityContent, cityEscortEssay } from "@/lib/city-content";
import { listingProfileArticle } from "@/lib/owner-bio";
import type { Listing } from "@/lib/listings";
import { getSettings, ilanVerHref } from "@/lib/settings";
import { vitrinStyle } from "@/lib/vitrin-style";
import { cityPagePath, rehberUrl } from "@/lib/site";
import { arrangeVitrin, vitrinBadge } from "@/lib/vitrin-order";

export function VitrinHome({
  title,
  kicker,
  listings,
  cityName,
  city,
}: {
  title: string;
  kicker: string;
  listings: Listing[];
  cityName?: string;
  city?: City | null;
}) {
  const settings = getSettings();
  const ordered = arrangeVitrin(listings);
  const clicks = todayListingClicks();
  const rotatePhotos = settings.rotatePhotos !== false;
  const sections = city ? cityContent(city).sections : [];
  const style = vitrinStyle(settings);

  return (
    <div className="vitrin" style={style}>
      <header className="vitrin-top">
        <a className="vitrin-brand" href={city ? rehberUrl(cityPagePath(city.slug)) : rehberUrl("/")} style={{ color: settings.vitrinLogoColor }}>
          <span className="vitrin-mark" />
          <span className="vitrin-logo-text">{settings.vitrinLogoText}</span>
        </a>
        <a className="vitrin-nav" href="#vitrin">
          Vitrin
        </a>
      </header>
      <section className="vitrin-hero">
        <div className="vitrin-hero-copy">
          <p>{kicker}</p>
          <h1>{title}</h1>
        </div>
        <div className="vitrin-ilanver">
          <strong style={{ color: settings.vitrinIlanTitleColor, fontSize: settings.vitrinIlanTitleSize }}>
            {settings.vitrinIlanTitle}
          </strong>
          <a
            href={ilanVerHref()}
            target="_blank"
            rel="noreferrer"
            style={{ color: settings.vitrinIlanNoteColor, borderColor: settings.vitrinIlanNoteColor, fontSize: settings.vitrinIlanNoteSize }}
          >
            {settings.vitrinIlanNote}
          </a>
        </div>
      </section>
      <section className="vitrin-board" id="vitrin">
        <p className="vitrin-kicker">Öne çıkan ilanlar</p>
        <h2>Vitrin</h2>
        <div className="vitrin-grid">
          {ordered.map((listing) => (
            <VitrinCard
              key={listing.id}
              listing={listing}
              cityName={cityName}
              badge={vitrinBadge(listing)}
              views={clicks[listing.id] || 0}
              rotatePhotos={rotatePhotos}
            />
          ))}
          <a className="vitrin-promo" href={ilanVerHref()} target="_blank" rel="noreferrer">
            <img src="/ilan-ver-pano.jpg" alt="İlan ver" />
            <span>{settings.ilanVerPhone || "WhatsApp"}</span>
          </a>
        </div>
      </section>
      {city && sections.length ? (
        <section className="vitrin-profiles" aria-label={`${city.name} profilleri`}>
          <h2>
            <span>{city.name} Escort</span>
          </h2>
          <article className="vitrin-essay">
            <p>{cityEscortEssay(city)}</p>
          </article>
          <div className="vitrin-profile-grid">
            {ordered.slice(0, 8).map((listing) => {
              const name = listing.displayName || listing.name;
              return (
                <article key={listing.id} className="vitrin-profile-box">
                  <a href={`/ilan/${listing.slug}/?sehir=${encodeURIComponent(city.name)}`}>
                    <span>Profil</span>
                    <strong>
                      {city.name} {name}
                    </strong>
                  </a>
                  <p>{listingProfileArticle(listing, city.name)}</p>
                </article>
              );
            })}
          </div>
        </section>
      ) : (
        <section className="vitrin-profiles" aria-label="İller">
          <h2>
            <span>Profiller</span>
          </h2>
          <div className="vitrin-profile-grid">
            {cities.map((item) => (
              <a key={item.slug} className="vitrin-profile-box" href={rehberUrl(cityPagePath(item.slug))}>
                <span>Profil</span>
                <strong>{item.name} Escort</strong>
              </a>
            ))}
          </div>
        </section>
      )}
      <footer className="vitrin-foot">
        <strong>18+</strong>
        <p>Bu site yalnızca 18 yaşını doldurmuş yetişkinler içindir. İlanlar, bağımsız ilan sahiplerine aittir.</p>
        <p>
          {city ? `${city.name} Escort ana sayfası` : "Zirve Rehber ana sayfası"} · © Zirve Rehber
        </p>
      </footer>
    </div>
  );
}
