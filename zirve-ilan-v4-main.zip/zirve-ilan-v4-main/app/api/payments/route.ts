import { isAdmin, ownerTokenFromCookie } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { claimPayment, getPayments } from "@/lib/payments";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { ownerFromToken } from "@/lib/users";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json(getPayments());
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!rateLimit(`pay:${clientIp(request)}`, 10, 15 * 60 * 1000)) {
    return NextResponse.json({ error: "Çok fazla deneme." }, { status: 429 });
  }
  const owner = await ownerFromToken(await ownerTokenFromCookie());
  if (!owner) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { listingId?: string; plan?: string; note?: string } | null;
  if (!body?.listingId) return NextResponse.json({ error: "İlan seç." }, { status: 400 });
  const result = await claimPayment(owner.id, body.listingId, body.plan, body.note);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true, status: result.payment.status });
}
