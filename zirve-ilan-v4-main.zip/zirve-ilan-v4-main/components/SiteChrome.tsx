import { cities } from "@/lib/cities";
import { getSettings } from "@/lib/settings";
import { cityPagePath, rehberUrl, vitrinListingsUrl } from "@/lib/site";

export function SiteHeader({ title, href }: { title: string; href: string }) {
  const settings = getSettings();
  return (
    <header className="site-header" itemScope itemType="https://schema.org/WPHeader">
      <a className="branding text-logo" href={href}>
        {settings.sideLeftText ? <span className="brand-side left">{settings.sideLeftText}</span> : null}
        <span className="brand-title">{title}</span>
        {settings.sideRightText ? <span className="brand-side right">{settings.sideRightText}</span> : null}
      </a>
    </header>
  );
}

export function IlanVerBar({ href }: { href: string }) {
  return (
    <div className="ilan-ver-block">
      <a className="complaint-bar" href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer">
        İLAN VER
      </a>
    </div>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <p>Dikkat: Bu internet sitesi 18 yaşından küçük kullanıcılar için önerilmez.</p>
    </footer>
  );
}

export function CityLinks({
  current,
  dest = "rehber",
}: {
  current?: string;
  dest?: "rehber" | "vitrin";
}) {
  return (
    <nav className="city-links" aria-label="İller">
      {cities.map((city) => (
        <a
          key={city.slug}
          href={dest === "vitrin" ? vitrinListingsUrl(city.name) : rehberUrl(cityPagePath(city.slug))}
          aria-current={current === city.slug ? "page" : undefined}
        >
          {city.name}
        </a>
      ))}
    </nav>
  );
}
