import { rejectCrossOrigin } from "@/lib/http";
import { currentActor } from "@/lib/session";
import { randomUUID } from "crypto";
import { mkdirSync, writeFileSync } from "fs";
import path from "path";
import { NextResponse } from "next/server";

const MAX_BYTES = 8 * 1024 * 1024;

function sniff(buf: Buffer) {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.length >= 4 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "png";
  if (buf.length >= 4 && buf.toString("ascii", 0, 3) === "GIF") return "gif";
  if (buf.length >= 12 && buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WEBP") {
    return "webp";
  }
  if (buf.length >= 2 && buf.toString("ascii", 0, 2) === "BM") return "bmp";
  if (buf.length >= 4 && buf[0] === 0 && buf[1] === 0 && buf[2] === 1 && buf[3] === 0) return "ico";
  if (
    buf.length >= 4 &&
    ((buf[0] === 0x49 && buf[1] === 0x49 && buf[2] === 0x2a && buf[3] === 0) ||
      (buf[0] === 0x4d && buf[1] === 0x4d && buf[2] === 0 && buf[3] === 0x2a))
  ) {
    return "tif";
  }
  if (buf.length >= 12 && buf.toString("ascii", 4, 8) === "ftyp") {
    const brand = buf.toString("ascii", 8, 12).toLowerCase();
    if (brand.startsWith("avif") || brand.startsWith("avis")) return "avif";
    if (["heic", "heif", "mif1", "msf1", "heix", "hevc"].some((item) => brand.startsWith(item))) return "heic";
  }
  const head = buf.slice(0, 240).toString("utf8").toLowerCase();
  if (head.includes("<svg")) return "svg";
  return null;
}

const SAFE = new Set(["jpg", "png", "gif", "webp", "bmp", "ico", "tif", "avif", "heic"]);

async function storeBuffer(buf: Buffer) {
  const sniffed = sniff(buf);
  if (!sniffed || sniffed === "svg" || !SAFE.has(sniffed)) return null;
  try {
    const sharp = (await import("sharp")).default;
    const out = await sharp(buf, { failOn: "none", animated: false, limitInputPixels: 40_000_000 })
      .rotate()
      .resize({ width: 1400, height: 2200, fit: "inside", withoutEnlargement: true })
      .jpeg({ quality: 78, mozjpeg: true })
      .toBuffer();
    return { buf: out, ext: "jpg" as const };
  } catch {
    if (sniffed === "jpg" || sniffed === "png" || sniffed === "gif" || sniffed === "webp") return { buf, ext: sniffed };
    return null;
  }
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await currentActor()).role) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });

  const form = await request.formData();
  const files = form.getAll("files").filter((item): item is File => item instanceof File);
  if (!files.length) return NextResponse.json({ error: "Görsel seç." }, { status: 400 });
  if (files.length > 24) return NextResponse.json({ error: "En fazla 24 görsel." }, { status: 400 });

  const dir = path.join(process.cwd(), "public", "uploads", "ads");
  mkdirSync(dir, { recursive: true });

  const urls: string[] = [];
  for (const file of files) {
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ error: `${file.name} 8 MB üstünde.` }, { status: 400 });
    }
    const raw = Buffer.from(await file.arrayBuffer());
    const stored = await storeBuffer(raw);
    if (!stored) {
      return NextResponse.json({ error: `${file.name} görsel olarak okunamadı.` }, { status: 400 });
    }
    const name = `${Date.now()}-${randomUUID().slice(0, 8)}.${stored.ext}`;
    writeFileSync(path.join(dir, name), stored.buf);
    urls.push(`/uploads/ads/${name}`);
  }

  return NextResponse.json({ urls });
}
