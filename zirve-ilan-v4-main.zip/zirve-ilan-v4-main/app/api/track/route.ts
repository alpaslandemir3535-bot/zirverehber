import { trackEvent } from "@/lib/analytics";
import { rejectCrossOrigin } from "@/lib/http";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!rateLimit(`track:${clientIp(request)}`, 80, 60 * 1000)) {
    return NextResponse.json({ ok: true });
  }
  const raw = await request.text();
  const body = (() => {
    try {
      return JSON.parse(raw) as {
        type?: "view" | "listing" | "whatsapp";
        visitorId?: string;
        listingId?: string;
        city?: string;
        device?: "mobile" | "desktop";
        source?: string;
        term?: string;
      };
    } catch {
      return null;
    }
  })();
  if (!body?.type) return NextResponse.json({ error: "type gerekli" }, { status: 400 });
  trackEvent({
    type: body.type,
    visitorId: body.visitorId,
    listingId: body.listingId,
    city: body.city,
  });
  return NextResponse.json({ ok: true });
}
