import { SikayetForm } from "@/components/SikayetForm";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { rehberOrigin } from "@/lib/site";

export default function SikayetPage() {
  return (
    <>
      <SiteHeader title="Şikayet Hattı" href={`${rehberOrigin()}/`} />
      <main className="archive-page-header" style={{ maxWidth: 560, margin: "0 auto" }}>
        <h1>İlan & Şikayet Hattı</h1>
        <p className="archive-description">
          Sahte ilan, taciz veya ödeme şikayetini buradan ilet. Mesaj panele düşer.
        </p>
        <SikayetForm />
      </main>
      <SiteFooter />
    </>
  );
}
