"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function GaSettings({ gaMeasurementId }: { gaMeasurementId: string }) {
  const router = useRouter();
  const [id, setId] = useState(gaMeasurementId);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/telegram/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gaMeasurementId: id }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    setMessage(res.ok ? "Kaydedildi." : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <div className="full help-box">
        <p>analytics.google.com adresinde hesap ve mülk aç. Veri akışına site adresini yaz, ölçüm kimliğini (G- ile başlar) buraya yapıştır.</p>
        <p>Kimlik kaydolunca herkese açık sayfalara sayaç eklenir. Panel ve hesap sayfaları sayılmaz.</p>
      </div>
      <label>
        Ölçüm kimliği
        <input value={id} onChange={(event) => setId(event.target.value)} placeholder="G-ABC1234567" spellCheck={false} />
      </label>
      <div className="full row-actions">
        <button className="btn" type="submit" disabled={busy}>
          Kaydet
        </button>
        <span className={gaMeasurementId ? "badge published" : "badge draft"}>{gaMeasurementId ? "Bağlı" : "Kimlik yok"}</span>
        {message ? <span className="muted">{message}</span> : null}
      </div>
    </form>
  );
}
