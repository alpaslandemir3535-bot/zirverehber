"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function PaymentDecision({ id }: { id: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");

  async function act(action: "approve" | "reject") {
    setBusy(action);
    setError("");
    const res = await fetch(`/api/payments/${id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy("");
    if (!res.ok) {
      setError(json.error || "İşlenemedi.");
      return;
    }
    router.refresh();
  }

  return (
    <div className="row-actions">
      <button className="btn" type="button" disabled={Boolean(busy)} onClick={() => act("approve")}>
        {busy === "approve" ? "Onaylanıyor" : "Onayla ve yayınla"}
      </button>
      <button className="btn ghost" type="button" disabled={Boolean(busy)} onClick={() => act("reject")}>
        Reddet
      </button>
      {error ? <span className="err">{error}</span> : null}
    </div>
  );
}
