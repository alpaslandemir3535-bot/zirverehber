import { cities } from "./cities";
import {
  CATEGORIES,
  durationMs,
  type Listing,
} from "./listing-types";
import { toSlug } from "./to-slug";

const portraits = [
  "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1502823403499-6ccfcad4ee55?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1524502397800-2eeaad7c3fe5?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1548142813-c348350df52b?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1554151228-14d9def656e4?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=664&h=1104&q=80",
  "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=664&h=1104&q=80",
];

const NAMES = [
  "Elif", "Simay", "Sena", "Selva", "Sinem", "Beyza", "Gülcan", "Eslem",
  "Kübra", "Yaren", "Cansu", "Belis", "Selinay", "Derya", "Tuğçe", "Aley",
  "Aysel", "Nisa", "Duru", "Sude", "Pınar", "Burçin", "Arzu", "Sibel",
];

function citiesFor(index: number) {
  const major = ["istanbul", "ankara", "izmir", "antalya", "bursa", "manisa"];
  const extra = cities[(index * 7) % cities.length].slug;
  const second = cities[(index * 11 + 3) % cities.length].slug;
  return [...new Set([...major.slice(0, 2 + (index % 3)), extra, second])];
}

export function buildSeedListings(): Listing[] {
  const now = new Date();
  return NAMES.map((name, index) => {
    const mid = String(100 + (index * 13) % 800).padStart(3, "0");
    const tail = String(1000 + index * 37).padStart(4, "0");
    const phone = `0532 ${mid} ${tail}`;
    const cover = portraits[index % portraits.length];
    const gallery = [
      cover,
      portraits[(index + 5) % portraits.length],
      portraits[(index + 9) % portraits.length],
    ];
    const startedAt = now.toISOString();
    return {
      id: `seed-${index + 1}`,
      slug: toSlug(name) + (index > 15 ? `-${index}` : ""),
      name,
      displayName: index % 4 === 0 ? `${name}✅` : name,
      category: CATEGORIES[index % CATEGORIES.length],
      phone,
      phoneDigits: `90532${mid}${tail}`,
      age: 21 + (index % 8),
      height: 0,
      weight: 0,
      bio: `Merhaba, ben ${name}. Görseller bana aittir. ${21 + (index % 8)} yaşındayım; görüşmelerde gizlilik ve temizlik önceliğim. Eve, otele ve aparte gelirim. Ödeme elden.`,
      cover,
      gallery,
      cities: citiesFor(index),
      districts: [],
      ownerId: null,
      featured: index < 4,
      gold: false,
      yeni: false,
      eldenOdeme: true,
      evOtelApart: false,
      gercekGoruntu: false,
      extraMarks: [],
      sortOrder: index,
      status: "published",
      duration: index % 3 === 0 ? "week" : "month",
      startedAt,
      expiresAt: new Date(now.getTime() + durationMs(index % 3 === 0 ? "week" : "month")).toISOString(),
      createdAt: startedAt,
      updatedAt: startedAt,
    };
  });
}
