export const vitrinOtherDefaults = {
  vitrinOtherTitleColor: "#e0b15a",
  vitrinOtherTextColor: "#f7f1ea",
  vitrinOtherMutedColor: "#c9bfb4",
  vitrinOtherFont: "playfair",
} as const;

export const vitrinFontOptions = [
  { value: "playfair", label: "Serif, varsayılan" },
  { value: "righteous", label: "Başlık yazısı" },
  { value: "sans", label: "Düz yazı" },
  { value: "oswald", label: "Keskin" },
  { value: "anton", label: "Kalın" },
  { value: "fjalla", label: "Keskin dar" },
  { value: "staatliches", label: "Keskin ekstra" },
  { value: "teko", label: "Keskin ince" },
  { value: "barlow", label: "Keskin sıkı" },
  { value: "saira", label: "Keskin uzun" },
  { value: "encode", label: "Keskin net" },
  { value: "passion", label: "Kalın keskin" },
  { value: "russo", label: "Köşeli" },
  { value: "archivo", label: "Ağır" },
  { value: "kanit", label: "Keskin geometrik" },
] as const;

export type VitrinOtherFont = (typeof vitrinFontOptions)[number]["value"];

const sharpFonts = new Set<VitrinOtherFont>([
  "oswald",
  "anton",
  "fjalla",
  "staatliches",
  "teko",
  "barlow",
  "saira",
  "encode",
  "passion",
  "russo",
  "archivo",
  "kanit",
]);

export function vitrinOtherFont(value: unknown): VitrinOtherFont {
  if (typeof value === "string" && vitrinFontOptions.some((item) => item.value === value)) return value as VitrinOtherFont;
  return "playfair";
}

export function vitrinOtherFontFamily(font: VitrinOtherFont) {
  if (font === "righteous") return "var(--font-righteous), sans-serif";
  if (font === "sans") return "inherit";
  if (font === "oswald") return "var(--font-oswald), Impact, sans-serif";
  if (font === "anton") return "var(--font-anton), Impact, sans-serif";
  if (font === "fjalla") return "var(--font-fjalla), Impact, sans-serif";
  if (font === "staatliches") return "var(--font-staatliches), Impact, sans-serif";
  if (font === "teko") return "var(--font-teko), Impact, sans-serif";
  if (font === "barlow") return "var(--font-barlow), Impact, sans-serif";
  if (font === "saira") return "var(--font-saira), Impact, sans-serif";
  if (font === "encode") return "var(--font-encode), Impact, sans-serif";
  if (font === "passion") return "var(--font-passion), Impact, sans-serif";
  if (font === "russo") return "var(--font-russo), Impact, sans-serif";
  if (font === "archivo") return "var(--font-archivo), Impact, sans-serif";
  if (font === "kanit") return "var(--font-kanit), Impact, sans-serif";
  return "var(--font-playfair), Georgia, serif";
}

export function vitrinOtherFontWeight(font: VitrinOtherFont) {
  if (sharpFonts.has(font)) return "700";
  return "500";
}

export function cleanBgImage(value: unknown) {
  if (typeof value !== "string") return "";
  const text = value.trim();
  if (!text) return "";
  const pathOnly = text.split("?")[0];
  if (!/^\/uploads\/site\/vitrin-bg\.(jpg|png|webp)$/.test(pathOnly)) return "";
  const query = text.slice(pathOnly.length);
  if (query && !/^\?v=\d{1,16}$/.test(query)) return pathOnly;
  return pathOnly + query;
}
