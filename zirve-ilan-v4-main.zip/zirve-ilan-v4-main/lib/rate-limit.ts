const hits = new Map<string, { count: number; start: number }>();

function cleanIp(value: string) {
  return value.trim().replace(/^::ffff:/, "").slice(0, 80);
}

export function clientIp(request: Request) {
  const trusted = request.headers.get("x-zirve-ip");
  if (trusted) return cleanIp(trusted) || "local";
  const cloudflare = request.headers.get("cf-connecting-ip")?.split(",")[0];
  if (cloudflare) return cleanIp(cloudflare) || "local";
  const real = request.headers.get("x-real-ip");
  if (real) return cleanIp(real) || "local";
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    const parts = forwarded.split(",").map((item) => item.trim()).filter(Boolean);
    return cleanIp(parts[parts.length - 1] || "") || "local";
  }
  return "local";
}

export function rateLimit(key: string, limit: number, windowMs: number) {
  if (process.env.NODE_ENV !== "production" && key.endsWith(":local")) return true;
  const now = Date.now();
  const current = hits.get(key);
  if (!current || now - current.start > windowMs) {
    hits.set(key, { count: 1, start: now });
    return true;
  }
  current.count += 1;
  return current.count <= limit;
}
