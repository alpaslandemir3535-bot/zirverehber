"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function DeliveryDesk({ id }: { id: string }) {
  const router = useRouter();
  const [delivery, setDelivery] = useState("");
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");

  async function act(action: "approve" | "reject") {
    setBusy(action);
    setError("");
    const res = await fetch(`/api/market/orders/${id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, delivery }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy("");
    if (!res.ok) {
      setError(json.error || "İşlenemedi.");
      return;
    }
    router.refresh();
  }

  return (
    <div className="delivery-box">
      <label>
        Dijital teslim
        <textarea className="pay-note" value={delivery} onChange={(event) => setDelivery(event.target.value)} placeholder="Numara, hat bilgisi veya teslim metni" />
      </label>
      <div className="row-actions">
        <button className="btn" type="button" disabled={Boolean(busy)} onClick={() => act("approve")}>
          {busy === "approve" ? "Teslim ediliyor" : "Onayla ve teslim et"}
        </button>
        <button className="btn ghost" type="button" disabled={Boolean(busy)} onClick={() => act("reject")}>
          Reddet
        </button>
      </div>
      {error ? <p className="err">{error}</p> : null}
    </div>
  );
}
