import { buildBackup, saveBackupToDir } from "@/lib/backup";
import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { filename, zip } = buildBackup();
  return new NextResponse(new Uint8Array(zip), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as { dir?: string } | null;
  if (!body?.dir?.trim()) return NextResponse.json({ error: "Klasör yolu yaz." }, { status: 400 });
  const saved = saveBackupToDir(body.dir);
  if ("error" in saved) return NextResponse.json({ error: saved.error }, { status: 400 });
  return NextResponse.json(saved);
}
