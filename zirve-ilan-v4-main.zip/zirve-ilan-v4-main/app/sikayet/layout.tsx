import type { Metadata } from "next";

export const metadata: Metadata = {
  robots: { index: false, follow: false },
  title: "Şikayet",
};

export default function SikayetLayout({ children }: { children: React.ReactNode }) {
  return children;
}
