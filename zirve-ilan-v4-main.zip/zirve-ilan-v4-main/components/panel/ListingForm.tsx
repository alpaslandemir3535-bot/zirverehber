"use client";

import { fullCoverage } from "@/lib/districts";
import { CATEGORIES, type Listing, type ListingInput } from "@/lib/listing-types";
import { isSharedBio, listingArticle, listingCornerNotes } from "@/lib/owner-bio";
import type { Owner } from "@/lib/users";
import { useRouter } from "next/navigation";
import { useState } from "react";

function toInput(listing?: Listing): ListingInput {
  const coverage = fullCoverage();
  return {
    name: listing?.name || "",
    displayName: listing?.displayName || "",
    category: listing?.category || "POPÜLER ESCORT",
    phone: listing?.phone || "",
    age: listing?.age || 21,
    height: listing?.height || 0,
    weight: listing?.weight || 0,
    bio: listing?.bio || "",
    cover: listing?.cover || "",
    gallery: listing?.gallery || [],
    cities: coverage.cities,
    districts: coverage.districts,
    ownerId: listing?.ownerId || null,
    featured: listing?.featured || false,
    gold: listing?.gold || false,
    yeni: listing?.yeni || false,
    eldenOdeme: listing?.eldenOdeme ?? true,
    evOtelApart: listing?.evOtelApart ?? false,
    gercekGoruntu: listing?.gercekGoruntu ?? false,
    extraMarks: listing?.extraMarks || [],
    sortOrder: listing?.sortOrder || 0,
    status: listing?.status || "draft",
    duration: listing?.duration || "month",
  };
}

export function ListingForm({
  listing,
  owners = [],
  mode = "admin",
  redirectTo = "/panel/",
}: {
  listing?: Listing;
  owners?: Omit<Owner, "passwordHash">[];
  mode?: "admin" | "owner";
  redirectTo?: string;
}) {
  const router = useRouter();
  const [form, setForm] = useState<ListingInput>(() => toInput(listing));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const bioStored = isSharedBio(form.bio)
    ? listingArticle({
        id: listing?.id,
        name: form.name,
        displayName: form.displayName,
        age: form.age,
        category: form.category,
        phone: form.phone,
        eldenOdeme: form.eldenOdeme,
        evOtelApart: form.evOtelApart,
        gercekGoruntu: form.gercekGoruntu,
      })
    : form.bio;
  const bioPreview = bioStored.replaceAll("{şehir}", "şehir").replaceAll("{sehir}", "şehir");
  const cornerNotes = listingCornerNotes(form);

  function patch(next: Partial<ListingInput>) {
    setForm((prev) => ({ ...prev, ...next }));
  }

  function payload(next: ListingInput) {
    return mode === "owner" ? { ...next, asOwner: true } : next;
  }

  async function persist(next: ListingInput) {
    if (!listing) return;
    const res = await fetch(`/api/listings/${listing.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload(next)),
    });
    const json = await res.json();
    if (!res.ok) setError(json.error || "Görseller kaydedilemedi.");
  }

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setUploading(true);
    setError("");
    const data = new FormData();
    Array.from(files).forEach((file) => data.append("files", file));
    const res = await fetch("/api/upload", { method: "POST", body: data });
    const json = await res.json();
    setUploading(false);
    if (!res.ok) {
      setError(json.error || "Yükleme olmadı.");
      return;
    }
    const urls = json.urls as string[];
    const next = {
      ...form,
      gallery: [...form.gallery, ...urls],
      cover: form.cover || urls[0],
    };
    setForm(next);
    await persist(next);
  }

  async function removeImage(src: string) {
    const gallery = form.gallery.filter((item) => item !== src);
    const next = {
      ...form,
      gallery,
      cover: form.cover === src ? gallery[0] || "" : form.cover,
    };
    setForm(next);
    await persist(next);
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError("");
    const res = await fetch(listing ? `/api/listings/${listing.id}` : "/api/listings", {
      method: listing ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload({ ...form, bio: bioStored })),
    });
    const json = await res.json();
    setSaving(false);
    if (!res.ok) {
      setError(json.error || "Kaydedilemedi.");
      return;
    }
    router.push(redirectTo);
    router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <label>
        Ad
        <input value={form.name} onChange={(e) => patch({ name: e.target.value })} required />
      </label>
      <label>
        Görünen ad (emoji olabilir)
        <input value={form.displayName} onChange={(e) => patch({ displayName: e.target.value })} />
      </label>
      <label>
        Kategori
        <select value={form.category} onChange={(e) => patch({ category: e.target.value as ListingInput["category"] })}>
          {CATEGORIES.map((category) => (
            <option key={category}>{category}</option>
          ))}
        </select>
      </label>
      <label>
        Telefon / WhatsApp
        <input
          value={form.phone}
          onChange={(e) => patch({ phone: e.target.value })}
          required
          inputMode="tel"
          placeholder="+90 532 000 0000 veya +49 176 00000000"
        />
      </label>
      <p className="muted full">Detay</p>
      <label>
        Yaş
        <input type="number" min={21} value={form.age} onChange={(e) => patch({ age: Number(e.target.value) })} />
      </label>
      <label>
        Boy (cm)
        <input
          type="number"
          min={120}
          max={220}
          value={form.height || ""}
          placeholder="178"
          onChange={(e) => patch({ height: Number(e.target.value) || 0 })}
        />
      </label>
      <label>
        Kilo (kg)
        <input
          type="number"
          min={35}
          max={200}
          value={form.weight || ""}
          placeholder="60"
          onChange={(e) => patch({ weight: Number(e.target.value) || 0 })}
        />
      </label>
      {mode === "admin" ? (
        <label>
          Sıra
          <input type="number" value={form.sortOrder} onChange={(e) => patch({ sortOrder: Number(e.target.value) })} />
        </label>
      ) : null}
      {mode === "admin" ? (
        <label>
          Yayın durumu
          <select value={form.status} onChange={(e) => patch({ status: e.target.value as ListingInput["status"] })}>
            <option value="draft">Taslak</option>
            <option value="published">Yayında</option>
            <option value="hidden">Gizli</option>
          </select>
        </label>
      ) : null}
      {mode === "admin" ? (
        <label>
          İlan süresi
          <select value={form.duration} onChange={(e) => patch({ duration: e.target.value as ListingInput["duration"] })}>
            <option value="days3">3 gün</option>
            <option value="week">1 hafta</option>
            <option value="month">1 ay</option>
          </select>
        </label>
      ) : null}
      {mode === "admin" ? (
        <p className="muted full">
          Süre yayınlandığı saatle başlar. 3 günlük ilan 3 gün, haftalık ilan 7 gün, aylık ilan 30 gün sonra aynı saatte biter.
          {listing?.expiresAt ? ` Bu ilanın bitişi: ${new Date(listing.expiresAt).toLocaleString("tr-TR", { timeZone: "Europe/Istanbul", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}.` : ""}
        </p>
      ) : null}
      {mode === "admin" ? (
        <label>
          İlan sahibi
          <select
            value={form.ownerId || ""}
            onChange={(e) => patch({ ownerId: e.target.value || null })}
          >
            <option value="">Atanmamış</option>
            {owners.map((owner) => (
              <option key={owner.id} value={owner.id}>
                {owner.name} ({owner.username})
              </option>
            ))}
          </select>
        </label>
      ) : null}
      <p className="muted full">81 il ve ilçeleri kayıtta otomatik seçilir.</p>
      <div className="tick-row full">
        <label>
          <input type="checkbox" checked={form.eldenOdeme} onChange={(e) => patch({ eldenOdeme: e.target.checked })} /> ELDEN ÖDEME
        </label>
        <label>
          <input type="checkbox" checked={form.evOtelApart} onChange={(e) => patch({ evOtelApart: e.target.checked })} /> EV-OTEL-APART
        </label>
        <label>
          <input type="checkbox" checked={form.gercekGoruntu} onChange={(e) => patch({ gercekGoruntu: e.target.checked })} /> GERÇEK GÖRÜNTÜ
        </label>
      </div>
      {form.extraMarks.length ? (
        <div className="full">
          <ul className="mark-list">
            {form.extraMarks.map((mark) => (
              <li key={mark}>
                <span>{mark}</span>
                <button
                  type="button"
                  onClick={() => patch({ extraMarks: form.extraMarks.filter((item) => item !== mark) })}
                >
                  Kaldır
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      <div className="full">
        <p className="muted">Bu ilana özel yazı otomatik kurulur. Şehir adı, ziyaretçinin girdiği ildir. Sol üst yazılar da açıklamada durur.</p>
        <p className="bio-preview">
          {form.name.trim() ? (
            <>
              {bioPreview}
              <span className="detail-marks">{cornerNotes.join(" · ")}</span>
            </>
          ) : (
            "Ad yazılınca bio burada görünür."
          )}
        </p>
      </div>
      {mode === "admin" ? (
        <div className="tick-row full">
          <label>
            <input type="checkbox" checked={form.featured} onChange={(e) => patch({ featured: e.target.checked })} /> VIP
          </label>
          <label>
            <input type="checkbox" checked={form.gold} onChange={(e) => patch({ gold: e.target.checked })} /> GOLD
          </label>
          <label>
            <input type="checkbox" checked={form.yeni} onChange={(e) => patch({ yeni: e.target.checked })} /> YENİ
          </label>
        </div>
      ) : null}
      {mode === "admin" ? <p className="muted full">VIP, GOLD ve YENİ rozetini yalnız yönetici ayarlar.</p> : null}
      <label className="full">
        Görseller — JPG, PNG, WEBP, HEIC, GIF, BMP, AVIF, SVG (çoklu, ekle / sil)
        <input
          type="file"
          accept="image/*,.heic,.heif,.avif,.bmp,.tif,.tiff,.svg,.ico,.jfif,.jxl"
          multiple
          disabled={uploading}
          onChange={(e) => {
            void upload(e.target.files);
            e.target.value = "";
          }}
        />
        {uploading ? <span className="muted">Yükleniyor…</span> : null}
      </label>
      <div className="full thumbs">
        {form.gallery.map((src) => (
          <div key={src} className={`thumb${form.cover === src ? " cover" : ""}`}>
            <img src={src} alt="" />
            <button
              type="button"
              className="btn ghost"
              onClick={() => {
                const next = { ...form, cover: src };
                setForm(next);
                void persist(next);
              }}
            >
              Kapak
            </button>
            <button type="button" className="btn secondary" onClick={() => void removeImage(src)}>
              Sil
            </button>
          </div>
        ))}
      </div>
      {error ? <p className="err full">{error}</p> : null}
      <div className="full">
        <button className="btn" disabled={saving}>
          {saving ? "Kaydediliyor..." : "Kaydet"}
        </button>
      </div>
    </form>
  );
}
