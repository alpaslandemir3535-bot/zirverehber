/** @type {import('next').NextConfig} */
const nextConfig = {
  trailingSlash: true,
  serverExternalPackages: ["geoip-lite"],
  outputFileTracingIncludes: {
    "*": ["./node_modules/geoip-lite/data/**/*"],
  },
  images: {
    formats: ["image/webp"],
    deviceSizes: [320, 420, 640, 828, 1080],
    imageSizes: [160, 200, 256, 384],
    minimumCacheTTL: 2592000,
  },
  // Shared hosting (cPanel/CloudLinux) thread/process limits
  experimental: {
    workerThreads: false,
    cpus: 1,
    serverActions: { bodySizeLimit: "20mb" },
  },
  // Yüklenen görseller sunucu açıldıktan sonra diske düşer, Next'in public listesi
  // açılışta donduğu için bunları bulamaz. Hepsi diskten okunsun.
  async rewrites() {
    return {
      beforeFiles: [{ source: "/uploads/:path*", destination: "/api/gorsel/:path*" }],
      afterFiles: [],
      fallback: [],
    };
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(self)" },
          { key: "X-DNS-Prefetch-Control", value: "on" },
        ],
      },
    ];
  },
};

export default nextConfig;
