"use client";

import { useEffect, useState } from "react";

type AdminRow = { id: string; username: string; name: string };

export default function AdminsPage() {
  const [admins, setAdmins] = useState<AdminRow[]>([]);
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    const res = await fetch("/api/admins");
    if (res.ok) setAdmins(await res.json());
  }

  useEffect(() => {
    load();
  }, []);

  function resetForm() {
    setEditId(null);
    setName("");
    setUsername("");
    setPassword("");
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setMessage("");
    const res = await fetch(editId ? `/api/admins/${editId}` : "/api/admins", {
      method: editId ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        username,
        password: password || undefined,
      }),
    });
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "Kaydedilemedi.");
      return;
    }
    setMessage(editId ? "Yönetici güncellendi." : "Yönetici eklendi.");
    resetForm();
    load();
  }

  async function remove(id: string) {
    setError("");
    const res = await fetch(`/api/admins/${id}`, { method: "DELETE" });
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "Silinemedi.");
      return;
    }
    if (editId === id) resetForm();
    load();
  }

  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Erişim</p>
          <h1>Yöneticiler</h1>
        </div>
      </div>
      <form className="panel-card form-grid" onSubmit={save}>
        <label>
          Ad
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label>
          Kullanıcı adı
          <input value={username} onChange={(e) => setUsername(e.target.value)} required />
        </label>
        <label>
          Şifre {editId ? "(boş bırakırsan değişmez)" : ""}
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required={!editId}
          />
        </label>
        <div className="row-actions">
          <button className="btn" type="submit">
            {editId ? "Güncelle" : "Yönetici ekle"}
          </button>
          {editId ? (
            <button className="btn secondary" type="button" onClick={resetForm}>
              Vazgeç
            </button>
          ) : null}
        </div>
        {error ? <p className="err full">{error}</p> : null}
        {message ? <p className="muted full">{message}</p> : null}
      </form>
      <div className="panel-card" style={{ marginTop: 16 }}>
        <table>
          <thead>
            <tr>
              <th>Ad</th>
              <th>Kullanıcı</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {admins.map((admin) => (
              <tr key={admin.id}>
                <td>{admin.name}</td>
                <td>{admin.username}</td>
                <td className="row-actions">
                  <button
                    className="btn ghost"
                    type="button"
                    onClick={() => {
                      setEditId(admin.id);
                      setName(admin.name);
                      setUsername(admin.username);
                      setPassword("");
                      setMessage("");
                    }}
                  >
                    Düzenle
                  </button>
                  <button className="btn danger" type="button" onClick={() => remove(admin.id)}>
                    Sil
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="muted">Canlıda ilk yöneticiyi güçlü şifreyle oluştur. Varsayılan şifre kullanma.</p>
      </div>
    </>
  );
}
