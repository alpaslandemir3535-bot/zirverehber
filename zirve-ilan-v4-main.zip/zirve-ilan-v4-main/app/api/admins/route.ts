import { isAdmin } from "@/lib/auth";
import { createAdmin, getAdmins, publicAdmin } from "@/lib/admins";
import { rejectCrossOrigin } from "@/lib/http";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json(getAdmins().map(publicAdmin));
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json()) as { username?: string; password?: string; name?: string };
  if (!body.username?.trim() || !body.password?.trim()) {
    return NextResponse.json({ error: "Kullanıcı adı ve şifre gerekli." }, { status: 400 });
  }
  const result = createAdmin({
    username: body.username,
    password: body.password,
    name: body.name || body.username,
  });
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json(publicAdmin(result.admin), { status: 201 });
}
