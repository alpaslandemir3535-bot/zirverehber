import type { City } from "./cities";
import { cityContent } from "./city-content";
import type { Listing } from "./listing-types";
import { citySeoDescription, citySeoTitle } from "./seo";
import { cityPagePath, cityPostPath, ilanOrigin, rehberOrigin } from "./site";

function esc(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function abs(path: string) {
  if (path.startsWith("http")) return path;
  return `${rehberOrigin()}${path.startsWith("/") ? path : `/${path}`}`;
}

const BOILERPLATE =
  "body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}";

const CUSTOM = `body{margin:0;background:#111;color:#fff;font-family:Arial,sans-serif}header,main{padding:16px}h1{font-size:28px;line-height:1.2;margin:0 0 10px}p{line-height:1.5}a.card{display:block;margin:0 0 14px;color:#fff;text-decoration:none;background:#1b1b1b;border-radius:12px;overflow:hidden}a.card strong{display:block;padding:10px 12px;font-size:18px}a.open{display:block;margin-top:8px;background:#e10600;color:#fff;text-align:center;padding:12px;border-radius:999px;text-decoration:none;font-weight:700}`;

function documentHtml(input: { title: string; description: string; canonical: string; body: string }) {
  return `<!doctype html>
<html amp lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
<link rel="canonical" href="${esc(input.canonical)}">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<title>${esc(input.title)}</title>
<meta name="description" content="${esc(input.description)}">
<style amp-boilerplate>${BOILERPLATE}</style>
<noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<style amp-custom>${CUSTOM}</style>
</head>
<body>
${input.body}
</body>
</html>`;
}

function cards(listings: Listing[], cityName: string) {
  return listings
    .slice(0, 24)
    .map((listing) => {
      const href = `${ilanOrigin()}/ilan/${listing.slug}/?sehir=${encodeURIComponent(cityName)}`;
      const image = listing.cover
        ? `<amp-img src="${esc(abs(listing.cover))}" width="332" height="552" layout="responsive" alt="${esc(listing.name)}"></amp-img>`
        : "";
      return `<a class="card" href="${esc(href)}">${image}<strong>${esc(listing.displayName || listing.name)}</strong></a>`;
    })
    .join("");
}

export function cityAmpHtml(city: City, listings: Listing[]) {
  const canonical = abs(cityPagePath(city.slug));
  const title = citySeoTitle(city);
  const description = citySeoDescription(city);
  const article = cityContent(city)
    .sections.map((section) => `<h2>${esc(section.heading)}</h2><p>${esc(section.body)}</p>`)
    .join("");
  const body = `<header><h1>${esc(city.name)} Escort</h1><p>${esc(description)}</p><a class="open" href="${esc(canonical)}">${esc(city.name)} sayfasını aç</a></header><main>${cards(listings, city.name)}${article}</main>`;
  return documentHtml({ title, description, canonical, body });
}

export function postAmpHtml(input: { city: City; title: string; description: string; slug: string; listings: Listing[] }) {
  const canonical = abs(cityPostPath(input.city.slug, input.slug));
  const body = `<header><h1>${esc(input.title)}</h1><p>${esc(input.description)}</p><a class="open" href="${esc(abs(cityPagePath(input.city.slug)))}">${esc(input.city.name)} sayfasını aç</a></header><main>${cards(input.listings, input.city.name)}</main>`;
  return documentHtml({ title: input.title, description: input.description, canonical, body });
}
