import { getDomains } from "./domains";

export type SiteKind = "rehber" | "pano" | "ilan";

export function rehberHost() {
  return getDomains().rehberHost;
}

export function panoHost() {
  return getDomains().panoHost;
}

export function ilanHost() {
  return getDomains().ilanHost;
}

export function rehberOrigin() {
  return `https://${rehberHost()}`;
}

export function panoOrigin() {
  return `https://${panoHost()}`;
}

export function ilanOrigin() {
  return `https://${ilanHost()}`;
}

export function vitrinOrigin() {
  return panoOrigin();
}

function hostName(host: string | null) {
  return (host || "").toLowerCase().replace(/:\d+$/, "").replace(/\.$/, "");
}

export function isLocalHost(host: string | null) {
  const name = hostName(host);
  return name === "localhost" || name === "127.0.0.1";
}

function withHost(origin: string, path: string) {
  const next = path.startsWith("/") ? path : `/${path}`;
  if (process.env.NODE_ENV !== "production") return next;
  return `${origin}${next}`;
}

export function cityPagePath(slug: string) {
  return `/${slug}-escort/`;
}

export function cityPostPath(citySlug: string, postSlug: string) {
  return `/${citySlug}-escort/${postSlug}/`;
}

export function listingPath(slug: string, cityName?: string) {
  const query = cityName ? `?sehir=${encodeURIComponent(cityName)}` : "";
  return `/ilan/${slug}/${query}`;
}

export function rehberUrl(path: string) {
  return withHost(rehberOrigin(), path.startsWith("/") ? path : `/${path}`);
}

export function vitrinUrl(path: string) {
  return withHost(panoOrigin(), path.startsWith("/") ? path : `/${path}`);
}

export function listingUrl(slug: string, cityName?: string) {
  const query = cityName ? `?sehir=${encodeURIComponent(cityName)}` : "";
  return withHost(ilanOrigin(), `/ilan/${slug}/${query}`);
}

export function vitrinListingsUrl(cityName?: string) {
  const query = cityName ? `?sehir=${encodeURIComponent(cityName)}` : "";
  return withHost(panoOrigin(), `/ilanlar/${query}`);
}

export function isSearchBot(request: { headers: Headers }) {
  return /Googlebot|Google-InspectionTool|GoogleOther|bingbot|BingPreview|YandexBot|DuckDuckBot|Baiduspider|Slurp|Applebot|facebookexternalhit/i.test(
    request.headers.get("user-agent") || "",
  );
}

export function isMobileRequest(request: { headers: Headers }) {
  if (isSearchBot(request)) return false;
  const hint = request.headers.get("sec-ch-ua-mobile");
  if (hint === "?1") return true;
  if (hint === "?0") return false;
  return /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini|Mobile/i.test(
    request.headers.get("user-agent") || "",
  );
}

export function resolveSite(host: string | null): SiteKind {
  const name = hostName(host);
  const bare = name.startsWith("www.") ? name.slice(4) : name;
  const domains = getDomains();
  const raw = host || "";
  if (bare === domains.ilanHost || raw.includes(":3002")) return "ilan";
  if (bare === domains.panoHost || bare === "vitrinpano.site" || raw.includes(":3001")) return "pano";
  if (
    bare === domains.rehberHost ||
    bare === "zirverehber.site" ||
    bare === "localhost" ||
    bare === "127.0.0.1" ||
    raw.includes(":3000")
  ) {
    return "rehber";
  }
  return "pano";
}

export function isCityEscortPath(pathname: string) {
  return /^\/[a-z0-9-]+-escort(?:\/[a-z0-9-]+)?(?:\/amp)?\/?$/.test(pathname);
}
