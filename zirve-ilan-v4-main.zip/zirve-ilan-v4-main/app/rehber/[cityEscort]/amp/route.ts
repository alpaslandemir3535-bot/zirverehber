import { cityAmpHtml } from "@/lib/amp-html";
import { listingsForCity } from "@/lib/listings";
import { cityFromEscortParam } from "@/lib/seo";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ cityEscort: string }> }) {
  const { cityEscort } = await context.params;
  const city = cityFromEscortParam(cityEscort);
  if (!city) return new Response("Bulunamadı", { status: 404 });
  return new Response(cityAmpHtml(city, listingsForCity(city)), {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=300",
    },
  });
}
