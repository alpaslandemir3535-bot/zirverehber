import { isAdmin } from "@/lib/auth";
import { deleteAdmin, publicAdmin, updateAdmin } from "@/lib/admins";
import { rejectCrossOrigin } from "@/lib/http";
import { NextResponse } from "next/server";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const body = (await request.json()) as { username?: string; password?: string; name?: string };
  const result = updateAdmin(id, body);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json(publicAdmin(result.admin));
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const result = deleteAdmin(id);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}
