import { DurationBar } from "@/components/hesap/DurationBar";

export function ListingPulse({
  startedAt,
  expiresAt,
  waToday,
  waWeek,
}: {
  startedAt: string | null;
  expiresAt: string | null;
  waToday: number;
  waWeek: number;
}) {
  return (
    <div className="listing-pulse">
      <DurationBar startedAt={startedAt} expiresAt={expiresAt} />
      <div className="wa-stats">
        <article>
          <span>Günlük WhatsApp</span>
          <strong>{waToday.toLocaleString("tr-TR")}</strong>
          <em>Bugün</em>
        </article>
        <article>
          <span>Haftalık WhatsApp</span>
          <strong>{waWeek.toLocaleString("tr-TR")}</strong>
          <em>Pazartesiden bugüne</em>
        </article>
      </div>
    </div>
  );
}
