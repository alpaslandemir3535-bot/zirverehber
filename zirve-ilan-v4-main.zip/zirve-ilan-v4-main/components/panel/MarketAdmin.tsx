"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { MarketProduct } from "@/lib/market";

export function MarketAdmin({ products, address }: { products: MarketProduct[]; address: string }) {
  const router = useRouter();
  const [wallet, setWallet] = useState(address);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function saveAddress(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setMessage("");
    const res = await fetch("/api/market/address", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ marketTrc20Address: wallet }),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(json.error || "Adres kaydedilemedi.");
      return;
    }
    setMessage("Market adresi kaydedildi. İlan yenileme adresinden ayrıdır.");
  }

  return (
    <>
      <form className="panel-card form-grid" onSubmit={saveAddress}>
        <label className="full">
          Market TRC20 adresi
          <input value={wallet} onChange={(event) => setWallet(event.target.value)} placeholder="T ile başlayan 34 karakter" spellCheck={false} />
        </label>
        {error ? <p className="err full">{error}</p> : null}
        {message ? <p className="muted full">{message}</p> : null}
        <div>
          <button className="btn" type="submit">
            Adresi kaydet
          </button>
        </div>
      </form>
      <div className="market-grid" style={{ marginTop: 16 }}>
        {products.map((product) => (
          <ProductEditor key={product.id} product={product} />
        ))}
        <NewProduct />
      </div>
    </>
  );
}

function ProductEditor({ product }: { product: MarketProduct }) {
  const router = useRouter();
  const [name, setName] = useState(product.name);
  const [price, setPrice] = useState(String(product.priceUsd || ""));
  const [stock, setStock] = useState(String(product.stock));
  const [image, setImage] = useState(product.image);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function save() {
    setBusy(true);
    setError("");
    const res = await fetch(`/api/market/products/${product.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, priceUsd: price || 0, stock: Number(stock), image }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(json.error || "Kaydedilemedi.");
      return;
    }
    router.refresh();
  }

  async function remove() {
    setError("");
    const res = await fetch(`/api/market/products/${product.id}`, { method: "DELETE" });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(json.error || "Silinemedi.");
      return;
    }
    router.refresh();
  }

  async function upload(files: FileList | null) {
    if (!files?.[0]) return;
    const data = new FormData();
    data.append("files", files[0]);
    const res = await fetch("/api/upload", { method: "POST", body: data });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(json.error || "Görsel yüklenemedi.");
      return;
    }
    setImage((json.urls as string[])[0] || image);
  }

  return (
    <article className="market-card">
      {image ? <img src={image} alt="" /> : <div className="market-photo" />}
      <label>
        Ürün
        <input value={name} onChange={(event) => setName(event.target.value)} />
      </label>
      <label>
        Fiyat ($)
        <input inputMode="decimal" value={price} onChange={(event) => setPrice(event.target.value)} />
      </label>
      <label>
        Stok adedi
        <input type="number" min={0} value={stock} onChange={(event) => setStock(event.target.value)} />
      </label>
      <label>
        Görsel
        <input type="file" accept="image/*" onChange={(event) => void upload(event.target.files)} />
      </label>
      {error ? <p className="err">{error}</p> : null}
      <div className="row-actions">
        <button className="btn" type="button" disabled={busy} onClick={save}>
          {busy ? "Kaydediliyor" : "Güncelle"}
        </button>
        <button className="btn ghost" type="button" onClick={remove}>
          Çıkar
        </button>
      </div>
    </article>
  );
}

function NewProduct() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("0");
  const [image, setImage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function add(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/market", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, priceUsd: price, stock: Number(stock), image }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(json.error || "Eklenemedi.");
      return;
    }
    setName("");
    setPrice("");
    setStock("0");
    setImage("");
    router.refresh();
  }

  async function upload(files: FileList | null) {
    if (!files?.[0]) return;
    const data = new FormData();
    data.append("files", files[0]);
    const res = await fetch("/api/upload", { method: "POST", body: data });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(json.error || "Görsel yüklenemedi.");
      return;
    }
    setImage((json.urls as string[])[0] || "");
  }

  return (
    <form className="market-card" onSubmit={add}>
      <h2>Yeni ürün</h2>
      <label>
        Ürün
        <input value={name} onChange={(event) => setName(event.target.value)} required />
      </label>
      <label>
        Fiyat ($)
        <input inputMode="decimal" value={price} onChange={(event) => setPrice(event.target.value)} required />
      </label>
      <label>
        Stok adedi
        <input type="number" min={0} value={stock} onChange={(event) => setStock(event.target.value)} required />
      </label>
      <label>
        Görsel
        <input type="file" accept="image/*" onChange={(event) => void upload(event.target.files)} />
      </label>
      {image ? <img src={image} alt="" /> : null}
      {error ? <p className="err">{error}</p> : null}
      <button className="btn" type="submit" disabled={busy}>
        {busy ? "Ekleniyor" : "Ekle"}
      </button>
    </form>
  );
}
