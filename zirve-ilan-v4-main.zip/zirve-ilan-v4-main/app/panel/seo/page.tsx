import { cities } from "@/lib/cities";

export default function SeoIndexPage() {
  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">İçerik</p>
          <h1>Seo ilan yazıları</h1>
          <p className="muted">Yazılar, o ilde yayındaki ilanların adıyla hazırlanır. İlanda olmayan isimle yazı çıkmaz. Listedekiler taslaktır; bir yazıyı açıp kaydetmediğin sürece siteye çıkmaz.</p>
        </div>
      </div>
      <div className="panel-card panel-city-grid">
        {cities.map((city) => (
          <a key={city.slug} href={`/panel/seo/${city.slug}/`}>
            {city.name}
          </a>
        ))}
      </div>
    </>
  );
}
