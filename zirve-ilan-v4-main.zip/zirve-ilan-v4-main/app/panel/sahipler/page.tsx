"use client";

import { useEffect, useState } from "react";

type OwnerRow = { id: string; username: string; name: string; listingCount: number };

export default function OwnersPage() {
  const [owners, setOwners] = useState<OwnerRow[]>([]);
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  async function load() {
    const res = await fetch("/api/owners");
    if (res.ok) setOwners(await res.json());
  }

  useEffect(() => {
    load();
  }, []);

  async function create(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    const res = await fetch("/api/owners", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, name }),
    });
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "Eklenemedi.");
      return;
    }
    setUsername("");
    setName("");
    load();
  }

  async function remove(owner: OwnerRow) {
    const attached = owner.listingCount
      ? ` Bu hesabın ${owner.listingCount} ilanı var. Hesap silinir, ilan durur ve sahip ataması kalkar.`
      : "";
    if (!window.confirm(`${owner.name} (${owner.username}) silinsin mi?${attached}`)) return;
    setError("");
    const res = await fetch(`/api/owners/${owner.id}`, { method: "DELETE" });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(json.error || "Silinemedi.");
      return;
    }
    load();
  }

  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Hesaplar</p>
          <h1>İlan sahipleri</h1>
        </div>
      </div>
      <form className="panel-card form-grid" onSubmit={create}>
        <label>
          Ad
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label>
          Kullanıcı adı
          <input value={username} onChange={(e) => setUsername(e.target.value)} required />
        </label>
        <div>
          <button className="btn" type="submit">
            Hesap aç
          </button>
        </div>
        {error ? <p className="err full">{error}</p> : null}
      </form>
      <div className="panel-card" style={{ marginTop: 16 }}>
        <table>
          <thead>
            <tr>
              <th>Ad</th>
              <th>Kullanıcı</th>
              <th>İlan</th>
              <th>Giriş</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {owners.map((owner) => (
              <tr key={owner.id}>
                <td>{owner.name}</td>
                <td>{owner.username}</td>
                <td>{owner.listingCount ? `${owner.listingCount} ilan` : "İlan yok"}</td>
                <td>/hesap/login</td>
                <td>
                  <button className="btn ghost" type="button" onClick={() => remove(owner)}>
                    Sil
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p>Girişte şifre yok. Sahip, yalnızca burada tanımlanan kullanıcı adı ile /hesap/login adresinden girer. İlanı düzenlerken “İlan sahibi” alanından ata. Hesabı silersen ilan yayında kalır, sahip ataması kalkar.</p>
      </div>
    </>
  );
}
