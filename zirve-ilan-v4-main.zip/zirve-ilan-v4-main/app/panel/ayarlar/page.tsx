import { BackupSettings } from "@/components/panel/BackupSettings";
import { DomainSettings } from "@/components/panel/DomainSettings";
import { FaviconSettings } from "@/components/panel/FaviconSettings";
import { GscSettings } from "@/components/panel/GscSettings";
import { GaSettings } from "@/components/panel/GaSettings";
import { IlanVerSettings } from "@/components/panel/IlanVerSettings";
import { ListingPrefs } from "@/components/panel/ListingPrefs";
import { ThemeSettings } from "@/components/panel/ThemeSettings";
import { Trc20Settings } from "@/components/panel/Trc20Settings";
import { TelegramSettings } from "@/components/panel/TelegramSettings";
import { WaMessageSettings } from "@/components/panel/WaMessageSettings";
import { publicSettings } from "@/lib/settings";
import { rehberOrigin } from "@/lib/site";

export const dynamic = "force-dynamic";

export default function SettingsPage() {
  const settings = publicSettings();
  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Alan adları</p>
          <h1>Ön alan ve ilan adresi</h1>
        </div>
      </div>
      <DomainSettings {...settings.domains} />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Yedek</p>
          <h1>Haftalık veritabanı</h1>
        </div>
      </div>
      <BackupSettings lastBackupAt={settings.lastBackupAt} backupDue={settings.backupDue} />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Vitrin</p>
          <h1>Sıralama, dönen fotoğraf ve süre</h1>
        </div>
      </div>
      <ListingPrefs
        shuffleListings={settings.shuffleListings}
        rotatePhotos={settings.rotatePhotos}
        expiryNotifyDays={settings.expiryNotifyDays}
      />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Ödeme</p>
          <h1>Bitcoin TRC20 adresi</h1>
        </div>
      </div>
      <Trc20Settings trc20Address={settings.trc20Address} />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Site</p>
          <h1>İLAN VER numarası</h1>
        </div>
      </div>
      <IlanVerSettings
        ilanVerPhone={settings.ilanVerPhone}
        vitrinIlanTitle={settings.vitrinIlanTitle}
        vitrinIlanTitleColor={settings.vitrinIlanTitleColor}
        vitrinIlanTitleSize={settings.vitrinIlanTitleSize}
        vitrinIlanNote={settings.vitrinIlanNote}
        vitrinIlanNoteColor={settings.vitrinIlanNoteColor}
        vitrinIlanNoteSize={settings.vitrinIlanNoteSize}
      />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
        <p className="eyebrow">Görünüm</p>
        <h1>Site teması</h1>
        </div>
      </div>
      <ThemeSettings
        vitrinBg={settings.vitrinBg}
        vitrinCard={settings.vitrinCard}
        vitrinAccent={settings.vitrinAccent}
        vitrinHero={settings.vitrinHero}
        vitrinText={settings.vitrinText}
        vitrinVip={settings.vitrinVip}
        vitrinGold={settings.vitrinGold}
        vitrinYeni={settings.vitrinYeni}
        vitrinTopTier={settings.vitrinTopTier}
        vitrinLogoText={settings.vitrinLogoText}
        vitrinLogoColor={settings.vitrinLogoColor}
        vitrinBgImage={settings.vitrinBgImage}
        vitrinOtherTitleColor={settings.vitrinOtherTitleColor}
        vitrinOtherTextColor={settings.vitrinOtherTextColor}
        vitrinOtherMutedColor={settings.vitrinOtherMutedColor}
        vitrinOtherFont={settings.vitrinOtherFont}
        vitrinFont={settings.vitrinFont}
        vitrinProfileBg={settings.vitrinProfileBg}
        vitrinProfileColor={settings.vitrinProfileColor}
      />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Görünüm</p>
          <h1>Favicon</h1>
        </div>
      </div>
      <FaviconSettings favicon={settings.favicon} />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Vitrin</p>
          <h1>WhatsApp ilan mesajı</h1>
        </div>
      </div>
      <WaMessageSettings waListingMessage={settings.waListingMessage} />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Google</p>
          <h1>Analytics</h1>
        </div>
      </div>
      <GaSettings gaMeasurementId={settings.gaMeasurementId} />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Google</p>
          <h1>Search Console</h1>
        </div>
      </div>
      <GscSettings
        gscSiteUrl={settings.gscSiteUrl}
        gscClientEmail={settings.gscClientEmail}
        gscVerifyMeta={settings.gscVerifyMeta}
        gscReady={settings.gscReady}
        gscPrivateKeyMasked={settings.gscPrivateKeyMasked}
      />

      <div className="panel-row" style={{ marginTop: 28 }}>
        <div>
          <p className="eyebrow">Bağlantılar</p>
          <h1>Telegram bildirimi</h1>
        </div>
      </div>
      <TelegramSettings
        telegramChatId={settings.telegramChatId}
        telegramDaily={settings.telegramDaily}
        telegramReady={settings.telegramReady}
        telegramBotTokenMasked={settings.telegramBotTokenMasked}
        lastTelegramAt={settings.lastTelegramAt}
        cronHint={`curl -sL ${rehberOrigin()}/api/cron/telegram/?secret=CRON_SECRET`}
      />
    </>
  );
}
