import { fetchGscDashboard } from "@/lib/gsc";
import { publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

function Kpi({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <article className="kpi">
      <span>{label}</span>
      <strong>{value}</strong>
      {hint ? <em>{hint}</em> : null}
    </article>
  );
}

export default async function GscPage() {
  const settings = publicSettings();
  const data = await fetchGscDashboard();

  return (
    <>
      <div className="panel-row">
        <div>
          <p className="eyebrow">Google</p>
          <h1>Search Console</h1>
        </div>
        <a className="btn secondary" href="/panel/ayarlar/">
          {settings.gscReady ? "Bağlantıyı düzenle" : "GSC bağla"}
        </a>
      </div>

      {!data.ready ? (
        <div className="panel-card">
          <p className="muted">{data.error}</p>
          <p className="muted">Sayılar site doğrulanıp servis hesabı eklenince gelir. GSC verisi 2–3 gün geriden gelir.</p>
        </div>
      ) : (
        <>
          <p className="muted">{data.siteUrl} · son 28 gün (GSC gecikmeli)</p>
          <section className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))" }}>
            <Kpi label="Tıklama" value={data.clicks.toLocaleString("tr-TR")} />
            <Kpi label="Gösterim" value={data.impressions.toLocaleString("tr-TR")} />
            <Kpi label="CTR" value={`${(data.ctr * 100).toFixed(1)}%`} />
            <Kpi label="Ort. sıra" value={data.avgPosition.toFixed(1)} />
          </section>
          <section className="dash-grid">
            <div className="panel-card">
              <h2>Sorgular</h2>
              {data.queries.length ? (
                <table>
                  <thead>
                    <tr>
                      <th>Sorgu</th>
                      <th>Tık</th>
                      <th>Gösterim</th>
                      <th>Sıra</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.queries.map((row) => (
                      <tr key={row.query}>
                        <td>{row.query}</td>
                        <td>{row.clicks}</td>
                        <td>{row.impressions}</td>
                        <td>{row.position.toFixed(1)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="muted">Henüz sorgu yok. İndeks geldikten sonra dolar.</p>
              )}
            </div>
            <div className="panel-card">
              <h2>Sayfalar</h2>
              {data.pages.length ? (
                <table>
                  <thead>
                    <tr>
                      <th>Sayfa</th>
                      <th>Tık</th>
                      <th>Sıra</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.pages.map((row) => (
                      <tr key={row.page}>
                        <td>{row.page.replace(/^https?:\/\//, "")}</td>
                        <td>{row.clicks}</td>
                        <td>{row.position.toFixed(1)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="muted">Henüz sayfa verisi yok.</p>
              )}
            </div>
          </section>
        </>
      )}
    </>
  );
}
