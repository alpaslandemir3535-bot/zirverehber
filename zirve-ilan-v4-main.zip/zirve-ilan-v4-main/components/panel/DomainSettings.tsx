"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  rehberHost: string;
  panoHost: string;
  ilanHost: string;
};

export function DomainSettings(props: Props) {
  const router = useRouter();
  const [rehberHost, setRehberHost] = useState(props.rehberHost);
  const [panoHost, setPanoHost] = useState(props.panoHost);
  const [ilanHost, setIlanHost] = useState(props.ilanHost);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/domains", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rehberHost, panoHost, ilanHost }),
    });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Alan adları tüm sitede güncellendi." : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <p className="full muted">
        Site düşünce veya alan adı kapanınca üç adresi yazıp tek kaydet. Yönlendirme, ilan linki, sitemap ve panel aynı kaydı kullanır. Sunucuyu yeniden başlatmana gerek yok.
      </p>
      <p className="full muted">
        Türkiye'de erişim engeli gelirse sadece kapanan kutuyu değiştir, diğer ikisini elleme. Yeni adresin DNS'i aynı sunucuya bağlı olsun, sonra kaydet.
        Webde görünen kapanırsa il sayfaları ve sitemap bu kutuya yazdığın yeni adrese geçer; reklam linkini de o yeni adrese çek. Ön alan kapanırsa vitrin adresi değişir, rehber mobilde açılmaya devam eder. İlan alanı kapanırsa kart tıklaması yeni ilan adresine gider.
        Engel yiyen adres Türkiye'deki telefonda açılmaz. Site görünür kalır çünkü diğer iki adres ayrıdır; onlar engellenmediyse telefon onları açar.
      </p>
      <label>
        Webde görünen
        <input value={rehberHost} onChange={(event) => setRehberHost(event.target.value)} placeholder="zirverehber.com" required />
      </label>
      <label>
        Ön alan (.com tıklanınca)
        <input value={panoHost} onChange={(event) => setPanoHost(event.target.value)} placeholder="zirvepano.xyz" required />
      </label>
      <label>
        İlan alanı
        <input value={ilanHost} onChange={(event) => setIlanHost(event.target.value)} placeholder="zirveilan.xyz" required />
      </label>
      <div className="full">
        <button className="btn" type="submit" disabled={busy}>
          {busy ? "Kaydediliyor" : "Tüm sitede değiştir"}
        </button>
      </div>
      {message ? <p className="full">{message}</p> : null}
    </form>
  );
}
