"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  ilanVerPhone: string;
  vitrinIlanTitle: string;
  vitrinIlanTitleColor: string;
  vitrinIlanTitleSize: number;
  vitrinIlanNote: string;
  vitrinIlanNoteColor: string;
  vitrinIlanNoteSize: number;
};

export function IlanVerSettings(props: Props) {
  const router = useRouter();
  const [phone, setPhone] = useState(props.ilanVerPhone);
  const [bannerTitle, setBannerTitle] = useState(props.vitrinIlanTitle);
  const [bannerNote, setBannerNote] = useState(props.vitrinIlanNote);
  const [titleSize, setTitleSize] = useState(props.vitrinIlanTitleSize);
  const [noteSize, setNoteSize] = useState(props.vitrinIlanNoteSize);
  const [colors, setColors] = useState({
    vitrinIlanTitleColor: props.vitrinIlanTitleColor,
    vitrinIlanNoteColor: props.vitrinIlanNoteColor,
  });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/telegram/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ilanVerPhone: phone,
        vitrinIlanTitle: bannerTitle,
        vitrinIlanNote: bannerNote,
        vitrinIlanTitleSize: titleSize,
        vitrinIlanNoteSize: noteSize,
        ...colors,
      }),
    });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Kaydedildi." : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <p className="full muted">
        Sitedeki İLAN VER şeridine tıklanınca bu numaraya WhatsApp açılır. Türkiye veya yabancı numara
        olabilir.
      </p>
      <label>
        İLAN VER yazısı
        <input value={bannerTitle} maxLength={40} onChange={(event) => setBannerTitle(event.target.value)} />
      </label>
      <label>
        İLAN VER boyutu
        <input type="number" min={12} max={40} value={titleSize} onChange={(event) => setTitleSize(Number(event.target.value))} />
      </label>
      <label>
        İLAN VER rengi
        <span className="theme-field">
          <input
            type="color"
            value={colors.vitrinIlanTitleColor}
            onChange={(event) => setColors((prev) => ({ ...prev, vitrinIlanTitleColor: event.target.value }))}
            aria-label="İLAN VER rengi"
          />
          <input
            value={colors.vitrinIlanTitleColor}
            onChange={(event) => setColors((prev) => ({ ...prev, vitrinIlanTitleColor: event.target.value }))}
            spellCheck={false}
          />
        </span>
      </label>
      <label className="full">
        Alt yazı
        <input value={bannerNote} maxLength={120} onChange={(event) => setBannerNote(event.target.value)} />
      </label>
      <label>
        Alt yazı boyutu
        <input type="number" min={9} max={22} value={noteSize} onChange={(event) => setNoteSize(Number(event.target.value))} />
      </label>
      <label>
        Alt yazı rengi
        <span className="theme-field">
          <input
            type="color"
            value={colors.vitrinIlanNoteColor}
            onChange={(event) => setColors((prev) => ({ ...prev, vitrinIlanNoteColor: event.target.value }))}
            aria-label="Alt yazı rengi"
          />
          <input
            value={colors.vitrinIlanNoteColor}
            onChange={(event) => setColors((prev) => ({ ...prev, vitrinIlanNoteColor: event.target.value }))}
            spellCheck={false}
          />
        </span>
      </label>
      <label>
        WhatsApp numarası
        <input
          value={phone}
          onChange={(event) => setPhone(event.target.value)}
          placeholder="+90 532 000 0000"
          inputMode="tel"
        />
      </label>
      <div className="full row-actions">
        <button className="btn" type="submit" disabled={busy}>
          Kaydet
        </button>
        {message ? <span className="muted">{message}</span> : null}
      </div>
    </form>
  );
}
