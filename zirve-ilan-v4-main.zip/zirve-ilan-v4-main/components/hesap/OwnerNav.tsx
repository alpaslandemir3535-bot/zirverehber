"use client";

import { usePathname } from "next/navigation";

const links = [
  { href: "/hesap/", label: "İlanlarım", match: (path: string) => path === "/hesap" || path === "/hesap/" || path.startsWith("/hesap/ilan") },
];

export function OwnerNav() {
  const pathname = usePathname();
  return (
    <nav>
      {links.map((link) => (
        <a key={link.href} href={link.href} className={link.match(pathname) ? "on" : ""}>
          {link.label}
        </a>
      ))}
    </nav>
  );
}
