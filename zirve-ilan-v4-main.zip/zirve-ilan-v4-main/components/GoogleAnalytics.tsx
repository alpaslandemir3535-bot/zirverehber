"use client";

import Script from "next/script";
import { usePathname } from "next/navigation";

export function GoogleAnalytics({ measurementId }: { measurementId: string }) {
  const path = usePathname() || "";
  if (!measurementId) return null;
  if (path.startsWith("/panel") || path.startsWith("/hesap")) return null;
  return (
    <>
      <Script src={`https://www.googletagmanager.com/gtag/js?id=${measurementId}`} strategy="afterInteractive" />
      <Script id="ga4" strategy="afterInteractive">
        {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${measurementId}');`}
      </Script>
    </>
  );
}
