import { AdGrid } from "@/components/AdGrid";
import { IlanVerBar, SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { ilanVerHref } from "@/lib/settings";
import { cities } from "@/lib/cities";
import { listingsForCity } from "@/lib/listings";
import { keywordsForCity } from "@/lib/seo-keywords";
import { cityFromEscortParam, cityPostBody, cityPostBySlug, cityPosts, citySeoTitle } from "@/lib/seo";
import { cityPagePath, rehberOrigin, rehberUrl } from "@/lib/site";
import type { Metadata } from "next";
import { notFound } from "next/navigation";

type Props = { params: Promise<{ cityEscort: string; post: string }> };

export const revalidate = 300;

export function generateStaticParams() {
  return cities.flatMap((city) =>
    cityPosts(city).map((post) => ({
      cityEscort: `${city.slug}-escort`,
      post: post.slug,
    })),
  );
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { cityEscort, post: postSlug } = await params;
  const city = cityFromEscortParam(cityEscort);
  if (!city) return {};
  const post = cityPostBySlug(city, postSlug);
  if (!post) return {};
  return {
    title: `${post.title} | ${city.name} Escort`,
    description: cityPostBody(city, post).replace(/\s+/g, " ").slice(0, 160),
    keywords: keywordsForCity(city),
    alternates: { canonical: rehberUrl(post.path) },
    robots: { index: true, follow: true },
    icons: { other: [{ rel: "amphtml", url: `${rehberOrigin()}${post.path}amp/` }] },
    openGraph: {
      title: `${post.title} | ${city.name} Escort`,
      description: cityPostBody(city, post).slice(0, 180),
      url: rehberUrl(post.path),
      locale: "tr_TR",
      type: "article",
      siteName: "Zirve Rehber",
    },
  };
}

export default async function CityPostPage({ params }: Props) {
  const { cityEscort, post: postSlug } = await params;
  const city = cityFromEscortParam(cityEscort);
  if (!city) notFound();
  const post = cityPostBySlug(city, postSlug);
  if (!post) notFound();

  return (
    <>
      <SiteHeader title={`${city.name} Escort`} href={rehberUrl(cityPagePath(city.slug))} />
      <IlanVerBar href={ilanVerHref()} />
      <header className="archive-page-header">
        <h1>{post.title}</h1>
        <div className="archive-description">{cityPostBody(city, post)}</div>
        <p>
          <a href={rehberUrl(cityPagePath(city.slug))}>{citySeoTitle(city)}</a>
        </p>
      </header>
      <AdGrid listings={listingsForCity(city)} cityName={city.name} />
      <SiteFooter />
    </>
  );
}
