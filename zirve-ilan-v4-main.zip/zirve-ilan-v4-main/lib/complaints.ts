import { randomUUID } from "crypto";
import path from "path";
import { readJsonFile, writeJsonFile } from "./json-file";

export type Complaint = {
  id: string;
  name: string;
  phone: string;
  message: string;
  listingId: string | null;
  read: boolean;
  createdAt: string;
};

const file = path.join(process.cwd(), "data", "complaints.json");

function readAll(): Complaint[] {
  const raw = readJsonFile<Complaint[]>(file, []);
  return Array.isArray(raw) ? raw : [];
}

function writeAll(items: Complaint[]) {
  writeJsonFile(file, items);
}

export function getComplaints() {
  return readAll().sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
}

export function unreadComplaintCount() {
  return readAll().filter((item) => !item.read).length;
}

export function createComplaint(input: { name: string; phone: string; message: string; listingId?: string }) {
  const message = input.message.trim().slice(0, 1000);
  if (!message) return { error: "Mesaj yaz." as const };
  const item: Complaint = {
    id: randomUUID(),
    name: input.name.trim().slice(0, 80) || "İsimsiz",
    phone: input.phone.trim().slice(0, 30),
    message,
    listingId: input.listingId || null,
    read: false,
    createdAt: new Date().toISOString(),
  };
  const items = readAll();
  items.unshift(item);
  writeAll(items);
  return { complaint: item };
}

export function markComplaintRead(id: string, read = true) {
  const items = readAll();
  const item = items.find((row) => row.id === id);
  if (!item) return null;
  item.read = read;
  writeAll(items);
  return item;
}
