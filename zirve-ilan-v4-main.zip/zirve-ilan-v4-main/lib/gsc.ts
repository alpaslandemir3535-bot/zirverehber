import { createSign } from "crypto";
import { getSettings } from "./settings";

export type GscRow = {
  keys: string[];
  clicks: number;
  impressions: number;
  ctr: number;
  position: number;
};

type QueryResult = { rows?: GscRow[]; error?: { message?: string } };

export type GscDashboard =
  | { ready: false; error: string }
  | {
      ready: true;
      siteUrl: string;
      clicks: number;
      impressions: number;
      ctr: number;
      avgPosition: number;
      series: { date: string; clicks: number; impressions: number }[];
      queries: { query: string; clicks: number; impressions: number; position: number }[];
      pages: { page: string; clicks: number; impressions: number; position: number }[];
    };

let cache: { at: number; payload: GscDashboard } | null = null;
const CACHE_MS = 30 * 60 * 1000;

function base64url(input: string | Buffer) {
  const buf = Buffer.isBuffer(input) ? input : Buffer.from(input);
  return buf.toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function gscCredentials() {
  const settings = getSettings();
  return {
    siteUrl: (settings.gscSiteUrl || process.env.GSC_SITE_URL || "").trim(),
    email: (settings.gscClientEmail || process.env.GSC_CLIENT_EMAIL || "").trim(),
    key: (settings.gscPrivateKey || process.env.GSC_PRIVATE_KEY || "").replace(/\\n/g, "\n").trim(),
  };
}

export function gscReady() {
  const creds = gscCredentials();
  return Boolean(creds.siteUrl && creds.email && creds.key.includes("BEGIN"));
}

async function accessToken() {
  const { email, key } = gscCredentials();
  const now = Math.floor(Date.now() / 1000);
  const header = base64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = base64url(
    JSON.stringify({
      iss: email,
      scope: "https://www.googleapis.com/auth/webmasters.readonly",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    }),
  );
  const unsigned = `${header}.${claim}`;
  const signer = createSign("RSA-SHA256");
  signer.update(unsigned);
  const jwt = `${unsigned}.${base64url(signer.sign(key))}`;
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt,
    }),
  });
  const json = (await res.json()) as { access_token?: string; error_description?: string };
  if (!json.access_token) throw new Error(json.error_description || "Google token alınamadı.");
  return json.access_token;
}

function dayStamp(daysAgo: number) {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() - daysAgo);
  return date.toISOString().slice(0, 10);
}

async function query(token: string, dimensions: string[], startDays: number, rowLimit = 20) {
  const { siteUrl } = gscCredentials();
  const encoded = encodeURIComponent(siteUrl);
  const res = await fetch(`https://searchconsole.googleapis.com/webmasters/v3/sites/${encoded}/searchAnalytics/query`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      startDate: dayStamp(startDays),
      endDate: dayStamp(2),
      dimensions,
      rowLimit,
    }),
  });
  const json = (await res.json()) as QueryResult;
  if (!res.ok) throw new Error(json.error?.message || "Search Console verisi alınamadı.");
  return json.rows || [];
}

function sumRows(rows: GscRow[]) {
  return rows.reduce(
    (acc, row) => ({
      clicks: acc.clicks + (row.clicks || 0),
      impressions: acc.impressions + (row.impressions || 0),
    }),
    { clicks: 0, impressions: 0 },
  );
}

export async function fetchGscDashboard(): Promise<GscDashboard> {
  if (!gscReady()) {
    return { ready: false as const, error: "Search Console bağlı değil." };
  }
  if (cache && Date.now() - cache.at < CACHE_MS && cache.payload.ready) {
    return cache.payload;
  }
  try {
    const token = await accessToken();
    const [days, queries, pages] = await Promise.all([
      query(token, ["date"], 30, 40),
      query(token, ["query"], 28, 12),
      query(token, ["page"], 28, 12),
    ]);
    const totals = sumRows(days);
    const payload = {
      ready: true as const,
      siteUrl: gscCredentials().siteUrl,
      clicks: Math.round(totals.clicks),
      impressions: Math.round(totals.impressions),
      ctr: totals.impressions ? totals.clicks / totals.impressions : 0,
      avgPosition:
        days.reduce((acc, row) => acc + (row.position || 0) * (row.impressions || 0), 0) /
          Math.max(1, totals.impressions) || 0,
      series: days.map((row) => ({
        date: row.keys[0],
        clicks: Math.round(row.clicks || 0),
        impressions: Math.round(row.impressions || 0),
      })),
      queries: queries.map((row) => ({
        query: row.keys[0],
        clicks: Math.round(row.clicks || 0),
        impressions: Math.round(row.impressions || 0),
        position: row.position || 0,
      })),
      pages: pages.map((row) => ({
        page: row.keys[0],
        clicks: Math.round(row.clicks || 0),
        impressions: Math.round(row.impressions || 0),
        position: row.position || 0,
      })),
    };
    cache = { at: Date.now(), payload };
    return payload;
  } catch (error) {
    return {
      ready: false as const,
      error: error instanceof Error ? error.message : "Search Console hatası.",
    };
  }
}

export function clearGscCache() {
  cache = null;
}
