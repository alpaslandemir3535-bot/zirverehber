import { fullCoverage } from "./districts";
import { isSharedBio, listingArticle } from "./owner-bio";
import { CATEGORIES, toPhoneDigits, type ListingInput } from "./listing-types";

function keptBio(value: unknown, source: Parameters<typeof listingArticle>[0]) {
  const text = typeof value === "string" ? value.replace(/\s+\n/g, "\n").trim() : "";
  if (!isSharedBio(text)) return text.slice(0, 1200);
  return listingArticle(source);
}

function measure(value: unknown, min: number, max: number) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.min(max, Math.max(min, n));
}

export function cleanMarks(value: unknown) {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const marks: string[] = [];
  for (const item of value) {
    if (typeof item !== "string") continue;
    const text = item.replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 40);
    const key = text.toLocaleLowerCase("tr");
    if (!text || seen.has(key)) continue;
    seen.add(key);
    marks.push(text);
    if (marks.length >= 8) break;
  }
  return marks;
}

export function parseListingInput(body: Partial<ListingInput>): ListingInput | string {
  if (!body.name?.trim()) return "Ad gerekli.";
  if (!body.phone?.trim()) return "Telefon gerekli.";
  const digits = toPhoneDigits(body.phone);
  if (digits.length < 8 || digits.length > 15) {
    return "Telefonu ülke koduyla yaz: +90..., +49..., +44...";
  }
  if (!body.category || !CATEGORIES.includes(body.category)) return "Kategori seç.";
  if (!["draft", "published", "hidden"].includes(body.status || "")) return "Yayın durumu seç.";
  if (!["days3", "week", "month"].includes(body.duration || "")) return "Süre seç: 3 gün, 1 hafta veya 1 ay.";
  const coverage = fullCoverage();
  const name = body.name.trim().slice(0, 80);
  const age = Math.min(99, Math.max(21, Number(body.age) || 21));
  const height = measure(body.height, 120, 220);
  const weight = measure(body.weight, 35, 200);
  const phone = body.phone.trim().slice(0, 24);
  return {
    name,
    displayName: (body.displayName || body.name).trim().slice(0, 80),
    category: body.category,
    phone,
    age,
    height,
    weight,
    bio: keptBio(body.bio, {
      name,
      displayName: (body.displayName || body.name).trim(),
      age,
      category: body.category,
      phone,
      eldenOdeme: Boolean(body.eldenOdeme),
      evOtelApart: Boolean(body.evOtelApart),
      gercekGoruntu: Boolean(body.gercekGoruntu),
    }),
    cover: (body.cover || "").slice(0, 240),
    gallery: (body.gallery || []).filter((item) => typeof item === "string").slice(0, 24),
    cities: coverage.cities,
    districts: coverage.districts,
    ownerId: body.ownerId || null,
    featured: Boolean(body.featured),
    gold: Boolean(body.gold),
    yeni: Boolean(body.yeni),
    eldenOdeme: Boolean(body.eldenOdeme),
    evOtelApart: Boolean(body.evOtelApart),
    gercekGoruntu: Boolean(body.gercekGoruntu),
    extraMarks: cleanMarks(body.extraMarks),
    sortOrder: Number(body.sortOrder) || 0,
    status: body.status || "draft",
    duration: body.duration || "month",
  };
}
