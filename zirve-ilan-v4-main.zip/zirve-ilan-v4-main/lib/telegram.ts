import { formatStatsMessage } from "./analytics";
import { getSettings, saveSettings } from "./settings";

const SIX_HOURS_MS = 6 * 60 * 60 * 1000;

export async function sendTelegramMessage(text: string, options?: { stamp?: boolean }) {
  const settings = getSettings();
  const token = settings.telegramBotToken || process.env.TELEGRAM_BOT_TOKEN || "";
  const chatId = settings.telegramChatId || process.env.TELEGRAM_CHAT_ID || "";
  if (!token || !chatId) return { ok: false, error: "Bot token veya chat id yok." as const };

  let res: Response;
  try {
    res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: text.slice(0, 3900), disable_web_page_preview: true }),
      signal: AbortSignal.timeout(8000),
    });
  } catch {
    return { ok: false, error: "Telegram zaman aşımı." as const };
  }
  const json = (await res.json().catch(() => ({}))) as { ok?: boolean; description?: string };
  if (!res.ok || !json.ok) {
    return { ok: false, error: json.description || "Telegram gönderilemedi." as const };
  }
  if (options?.stamp !== false) saveSettings({ lastTelegramAt: new Date().toISOString() });
  return { ok: true as const };
}

export async function sendTelegramStats(_part: 1 | 2 = 1) {
  return sendTelegramMessage(formatStatsMessage());
}

export async function sendTelegramStatsPair() {
  const result = await sendTelegramStats();
  if (result.ok) saveSettings({ lastTelegramPart: 1, lastTelegramCronAt: new Date().toISOString() });
  return result;
}

export function nextTelegramPart(current: 1 | 2 | undefined): 1 | 2 {
  return current === 1 ? 2 : 1;
}

export function telegramDue(lastCronAt: string | null) {
  if (!lastCronAt) return true;
  return Date.now() - new Date(lastCronAt).getTime() >= SIX_HOURS_MS;
}

export async function sendScheduledTelegram() {
  const settings = getSettings();
  if (!settings.telegramDaily) return { ok: true as const, skipped: true as const };
  if (!telegramDue(settings.lastTelegramCronAt)) {
    return { ok: true as const, skipped: true as const, reason: "wait-6h" as const };
  }
  const result = await sendTelegramStats();
  if (!result.ok) return result;
  saveSettings({ lastTelegramCronAt: new Date().toISOString(), lastTelegramPart: 1 });
  return { ok: true as const, part: 1 as const };
}
