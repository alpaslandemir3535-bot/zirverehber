"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatUsd } from "@/lib/pay-plans";
import type { MarketProduct } from "@/lib/market";

export function OwnerMarket({
  products,
  address,
  waitingIds,
}: {
  products: MarketProduct[];
  address: string;
  waitingIds: string[];
}) {
  const router = useRouter();
  const [picked, setPicked] = useState<string | null>(null);
  const [qty, setQty] = useState<Record<string, string>>({});
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const product = products.find((item) => item.id === picked) ?? null;
  const count = product ? Math.max(1, Number(qty[product.id] || 1) || 1) : 1;
  const total = product ? product.priceUsd * count : 0;

  async function order() {
    if (!product) return;
    setBusy(true);
    setError("");
    const res = await fetch("/api/market/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id, qty: count, note }),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(json.error || "Sipariş kaydedilemedi.");
      return;
    }
    setPicked(null);
    setNote("");
    router.refresh();
  }

  async function copyAddress() {
    try {
      await navigator.clipboard.writeText(address);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <>
      <div className="market-grid">
        {products.map((item) => {
          const waiting = waitingIds.includes(item.id);
          const amount = qty[item.id] || "1";
          return (
            <article key={item.id} className="market-card">
              {item.image ? <img src={item.image} alt="" /> : <div className="market-photo" />}
              <h2>{item.name}</h2>
              <p>
                Stok: <strong>{item.stock}</strong>
              </p>
              <p>
                Fiyat: <strong>{item.priceUsd > 0 ? formatUsd(item.priceUsd) : "Yakında"}</strong>
              </p>
              {waiting ? (
                <p className="muted">Bu ürün için yönetici onayı bekleniyor.</p>
              ) : (
                <>
                  <label>
                    Sipariş miktarı
                    <input
                      type="number"
                      min={1}
                      max={Math.max(1, item.stock)}
                      value={amount}
                      onChange={(event) => setQty((prev) => ({ ...prev, [item.id]: event.target.value }))}
                    />
                  </label>
                  <button
                    className="btn"
                    type="button"
                    disabled={item.stock < 1 || !(item.priceUsd > 0)}
                    onClick={() => {
                      setPicked(item.id);
                      setError("");
                      setCopied(false);
                    }}
                  >
                    Ödeme yap
                  </button>
                </>
              )}
            </article>
          );
        })}
      </div>
      {picked && product ? (
        <div className="pay-modal" role="dialog" aria-modal="true" aria-labelledby="market-pay-title">
          <div className="pay-card">
            <p className="eyebrow">{product.name}</p>
            <h2 id="market-pay-title">Bitcoin TRC20 ile ödeme</h2>
            <p>
              {count} adet · {formatUsd(total)}. Ağ: TRC20. Bu adres ilan yenileme adresinden ayrıdır.
            </p>
            {address ? (
              <div className="pay-address">
                <code>{address}</code>
                <button className="btn ghost" type="button" onClick={copyAddress}>
                  {copied ? "Kopyalandı" : "Adresi kopyala"}
                </button>
              </div>
            ) : (
              <p className="err">Market ödeme adresi henüz tanımlanmadı.</p>
            )}
            <label className="pay-note-label">
              Sipariş notu
              <textarea className="pay-note" maxLength={300} value={note} placeholder="İsteğe bağlı" onChange={(event) => setNote(event.target.value)} />
            </label>
            {error ? <p className="err">{error}</p> : null}
            <div className="row-actions">
              <button className="btn" type="button" disabled={busy || !address} onClick={order}>
                {busy ? "Kaydediliyor" : `Ödeme yaptım · ${formatUsd(total)}`}
              </button>
              <button className="btn ghost" type="button" onClick={() => setPicked(null)}>
                Kapat
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
