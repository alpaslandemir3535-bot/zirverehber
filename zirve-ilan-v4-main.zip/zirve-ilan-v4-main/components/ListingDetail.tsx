import { ListingPhotos } from "@/components/ListingPhotos";
import { TrackLink } from "@/components/TrackLink";
import { VitrinCard } from "@/components/VitrinCard";
import { todayListingClicks } from "@/lib/analytics";
import { cities } from "@/lib/cities";
import type { Listing } from "@/lib/listings";
import { isSharedBio, listingArticle } from "@/lib/owner-bio";
import { getSettings } from "@/lib/settings";
import { vitrinStyle } from "@/lib/vitrin-style";
import { cityPagePath, rehberUrl, vitrinListingsUrl } from "@/lib/site";
import { getPublishedListings } from "@/lib/store";
import { arrangeVitrin, vitrinBadge } from "@/lib/vitrin-order";
import { listingWhatsAppHref } from "@/lib/whatsapp-listing";

function aboutParts(listing: Listing, city: string) {
  const stored = listing.bio.trim();
  const text = isSharedBio(stored) ? listingArticle(listing, city) : stored;
  const marks = [
    listing.eldenOdeme ? "ELDEN ÖDEME" : "",
    listing.evOtelApart ? "EV-OTEL-APART" : "",
    listing.gercekGoruntu ? "GERÇEK GÖRÜNTÜ" : "",
  ].filter(Boolean);
  const body = text.replaceAll("{şehir}", city).replaceAll("{sehir}", city).replace(/[ \t]{2,}/g, " ").trim();
  return { body, marks };
}

function badgeKind(badge: string) {
  if (badge === "VIP") return "vip";
  if (badge === "GOLD") return "gold";
  if (badge === "YENİ") return "yeni";
  return "";
}

export function ListingDetail({
  listing,
  cityName,
}: {
  listing: Listing;
  cityName?: string;
}) {
  const settings = getSettings();
  const city =
    cityName?.trim() || cities.find((item) => item.slug === listing.cities[0])?.name || "";
  const citySlug = cities.find((item) => item.name === city)?.slug || listing.cities[0] || "";
  const images = listing.gallery.length ? listing.gallery : listing.cover ? [listing.cover] : [];
  const badge = vitrinBadge(listing);
  const kind = badgeKind(badge);
  const clicks = todayListingClicks();
  const views = clicks[listing.id] || 0;
  const wa = listingWhatsAppHref(listing, city);
  const vitrinHref = vitrinListingsUrl(city || undefined);
  const cityHref = citySlug ? rehberUrl(cityPagePath(citySlug)) : vitrinHref;
  const others = arrangeVitrin(getPublishedListings().filter((item) => item.id !== listing.id)).slice(0, 4);
  const rotatePhotos = settings.rotatePhotos !== false;
  const about = aboutParts(listing, city);
  const rows = [
    ["Bölge", city],
    ["Profil", listing.category],
    ["Yaş", String(listing.age || "")],
    ["Boy", listing.height ? `${listing.height} cm` : ""],
    ["Kilo", listing.weight ? `${listing.weight} kg` : ""],
    ["Ödeme", listing.eldenOdeme ? "ELDEN ÖDEME" : ""],
    ["Görsel", listing.gercekGoruntu ? "GERÇEK GÖRÜNTÜ" : ""],
    ["Gelebileceği yerler", listing.evOtelApart ? "EV-OTEL-APART" : ""],
  ].filter((row) => row[1]);
  const style = vitrinStyle(settings);

  return (
    <div className="vitrin ilan-page" style={style}>
      <header className="vitrin-top">
        <a className="vitrin-brand" href={cityHref} style={{ color: settings.vitrinLogoColor }}>
          <span className="vitrin-mark" />
          <span className="vitrin-logo-text">{settings.vitrinLogoText}</span>
        </a>
        <a className="vitrin-nav" href={vitrinHref}>
          Vitrin
        </a>
      </header>

      <p className="ilan-crumb">
        <a href={vitrinHref}>Vitrin</a>
        {city ? (
          <>
            {" › "}
            <a href={cityHref}>{city} Escort</a>
          </>
        ) : null}
        {" › "}
        <span>{listing.displayName || listing.name}</span>
      </p>

      <div className="ilan-sheet">
        <ListingPhotos images={images} name={listing.displayName || listing.name} badge={badge} kind={kind} />
        <TrackLink href={wa} type="whatsapp" listingId={listing.id} city={city} className="ilan-wa" target="_blank">
          <WaIcon /> WhatsApp
        </TrackLink>

        <h1>{listing.displayName || listing.name}</h1>
        <p className="ilan-sub">
          {[city, listing.category].filter(Boolean).join(" · ")}
        </p>
        <p className="ilan-views">Bugün {views} kişi görüntüledi</p>
        <div className="ilan-tags">
          {city ? <a href={cityHref}>{city} Escort</a> : null}
          {listing.category ? <span>{listing.category}</span> : null}
        </div>
        <p className="ilan-note">Bu ilana Zirve Escort Sayfasından yazdığını söylemen yeterli.</p>

        <dl className="ilan-facts">
          {rows.map(([label, value]) => (
            <div key={label}>
              <dt>{label}</dt>
              <dd>{value}</dd>
            </div>
          ))}
        </dl>

        <section className="ilan-about-box">
          <h2>Hakkında</h2>
          <p className="ilan-about">{about.body}</p>
          {about.marks.length ? <p className="ilan-about-marks">{about.marks.join(" · ")}</p> : null}
        </section>
      </div>

      {others.length ? (
        <section className="vitrin-board vitrin-others">
          <p className="vitrin-kicker">Öne çıkan ilanlar</p>
          <h2>Diğer ilanlar</h2>
          <div className="vitrin-grid">
            {others.map((item) => (
              <VitrinCard
                key={item.id}
                listing={item}
                cityName={city}
                cityHref={cityHref}
                badge={vitrinBadge(item)}
                views={clicks[item.id] || 0}
                rotatePhotos={rotatePhotos}
                layout="other"
              />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function WaIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
      <path
        fill="currentColor"
        d="M12.04 2C6.58 2 2.15 6.4 2.15 11.83c0 1.74.46 3.44 1.34 4.94L2 22l5.39-1.41a10.1 10.1 0 0 0 4.65 1.12h.01c5.46 0 9.89-4.4 9.89-9.83C21.94 6.4 17.5 2 12.04 2zm5.76 13.9c-.24.68-1.4 1.3-1.94 1.38-.5.08-1.12.11-1.81-.11-.41-.14-.95-.31-1.64-.61-2.88-1.25-4.76-4.15-4.9-4.34-.14-.2-1.16-1.54-1.16-2.94 0-1.4.73-2.09 1-2.37.24-.26.64-.38.85-.38h.6c.19 0 .45-.07.7.53.26.63.88 2.16.96 2.32.08.16.03.35-.07.52l-.3.4c-.13.16-.27.36-.12.6.17.3.76 1.25 1.63 2.03 1.12 1 2.06 1.31 2.36 1.46.3.15.47.13.64-.08.17-.2.74-.86.94-1.16.2-.3.4-.24.67-.14.27.1 1.7.8 1.99.95.29.14.48.22.55.34.07.12.07.7-.17 1.38z"
      />
    </svg>
  );
}
