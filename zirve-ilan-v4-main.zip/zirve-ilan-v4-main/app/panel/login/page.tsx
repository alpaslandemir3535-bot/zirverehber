"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const STORAGE_KEY = "zirve.adminLogin";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw) as { username?: string; password?: string };
      if (saved.password) localStorage.removeItem(STORAGE_KEY);
      if (saved.username) setUsername(saved.username);
      setRemember(Boolean(saved.username) && !saved.password);
    } catch {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    const res = await fetch("/api/auth/login/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const json = (await res.json().catch(() => null)) as { error?: string } | null;
    if (!res.ok) {
      setError(json?.error || "Kullanıcı veya şifre yanlış.");
      return;
    }
    if (remember) localStorage.setItem(STORAGE_KEY, JSON.stringify({ username }));
    else localStorage.removeItem(STORAGE_KEY);
    router.push("/panel/");
    router.refresh();
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <p className="eyebrow">Zirve</p>
        <h1>Yönetici girişi</h1>
        <p className="muted">İlan, istatistik ve site ayarları.</p>
        <form onSubmit={submit} className="form-grid one-col" autoComplete="on">
          <label>
            Kullanıcı adı
            <input
              name="username"
              autoComplete="username"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              autoFocus
            />
          </label>
          <label>
            Şifre
            <input
              name="password"
              autoComplete="current-password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </label>
          <label className="check-line">
            <input type="checkbox" checked={showPassword} onChange={(event) => setShowPassword(event.target.checked)} />
            Şifreyi göster
          </label>
          <label className="check-line">
            <input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} />
            Kullanıcı adını kaydet
          </label>
          {error ? <p className="err">{error}</p> : null}
          <button className="btn" type="submit">
            Panele gir
          </button>
        </form>
      </div>
    </div>
  );
}
