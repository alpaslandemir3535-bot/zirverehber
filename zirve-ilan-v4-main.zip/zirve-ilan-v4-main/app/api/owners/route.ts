import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { listingsForOwner } from "@/lib/store";
import { createOwner, getOwners } from "@/lib/users";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json(
    getOwners().map(({ passwordHash: _h, ...owner }) => ({
      ...owner,
      listingCount: listingsForOwner(owner.id).length,
    })),
  );
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json()) as { username?: string; name?: string };
  if (!body.username?.trim()) {
    return NextResponse.json({ error: "Kullanıcı adı gerekli." }, { status: 400 });
  }
  const result = createOwner({
    username: body.username,
    name: body.name || body.username,
  });
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  const { passwordHash: _h, ...owner } = result.owner;
  return NextResponse.json(owner, { status: 201 });
}
