"use client";

import { useState } from "react";

type Row = { id: string; name: string; count: number };
type Span = "today" | "week" | "month";

const SPANS: { id: Span; label: string }[] = [
  { id: "today", label: "Günlük" },
  { id: "week", label: "Haftalık" },
  { id: "month", label: "Aylık" },
];

function Board({
  title,
  rows,
  countLabel,
  empty,
}: {
  title: string;
  rows: Row[];
  countLabel: string;
  empty: string;
}) {
  return (
    <div className="panel-card">
      <h2>{title}</h2>
      {rows.length ? (
        <table>
          <thead>
            <tr>
              <th>İlan</th>
              <th>{countLabel}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td>{row.name}</td>
                <td>{row.count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="muted">{empty}</p>
      )}
    </div>
  );
}

export function ClickBoards({
  clicks,
  whatsapp,
}: {
  clicks: Record<Span, Row[]>;
  whatsapp: Record<Span, Row[]>;
}) {
  const [span, setSpan] = useState<Span>("today");

  return (
    <section>
      <div className="span-picks" role="group" aria-label="Tıklama aralığı">
        {SPANS.map((item) => (
          <button key={item.id} type="button" className={span === item.id ? "btn" : "btn secondary"} onClick={() => setSpan(item.id)}>
            {item.label}
          </button>
        ))}
      </div>
      <div className="dash-grid">
        <Board
          title="En çok tıklanan ilanlar"
          rows={clicks[span]}
          countLabel="Tık"
          empty="Bu aralıkta ilan tıklaması yok. Vitrindeki kartlar sayılır."
        />
        <Board
          title="WhatsApp tıklamaları"
          rows={whatsapp[span]}
          countLabel="Mesaj"
          empty="Bu aralıkta WhatsApp tıklaması yok."
        />
      </div>
    </section>
  );
}
