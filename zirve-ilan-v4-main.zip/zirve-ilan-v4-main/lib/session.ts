import { isAdmin, ownerTokenFromCookie } from "./auth";
import { ownerFromToken, type Owner } from "./users";

export async function currentActor(): Promise<
  { role: "admin"; owner: null } | { role: "owner"; owner: Owner } | { role: null; owner: null }
> {
  if (await isAdmin()) return { role: "admin", owner: null };
  const owner = await ownerFromToken(await ownerTokenFromCookie());
  if (owner) return { role: "owner", owner };
  return { role: null, owner: null };
}
