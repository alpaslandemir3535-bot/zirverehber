"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";

export function FaviconSettings({ favicon }: { favicon: string }) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState(favicon);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function upload(file: File) {
    setBusy(true);
    setMessage("");
    const form = new FormData();
    form.set("file", file);
    const res = await fetch("/api/favicon", { method: "POST", body: form });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setMessage(json.error || "Yüklenemedi.");
      return;
    }
    setPreview(json.favicon);
    setMessage("Kaydedildi. Sekmede birkaç saniye sonra görünür.");
    router.refresh();
  }

  async function reset() {
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/favicon", { method: "DELETE" });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setMessage(json.error || "Sıfırlanamadı.");
      return;
    }
    setPreview(json.favicon);
    setMessage("Varsayılan ikona dönüldü.");
    if (input.current) input.current.value = "";
    router.refresh();
  }

  return (
    <form
      className="panel-card form-grid"
      onSubmit={(event) => {
        event.preventDefault();
        const file = input.current?.files?.[0];
        if (file) void upload(file);
      }}
    >
      <p className="full muted">Tarayıcı sekmesinde ve telefon kısayolunda görünen küçük ikon.</p>
      <div className="full favicon-preview">
        <img src={preview} alt="Favicon önizleme" width={48} height={48} />
        <span className="muted">{preview.split("?")[0]}</span>
      </div>
      <label className="full">
        Yeni ikon
        <input
          ref={input}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/svg+xml,image/x-icon,.ico"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void upload(file);
          }}
        />
      </label>
      <div className="full row-actions">
        <button className="btn" type="submit" disabled={busy}>
          Kaydet
        </button>
        <button className="btn secondary" type="button" onClick={() => void reset()} disabled={busy}>
          Varsayılana dön
        </button>
        {message ? <span className="muted">{message}</span> : null}
      </div>
    </form>
  );
}
