import { isAdmin } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { isTrc20Address } from "@/lib/payments";
import { clampDays, cleanSameAs, normalizeThemeColor, publicSettings, saveSettings, sideFontSize, sideLabel } from "@/lib/settings";
import { vitrinOtherDefaults, vitrinOtherFont, type VitrinOtherFont } from "@/lib/vitrin-defaults";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const body = (await request.json().catch(() => null)) as {
    shuffleListings?: boolean;
    rotatePhotos?: boolean;
    vipArea?: boolean;
    expiryNotifyDays?: number;
    trc20Address?: string;
    themeColor?: string;
    textColor?: string;
    ilanVerColor?: string;
    ilanVerTextColor?: string;
    sideLeftText?: string;
    sideLeftColor?: string;
    sideRightText?: string;
    sideRightColor?: string;
    sideFontSize?: number;
    sameAs?: unknown;
    vitrinBg?: string;
    vitrinCard?: string;
    vitrinAccent?: string;
    vitrinHero?: string;
    vitrinText?: string;
    vitrinVip?: string;
    vitrinGold?: string;
    vitrinYeni?: string;
    vitrinTopTier?: string;
    vitrinLogoText?: string;
    vitrinLogoColor?: string;
    vitrinProfileBg?: string;
    vitrinProfileColor?: string;
    vitrinOtherTitleColor?: string;
    vitrinOtherTextColor?: string;
    vitrinOtherMutedColor?: string;
    vitrinOtherFont?: string;
    vitrinFont?: string;
    restoreOther?: boolean;
  } | null;
  if (!body) return NextResponse.json({ error: "Eksik." }, { status: 400 });
  const patch: {
    shuffleListings?: boolean;
    rotatePhotos?: boolean;
    vipArea?: boolean;
    expiryNotifyDays?: number;
    trc20Address?: string;
    themeColor?: string;
    textColor?: string;
    ilanVerColor?: string;
    ilanVerTextColor?: string;
    sideLeftText?: string;
    sideLeftColor?: string;
    sideRightText?: string;
    sideRightColor?: string;
    sideFontSize?: number;
    sameAs?: string[];
    vitrinBg?: string;
    vitrinCard?: string;
    vitrinAccent?: string;
    vitrinHero?: string;
    vitrinText?: string;
    vitrinVip?: string;
    vitrinGold?: string;
    vitrinYeni?: string;
    vitrinTopTier?: "vip" | "gold";
    vitrinLogoText?: string;
    vitrinLogoColor?: string;
    vitrinProfileBg?: string;
    vitrinProfileColor?: string;
    vitrinOtherTitleColor?: string;
    vitrinOtherTextColor?: string;
    vitrinOtherMutedColor?: string;
    vitrinOtherFont?: VitrinOtherFont;
    vitrinFont?: VitrinOtherFont;
  } = {};
  if (typeof body.shuffleListings === "boolean") patch.shuffleListings = body.shuffleListings;
  if (typeof body.rotatePhotos === "boolean") patch.rotatePhotos = body.rotatePhotos;
  if (typeof body.vipArea === "boolean") patch.vipArea = body.vipArea;
  if (body.expiryNotifyDays != null) patch.expiryNotifyDays = clampDays(body.expiryNotifyDays);
  if (typeof body.trc20Address === "string") {
    const address = body.trc20Address.trim();
    if (address && !isTrc20Address(address)) {
      return NextResponse.json({ error: "TRC20 adresi T ile başlayan 34 karakter olmalı." }, { status: 400 });
    }
    patch.trc20Address = address;
  }
  for (const key of ["themeColor", "textColor", "ilanVerColor", "ilanVerTextColor", "sideLeftColor", "sideRightColor", "vitrinBg", "vitrinCard", "vitrinAccent", "vitrinHero", "vitrinText", "vitrinVip", "vitrinGold", "vitrinYeni", "vitrinLogoColor", "vitrinProfileBg", "vitrinProfileColor", "vitrinOtherTitleColor", "vitrinOtherTextColor", "vitrinOtherMutedColor"] as const) {
    if (typeof body[key] !== "string") continue;
    const color = normalizeThemeColor(body[key]);
    if (!color) return NextResponse.json({ error: "Renk # ile başlayan 6 haneli olmalı." }, { status: 400 });
    patch[key] = color;
  }
  if (typeof body.sideLeftText === "string") patch.sideLeftText = sideLabel(body.sideLeftText, "");
  if (typeof body.sideRightText === "string") patch.sideRightText = sideLabel(body.sideRightText, "");
  if (body.sideFontSize != null) patch.sideFontSize = sideFontSize(body.sideFontSize);
  if (body.sameAs != null) patch.sameAs = cleanSameAs(body.sameAs);
  if (body.vitrinTopTier === "vip" || body.vitrinTopTier === "gold") patch.vitrinTopTier = body.vitrinTopTier;
  if (typeof body.vitrinLogoText === "string") patch.vitrinLogoText = sideLabel(body.vitrinLogoText, "Zirve Rehber");
  if (typeof body.vitrinOtherFont === "string") patch.vitrinOtherFont = vitrinOtherFont(body.vitrinOtherFont);
  if (typeof body.vitrinFont === "string") patch.vitrinFont = vitrinOtherFont(body.vitrinFont);
  if (body.restoreOther === true) {
    patch.vitrinOtherTitleColor = vitrinOtherDefaults.vitrinOtherTitleColor;
    patch.vitrinOtherTextColor = vitrinOtherDefaults.vitrinOtherTextColor;
    patch.vitrinOtherMutedColor = vitrinOtherDefaults.vitrinOtherMutedColor;
    patch.vitrinOtherFont = vitrinOtherDefaults.vitrinOtherFont;
  }
  saveSettings(patch);
  return NextResponse.json(publicSettings());
}
