import { redirect } from "next/navigation";

export default function OwnerDeliveryPage() {
  redirect("/hesap/");
}