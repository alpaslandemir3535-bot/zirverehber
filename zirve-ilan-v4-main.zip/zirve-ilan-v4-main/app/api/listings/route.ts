import { rejectCrossOrigin } from "@/lib/http";
import { parseListingInput } from "@/lib/listing-input";
import { currentActor } from "@/lib/session";
import { createListing, getAllListings, listingsForOwner } from "@/lib/store";
import { NextResponse } from "next/server";

export async function GET() {
  const actor = await currentActor();
  if (actor.role === "admin") return NextResponse.json(getAllListings());
  if (actor.role === "owner") return NextResponse.json(listingsForOwner(actor.owner.id));
  return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  const actor = await currentActor();
  if (actor.role === "owner") {
    return NextResponse.json({ error: "Yeni ilan açamazsın. Sana tanımlanan ilanı düzenle." }, { status: 403 });
  }
  if (!actor.role) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const parsed = parseListingInput((await request.json()) as Partial<import("@/lib/listing-types").ListingInput>);
  if (typeof parsed === "string") return NextResponse.json({ error: parsed }, { status: 400 });
  if (parsed.ownerId && listingsForOwner(parsed.ownerId).length) {
    return NextResponse.json({ error: "Bu ilan sahibinin zaten bir ilanı var." }, { status: 400 });
  }
  return NextResponse.json(createListing(parsed), { status: 201 });
}
