export const PAY_PLANS = {
  week: { label: "1 hafta", amountUsd: 400 },
  month: { label: "1 ay", amountUsd: 1600 },
} as const;

export type PayPlan = keyof typeof PAY_PLANS;

export function isPayPlan(value: unknown): value is PayPlan {
  return value === "week" || value === "month";
}

export type MoneyCurrency = "usd" | "tl";

export function isMoneyCurrency(value: unknown): value is MoneyCurrency {
  return value === "usd" || value === "tl";
}

export function formatUsd(amount: number) {
  return formatMoney(amount, "usd");
}

export function formatMoney(amount: number, currency: MoneyCurrency) {
  const value = amount.toLocaleString("tr-TR");
  return currency === "tl" ? `${value} ₺` : `${value} $`;
}
