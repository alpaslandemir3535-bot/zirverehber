import { randomUUID } from "crypto";
import path from "path";
import { readJsonFile, writeJsonFile } from "./json-file";
import { recordPaymentIncome } from "./ledger";
import { isListingEnded } from "./listing-types";
import { isPayPlan, PAY_PLANS, type PayPlan } from "./pay-plans";
import { listingById, renewListing } from "./store";
import { getSettings } from "./settings";
import { sendTelegramMessage } from "./telegram";
import { ownerById } from "./users";

export type PaymentStatus = "waiting" | "approved" | "rejected";

export type Payment = {
  id: string;
  listingId: string;
  ownerId: string;
  listingName: string;
  address: string;
  plan: PayPlan;
  amountUsd: number;
  note: string;
  status: PaymentStatus;
  createdAt: string;
  decidedAt: string | null;
};

const file = path.join(process.cwd(), "data", "payments.json");

export function isTrc20Address(value: string) {
  return /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(value.trim());
}

function normalizePayment(raw: Partial<Payment>): Payment | null {
  if (!raw.id || !raw.listingId || !raw.ownerId || !raw.createdAt) return null;
  const plan = isPayPlan(raw.plan) ? raw.plan : "month";
  const status = raw.status === "waiting" || raw.status === "approved" || raw.status === "rejected" ? raw.status : "waiting";
  return {
    id: raw.id,
    listingId: raw.listingId,
    ownerId: raw.ownerId,
    listingName: raw.listingName || "İlan",
    address: raw.address || "",
    plan,
    amountUsd: typeof raw.amountUsd === "number" ? raw.amountUsd : PAY_PLANS[plan].amountUsd,
    note: typeof raw.note === "string" ? raw.note : "",
    status,
    createdAt: raw.createdAt,
    decidedAt: raw.decidedAt ?? null,
  };
}

function readPayments(): Payment[] {
  const raw = readJsonFile<Partial<Payment>[]>(file, []);
  if (!Array.isArray(raw)) return [];
  return raw
    .map((item) => {
      try {
        return normalizePayment(item);
      } catch {
        return null;
      }
    })
    .filter((item): item is Payment => Boolean(item));
}

function writePayments(items: Payment[]) {
  writeJsonFile(file, items);
}

export function getPayments() {
  return readPayments().sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
}

export function waitingPayments() {
  return getPayments().filter((item) => item.status === "waiting");
}

export function latestPaymentForListing(listingId: string, ownerId?: string) {
  return (
    getPayments().find((item) => item.listingId === listingId && (!ownerId || item.ownerId === ownerId)) ?? null
  );
}

export async function claimPayment(ownerId: string, listingId: string, plan: unknown, noteText: unknown) {
  const listing = listingById(listingId);
  if (!listing || listing.ownerId !== ownerId) return { error: "İlan yok." as const };
  if (!isListingEnded(listing)) return { error: "Bu ilanın süresi dolmamış." as const };
  if (!isPayPlan(plan)) return { error: "1 hafta veya 1 ay seç." as const };
  const address = getSettings().trc20Address.trim();
  if (!isTrc20Address(address)) return { error: "Ödeme adresi henüz tanımlı değil." as const };
  const existing = readPayments().find((item) => item.listingId === listingId && item.status === "waiting");
  if (existing) return { payment: existing };
  const note = typeof noteText === "string" ? noteText.replace(/[\u0000-\u001F]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 300) : "";
  const payment: Payment = {
    id: randomUUID(),
    listingId,
    ownerId,
    listingName: listing.displayName,
    address,
    plan,
    amountUsd: PAY_PLANS[plan].amountUsd,
    note,
    status: "waiting",
    createdAt: new Date().toISOString(),
    decidedAt: null,
  };
  const items = readPayments();
  items.unshift(payment);
  writePayments(items);
  const planLabel = `${PAY_PLANS[plan].label} · ${PAY_PLANS[plan].amountUsd} $`;
  const sent = await sendTelegramMessage(
    `Ödeme bildirimi\n${listing.displayName}\n${planLabel}${payment.note ? `\nNot: ${payment.note}` : ""}\nBitcoin TRC20, onay bekliyor.\n${address}`,
    { stamp: false },
  );
  if (!sent.ok && sent.error !== "Bot token veya chat id yok.") {
    /* Bildirim gitmese de talep durur. */
  }
  return { payment };
}

export function decidePayment(id: string, action: "approve" | "reject") {
  const items = readPayments();
  const index = items.findIndex((item) => item.id === id);
  if (index < 0) return { error: "Kayıt yok." as const };
  const current = items[index];
  if (current.status !== "waiting") return { error: "Bu talep zaten kapanmış." as const };
  if (action === "approve") {
    const renewed = renewListing(current.listingId, current.plan);
    if (!renewed) return { error: "İlan bulunamadı." as const };
  }
  const decidedAt = new Date().toISOString();
  items[index] = {
    ...current,
    status: action === "approve" ? "approved" : "rejected",
    decidedAt,
  };
  writePayments(items);
  if (action === "approve") {
    const owner = ownerById(current.ownerId);
    recordPaymentIncome({
      id: current.id,
      listingName: current.listingName,
      ownerUsername: owner?.username || "Silinmiş hesap",
      plan: current.plan,
      amountUsd: current.amountUsd,
      note: current.note,
      at: decidedAt,
    });
  }
  return { payment: items[index] };
}
