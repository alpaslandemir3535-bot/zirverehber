"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function WaMessageSettings({ waListingMessage }: { waListingMessage: string }) {
  const router = useRouter();
  const [text, setText] = useState(waListingMessage);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const res = await fetch("/api/telegram/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ waListingMessage: text }),
    });
    const json = await res.json();
    setBusy(false);
    setMessage(res.ok ? "Kaydedildi." : json.error || "Kaydedilemedi.");
    if (res.ok) router.refresh();
  }

  return (
    <form className="panel-card form-grid" onSubmit={save}>
      <p className="full muted">
        İlan WhatsApp butonunda giden ilk metin. {"{ad}"} ilan adıdır (Eda, Buse). {"{sehir}"} ziyaretçinin girdiği ildir (İzmir, Ankara). Örnek: Merhaba, Eda İzmir Escort sayfanızdan yazıyorum.
      </p>
      <label className="full">
        İlan mesajı
        <textarea rows={3} value={text} onChange={(event) => setText(event.target.value)} required />
      </label>
      <div className="full row-actions">
        <button className="btn" type="submit" disabled={busy}>
          Kaydet
        </button>
        {message ? <span className="muted">{message}</span> : null}
      </div>
    </form>
  );
}
