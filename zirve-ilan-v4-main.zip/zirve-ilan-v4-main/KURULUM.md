# Hostinger kurulumu — Zirve İlan V3

Domain ve hosting Hostinger’da. Üç alan adı **tek** Node uygulamasına bakar:

| Alan adı | Görevi |
|----------|--------|
| `zirverehber.com` | Google’ın taradığı rehber. Ana site bu adrestir. |
| `zirvepano.xyz` | Ön alan. Rehberden tıklanınca ziyaretçi buraya gelir. |
| `zirveilan.xyz` | Açılan ilanlar. |

Uygulama gelen adresin adına bakıp sayfayı seçer. Üçünü ayrı site diye kurma.

Kod: özel depo [saydakgroup-max/zirve-ilan-v3](https://github.com/saydakgroup-max/zirve-ilan-v3), dal `main`.

Node.js Web App, **Business** veya **Cloud** hosting paketinde vardır. Pakette “Node.js web app / Web App” yoksa Hostinger panelinden bu özelliği olan pakete geç.

---

## 1. Domainleri Hostinger’a bağla

Domainler aynı Hostinger hesabındaysa nameserver zaten Hostinger’dır. Değilse her domainde:

1. [hpanel.hostinger.com](https://hpanel.hostinger.com) → **Domains**.
2. Domain → **DNS / Nameservers** → **Hostinger nameservers**.
3. Aynı işlemi `zirverehber.com`, `zirvepano.xyz` ve `zirveilan.xyz` için yap.

Yansıma bir saate kadar sürebilir. Bu bitmeden site açılmaz.

---

## 2. GitHub’ı Hostinger’a bağla

1. hPanel → **Websites** → **Add Website**.
2. **Node.js web app** seç.
3. Site adresi olarak **`zirverehber.com`** yaz. Geçici adresle kurma; ana domain bu olsun.
4. **Connect with GitHub**. Açılan pencerede Hostinger GitHub uygulamasını kur.
5. Depo listesinde **yalnız seçili depolar** dersen `zirve-ilan-v3` kutusunu işaretle. Depo özeldir; “tüm public depolar” yetmez.
6. Depo: `saydakgroup-max/zirve-ilan-v3`. Dal: **`main`**.

`zirverehber.com` hesapta boş bir WordPress veya PHP sitesi olarak duruyorsa Node.js onu yerinden değiştirmez. Yedeğini al, e-postayı silme kutusunu boş bırak, o siteyi kaldır, sonra aynı domaine Node.js sitesini ekle.

---

## 3. Derleme ayarları

Hostinger framework’ü Next.js sanıp açılış dosyasını yok sayar. Bu sitede açılış **`server.cjs`** olmalı. Ayarları şöyle düzelt:

| Alan | Değer |
|------|--------|
| Framework | **Other** |
| Root directory | `/` (boş da olabilir) |
| Branch | `main` |
| Node.js | **22** |
| Package manager | npm |
| Build command | `npm run build` |
| Output directory | boş bırak |
| Entry file | `server.cjs` |

**Environment variables** — localhost yazma, şifreleri kendin üret:

```
NODE_ENV=production
NEXT_PUBLIC_REHBER_ORIGIN=https://zirverehber.com
NEXT_PUBLIC_VITRIN_ORIGIN=https://zirvepano.xyz
NEXT_PUBLIC_ILAN_ORIGIN=https://zirveilan.xyz
ADMIN_PASSWORD=buraya-guclu-sifre
ADMIN_SECRET=buraya-uzun-rastgele
CRON_SECRET=buraya-baska-rastgele
```

`ADMIN_PASSWORD` panel şifrendir. Üç anahtar birbirinden farklı olsun. Telegram ve Search Console anahtarını buraya yazma; onları canlı panel → Ayarlar’a gir.

**Deploy** de. İlk derleme birkaç dakika sürer. Hata olursa Deployments → build log’daki ilk kırmızı satıra bak. Süre 15 dakikayı aşarsa aynı ayarlarla yeniden dene.

Bittikten sonra sitede **Running** görünür. https://zirverehber.com/ açılmalı.

---

## 4. .xyz alan adlarını bağla

`zirvepano.xyz` ve `zirveilan.xyz` için ikinci bir Node.js sitesi açma. İkisi de `zirverehber.com` sitesine park edilir. Böylece üç adres aynı `server.cjs` sürecine gelir; uygulama adrese göre pano veya ilan açar.

Her iki `.xyz` için aynı sırayı uygula.

### 4.1 Ayrı site olarak duruyorsa kaldır

hPanel → **Websites**. `zirvepano.xyz` veya `zirveilan.xyz` kendi sitesi olarak listede duruyorsa onu kaldır. E-posta varsa silme kutusunu işaretleme. Ana site `zirverehber.com` kalsın.

### 4.2 Nameserver

1. hPanel → **Domains** → ilgili `.xyz` → **DNS / Nameservers**.
2. Nameserver çifti Hostinger’ın bu site için gösterdiği çift olsun. Başka bir rehberden kopyalama; panelde yazan iki adresi kullan.
3. Domain Hostinger’da ve aynı hesaptaysa bu adım çoğu zaman hazırdır.

### 4.3 Park et

1. hPanel → **Websites** → `zirverehber.com` üzerine gel → **Manage**.
2. Solda **Parked domains**.
3. `zirvepano.xyz` yaz → **Park**.
4. Aynı yere `zirveilan.xyz` yaz → **Park**.

“Domain pointing değil” diye hata verirse önce 4.4’ü yap, sonra park etmeyi tekrar dene.

### 4.4 DNS kayıtları

Park ekranı IP isterse veya hata verirse:

1. `zirverehber.com` sitesinin panelinde hosting IP’sini kopyala. Sağ sütunda veya **Plan details** içinde yazar.
2. **Domains** → `.xyz` → **DNS / Nameservers** → **Add record**.

| Tip | Ad | Değer |
|-----|----|--------|
| A | `@` | Hosting IP’si |
| A | `www` | Aynı IP |

Eski A veya AAAA kaydı başka bir IP’ye bakıyorsa onu sil. `www` için CNAME varsa ve `@` hedefine gidiyorsa onu bırak, ikinci bir A ekleme.

CDN’yi henüz açma. CDN açıkken bu A kayıtları kendiliğinden değişir; elle geri yazma.

Kayıt yeşile dönene kadar bir saate kadar bekle. Parked domains listesinde `.xyz` satırı “pointing / Hostinger’a bakıyor” olmalı.

### 4.5 SSL

hPanel → **Security** → **SSL**. Üç adreste de sertifika görününce kilit simgesi gelir. `.xyz` satırı boşsa o domaini seçip sertifikayı kur. Birkaç dakika sürebilir.

### 4.6 Deneme

- https://zirvepano.xyz/ilanlar/ açılır, rehber sayfasının kopyası gibi durmaz.
- https://zirveilan.xyz/ ilan adresi olarak açılır.
- https://www.zirvepano.xyz/ ve https://www.zirveilan.xyz/ de aynı yere düşer.

Üçü de aynı karşılama sayfasını açıyorsa park tamamdır ama site hâlâ tek vitrin sanıyordur. Panel → Ayarlar’daki üç alan adının yukarıdaki tabloyla aynı olduğunu kontrol et.

---

## 5. CDN

CDN, Hostinger’ın kendi ağıdır. Cloudflare’ı aynı anda açma. İkisi birlikte DNS’i bozar.

Bunu `.xyz` adresleri açıldıktan sonra yap. Premium, Business veya Cloud paketinde vardır. VPS’te bu düğme yoktur.

1. hPanel → **Websites** → `zirverehber.com` → **Manage**.
2. Solda **Performance** → **CDN**.
3. Durum kapalıysa **Enable**.
4. Parked domains listesinde `.xyz` için ayrı CDN anahtarı varsa `zirvepano.xyz` ve `zirveilan.xyz` için de **Enable**.

Açılınca Hostinger, A ve AAAA kayıtlarını CDN adresine çevirir. Bunu elle düzeltme. Birkaç dakika, bazen bir saat sürer.

Sonra **Manage** ile şunları bırak:

- **Website optimization** → WebP açık kalabilir.
- **Security** → TLS 1.3 zorunlu yapma. Eski telefonlar düşer. 1.2 ve 1.3 birlikte kalsın.
- Ülke veya IP engeli ekleme.

Panel, ilan listesi veya az önce kaydettiğin ayar eski görünürse:

1. **Performance** → **CDN** → **Development mode** aç. Önbellek kalkar, değişikliği görürsün.
2. İşin bitince Development mode’u kapat.
3. Hâlâ eskiyse aynı ekrandan önbelleği temizle.

CDN’nin oturduğunu görmek için sayfayı gizli pencerede aç. Yavaşsa veya 5xx ise Development mode aç, site düzelince CDN’yi kapatıp yeniden Enable et.

---

## 6. İlk kontrol

- https://zirverehber.com/manisa-escort/
- https://zirvepano.xyz/ilanlar/
- https://zirveilan.xyz/ açılınca ilan adresi olarak davranır
- https://zirverehber.com/panel/ — `ADMIN_PASSWORD` ile gir

Panel → Ayarlar’da alan adları zaten şunlar olmalı: `zirverehber.com`, `zirvepano.xyz`, `zirveilan.xyz`. Tema kırmızı / beyaz yazı / siyah İLAN VER şeridi bu kayıttan gelir.

---

## 7. İlan, yükleme ve yedek

Canlıda eklenen ilan, fotoğraf, kullanıcı ve ödeme `data/` ile `public/uploads/` içine yazılır. GitHub’a her gönderiş Hostinger’da **yeni bir kopya** kurar. O kopyada bu dosyalar yoktur; bir önceki canlı veri silinmiş gibi görünebilir.

Her güncellemeden önce hPanel **File Manager** ile şunları bilgisayara indir:

- `domains/zirverehber.com/hbuilds/current/nodejs/data`
- `domains/zirverehber.com/hbuilds/current/nodejs/public/uploads`

Yeni sürüm **Running** olduktan sonra bu klasörleri yeni kopyanın aynı yerine geri yükle ve uygulamayı **Restart** et.

Panelden değiştirdiğin tema ve alan adı da `data/settings.json` ile `data/domains.json` içindedir. Onları da bu yedekle birlikte geri koy. Yoksa canlıdaki son ayar, depodaki ayarın üstüne yazar.

---

## 8. Zamanlanmış iş

hPanel → **Advanced** → **Cron Jobs**. Saat başı:

```
curl -sL "https://zirverehber.com/api/cron/telegram/?secret=CRON_SECRET"
```

`CRON_SECRET`, 3. adımdaki değerin aynısı olsun. Bu adres süre uyarısını ve Telegram özetini çalıştırır. Panelde Telegram kutusunu işaretlemeden özet gitmez.

---

## 9. Güncelleme

Bilgisayarda kodu değiştir, GitHub’daki `zirve-ilan-v3` deposunun `main` dalına gönder. Hostinger yeni gönderişi görünce kendisi derler.

Gönderiden önce 7. adımdaki yedeği al. Derleme bitince yedeği geri yükle ve **Restart** et. Yeni kod görünmüyorsa CDN’de Development mode aç veya önbelleği temizle.

Elle yeniden kurmak için: site → **Deployments** → **Redeploy**.

---

## Takılırsa

| Belirti | Ne bak |
|---------|--------|
| Depo listede yok | GitHub uygulamasına `zirve-ilan-v3` özel deposu seçili mi |
| Site PHP / Hostinger karşılama sayfası | Framework **Other**, entry `server.cjs`, durum Running |
| `.xyz` park olmuyor | Önce A kaydı hosting IP’sine baksın, sonra tekrar Park |
| Üç adres aynı sayfayı açıyor | Parked domain ekli mi; paneldeki üç alan adı doğru mu |
| Panel şifresi olmuyor | `ADMIN_PASSWORD` env’de mi, sonra Restart |
| Build failed | Deployments log’undaki ilk hata. Node 22 ve `npm run build` kalsın |
| Güncellemeden sonra ilanlar kayboldu | 7. adımdaki `data` ve `uploads` yedeğini yeni kopyaya geri koy |
| Kilit simgesi yok | DNS Hostinger’a bakıyor mu; SSL ekranında sertifika var mı |
| Eski sayfa veya CDN 5xx | Performance → CDN → Development mode veya önbelleği temizle. Cloudflare açıksa kapat |
