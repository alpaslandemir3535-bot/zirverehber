import { ADMIN_COOKIE, OWNER_COOKIE } from "@/lib/auth";
import { rejectCrossOrigin } from "@/lib/http";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  const back = request.headers.get("referer")?.includes("/hesap") ? "/hesap/login/" : "/panel/login/";
  const response = NextResponse.redirect(new URL(back, request.url));
  response.cookies.set(ADMIN_COOKIE, "", { path: "/", maxAge: 0 });
  response.cookies.set(OWNER_COOKIE, "", { path: "/", maxAge: 0 });
  return response;
}
