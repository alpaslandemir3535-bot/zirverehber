import { isAdmin } from "@/lib/auth";
import { createComplaint, getComplaints } from "@/lib/complaints";
import { rejectCrossOrigin } from "@/lib/http";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { NextResponse } from "next/server";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  return NextResponse.json(getComplaints());
}

export async function POST(request: Request) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!rateLimit(`complaint:${clientIp(request)}`, 5, 15 * 60 * 1000)) {
    return NextResponse.json({ error: "Çok fazla istek." }, { status: 429 });
  }
  const body = (await request.json().catch(() => null)) as {
    name?: string;
    phone?: string;
    message?: string;
    listingId?: string;
  } | null;
  const result = createComplaint({
    name: body?.name || "",
    phone: body?.phone || "",
    message: body?.message || "",
    listingId: body?.listingId,
  });
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ ok: true }, { status: 201 });
}
