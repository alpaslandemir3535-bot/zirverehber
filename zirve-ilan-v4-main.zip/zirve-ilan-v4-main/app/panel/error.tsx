"use client";

export default function PanelError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="login-screen">
      <div className="login-card">
        <p className="eyebrow">Zirve</p>
        <h1>Panel geçici olarak açılamadı</h1>
        <p className="muted">Sayfa yüklenirken bir hata oluştu. Verilerin silinmedi.</p>
        {error.digest ? <p className="muted">Hata kodu: {error.digest}</p> : null}
        <div className="form-grid one-col">
          <button className="btn" type="button" onClick={() => reset()}>
            Tekrar dene
          </button>
          <a className="btn" href="/panel/login/">
            Girişe dön
          </a>
        </div>
      </div>
    </div>
  );
}
