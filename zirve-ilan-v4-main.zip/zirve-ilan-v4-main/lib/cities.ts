import { toSlug } from "./to-slug";

export type City = {
  name: string;
  slug: string;
  plate: number;
  region: string;
  blurb: string;
};

const RAW: Array<Omit<City, "slug">> = [
  { name: "Adana", plate: 1, region: "Akdeniz", blurb: "Seyhan ve Çukurova hattında gece hayatı merkeze yakındır. Adana rehberi, ilanları semt ve iletişim bilgisiyle listeler." },
  { name: "Adıyaman", plate: 2, region: "Güneydoğu Anadolu", blurb: "Kahta ve merkez arasında kısa mesafeler vardır. Adıyaman sayfası güncel ilanları tek listede toplar." },
  { name: "Afyonkarahisar", plate: 3, region: "Ege", blurb: "Termal oteller ve merkez çarşı aynı güzergahtadır. Afyon rehberi ilanları sade başlıklarla açar." },
  { name: "Ağrı", plate: 4, region: "Doğu Anadolu", blurb: "Doğubayazıt–merkez yolu kışın yavaşlar. Ağrı ilanları konum ve telefonla yayınlanır." },
  { name: "Amasya", plate: 5, region: "Karadeniz", blurb: "Yeşilırmak kıyısı ve şehzadeler mahallesi yürünebilir mesafededir. Amasya rehberi kısa ve net tutulur." },
  { name: "Ankara", plate: 6, region: "İç Anadolu", blurb: "Çankaya, Kızılay ve Çayyolu ayrı tempolardadır. Ankara sayfasında ilanlar ilçe etiketleriyle ayrılır." },
  { name: "Antalya", plate: 7, region: "Akdeniz", blurb: "Lara, Konyaaltı ve Kaleiçi turizm sezonunda yoğunlaşır. Antalya rehberi ilanları güncel tutar." },
  { name: "Artvin", plate: 8, region: "Karadeniz", blurb: "Hopa ve merkez arasında vadi yolu vardır. Artvin ilanları az ama düzenli yayınlanır." },
  { name: "Aydın", plate: 9, region: "Ege", blurb: "Kuşadası, Didim ve merkez yazın ayrı hareketlenir. Aydın rehberi ilçe bazlı bakış sunar." },
  { name: "Balıkesir", plate: 10, region: "Marmara", blurb: "Altıeylül, Karesi ve Edremit hattı geniştir. Balıkesir ilanları tek ızgarada toplanır." },
  { name: "Bilecik", plate: 11, region: "Marmara", blurb: "Bozüyük ile merkez kısa otoyol mesafesindedir. Bilecik sayfası sade tutulan bir rehberdir." },
  { name: "Bingöl", plate: 12, region: "Doğu Anadolu", blurb: "Merkez yerleşimi derli ve yakındır. Bingöl ilanları telefon ve konumla listelenir." },
  { name: "Bitlis", plate: 13, region: "Doğu Anadolu", blurb: "Tatvan sahili ile merkez ayrı durur. Bitlis rehberi güncel kayıtları gösterir." },
  { name: "Bolu", plate: 14, region: "Karadeniz", blurb: "Abant yolu ve şehir otelleri aynı günde gezilir. Bolu ilanları kısa açıklamayla açılır." },
  { name: "Burdur", plate: 15, region: "Akdeniz", blurb: "Göl manzaralı merkez sakin bir ritimdedir. Burdur sayfası ilanları tek kolonda özetler." },
  { name: "Bursa", plate: 16, region: "Marmara", blurb: "Nilüfer, Osmangazi ve Yıldırım ayrı duraklardır. Bursa rehberi ilanları ilçeye göre sıralar." },
  { name: "Çanakkale", plate: 17, region: "Marmara", blurb: "Kepez ve merkez feribot saatlerine göre hareketlenir. Çanakkale ilanları güncel tutulur." },
  { name: "Çankırı", plate: 18, region: "İç Anadolu", blurb: "Şehir merkezi kompakt ve yürünebilirdir. Çankırı rehberi az sayıda net ilan barındırır." },
  { name: "Çorum", plate: 19, region: "Karadeniz", blurb: "Hitit caddesi ve yeni yerleşim yan yanadır. Çorum sayfası ilanları sade başlıklarla verir." },
  { name: "Denizli", plate: 20, region: "Ege", blurb: "Pamukkale hattı ile merkez çarşı ayrı tempolardadır. Denizli rehberi ilanları güncel listeler." },
  { name: "Diyarbakır", plate: 21, region: "Güneydoğu Anadolu", blurb: "Sur, Kayapınar ve Bağlar farklı ritimlerdedir. Diyarbakır ilanları ilçe notuyla yayınlanır." },
  { name: "Edirne", plate: 22, region: "Marmara", blurb: "Selimiye çevresi ve kapı hattı yürünebilir. Edirne rehberi kısa ve açık tutulur." },
  { name: "Elazığ", plate: 23, region: "Doğu Anadolu", blurb: "Merkez ve üniversite semti yakın mesafededir. Elazığ ilanları telefonla doğrulanır." },
  { name: "Erzincan", plate: 24, region: "Doğu Anadolu", blurb: "Düz ovada merkez yerleşimi açıktır. Erzincan sayfası ilanları tek listede tutar." },
  { name: "Erzurum", plate: 25, region: "Doğu Anadolu", blurb: "Palandöken ve merkez kışın ayrı yoğunlaşır. Erzurum rehberi ilanları güncel verir." },
  { name: "Eskişehir", plate: 26, region: "İç Anadolu", blurb: "Porsuk kıyısı ve Tepebaşı geceye yakındır. Eskişehir ilanları semt etiketli yayınlanır." },
  { name: "Gaziantep", plate: 27, region: "Güneydoğu Anadolu", blurb: "Şahinbey ve Şehitkamil geniş bir alana yayılır. Gaziantep rehberi ilanları düzenli yeniler." },
  { name: "Giresun", plate: 28, region: "Karadeniz", blurb: "Sahil şeridi ve tepe mahalleler iç içedir. Giresun sayfası kısa ilan özetleri sunar." },
  { name: "Gümüşhane", plate: 29, region: "Karadeniz", blurb: "Merkez vadi içinde derli bir yerleşimdir. Gümüşhane rehberi sade tutulur." },
  { name: "Hakkari", plate: 30, region: "Doğu Anadolu", blurb: "Yüksek rakımda mesafe ve hava belirleyicidir. Hakkari ilanları az ve net listelenir." },
  { name: "Hatay", plate: 31, region: "Akdeniz", blurb: "Antakya, İskenderun ve Defne ayrı duraklardır. Hatay rehberi ilçe ilçe bakış verir." },
  { name: "Isparta", plate: 32, region: "Akdeniz", blurb: "Gül bahçeleri ve üniversite çevresi sakin ritimdedir. Isparta ilanları kısa tutulur." },
  { name: "Mersin", plate: 33, region: "Akdeniz", blurb: "Yenişehir, Mezitli ve Pozcu sahile yakındır. Mersin rehberi ilanları güncel ızgarada açar." },
  { name: "İstanbul", plate: 34, region: "Marmara", blurb: "Anadolu ve Avrupa yakası ayrı plan ister. İstanbul sayfası ilanları semt notuyla gösterir." },
  { name: "İzmir", plate: 35, region: "Ege", blurb: "Alsancak, Karşıyaka ve Bornova farklı tempolardadır. İzmir rehberi ilanları ilçeye göre dizer." },
  { name: "Kars", plate: 36, region: "Doğu Anadolu", blurb: "Kale çevresi ve yeni yerleşim yakındır. Kars ilanları sade başlıklarla yayınlanır." },
  { name: "Kastamonu", plate: 37, region: "Karadeniz", blurb: "Çarşı ve evliyalar semti yürünebilir mesafededir. Kastamonu rehberi kısa tutulur." },
  { name: "Kayseri", plate: 38, region: "İç Anadolu", blurb: "Melikgazi ve Kocasinan geniş bir düzlüğe yayılır. Kayseri ilanları güncel listelenir." },
  { name: "Kırklareli", plate: 39, region: "Marmara", blurb: "Lüleburgaz ve merkez arasında kısa yol vardır. Kırklareli sayfası net ilan verir." },
  { name: "Kırşehir", plate: 40, region: "İç Anadolu", blurb: "Merkez yerleşimi kompakt ve sakin ritimdedir. Kırşehir rehberi az ilanı düzenli tutar." },
  { name: "Kocaeli", plate: 41, region: "Marmara", blurb: "İzmit, Gebze ve Körfez ayrı iş saatlerindedir. Kocaeli rehberi ilanları ilçe etiketler." },
  { name: "Konya", plate: 42, region: "İç Anadolu", blurb: "Selçuklu, Meram ve Karatay geniş mesafededir. Konya sayfası ilanları semte göre ayırır." },
  { name: "Kütahya", plate: 43, region: "Ege", blurb: "Çini çarşısı ve yeni mahalleler yan yanadır. Kütahya rehberi sade ilan listesi sunar." },
  { name: "Malatya", plate: 44, region: "Doğu Anadolu", blurb: "Battalgazi ve Yeşilyurt yakın mesafededir. Malatya ilanları telefonla yayınlanır." },
  { name: "Manisa", plate: 45, region: "Ege", blurb: "Yunusemre, Şehzadeler ve Turgutlu ayrı duraklardır. Manisa rehberi ilanları güncel ızgarada gösterir." },
  { name: "Kahramanmaraş", plate: 46, region: "Akdeniz", blurb: "Onikişubat ve Dulkadiroğlu merkez hattını paylaşır. Kahramanmaraş sayfası ilanları düzenler." },
  { name: "Mardin", plate: 47, region: "Güneydoğu Anadolu", blurb: "Artuklu taş evleri ve Kızıltepe ovası ayrı tempolardadır. Mardin rehberi kısa tutulur." },
  { name: "Muğla", plate: 48, region: "Ege", blurb: "Bodrum, Marmaris ve Fethiye sezonluk yoğunlaşır. Muğla ilanları ilçe notuyla açılır." },
  { name: "Muş", plate: 49, region: "Doğu Anadolu", blurb: "Ova yerleşimi açık ve mesafeler kısadır. Muş sayfası ilanları tek listede verir." },
  { name: "Nevşehir", plate: 50, region: "İç Anadolu", blurb: "Peribacaları hattı gece erken kapanır. Nevşehir rehberi sakin bir ritimle yayınlanır." },
  { name: "Niğde", plate: 51, region: "İç Anadolu", blurb: "Merkez ve üniversite çevresi yakındır. Niğde ilanları kısa açıklamayla listelenir." },
  { name: "Ordu", plate: 52, region: "Karadeniz", blurb: "Altınordu sahili ve boztepe aynı günde gezilir. Ordu rehberi ilanları güncel tutar." },
  { name: "Rize", plate: 53, region: "Karadeniz", blurb: "Sahil yolu dar ve yağmura göre yavaşlar. Rize sayfası ilanları sade gösterir." },
  { name: "Sakarya", plate: 54, region: "Marmara", blurb: "Adapazarı ve Serdivan yan yana durur. Sakarya rehberi ilanları semt notuyla verir." },
  { name: "Samsun", plate: 55, region: "Karadeniz", blurb: "Atakum, İlkadım ve Canik sahil boyunca dizilir. Samsun ilanları ilçe etiketli yayınlanır." },
  { name: "Siirt", plate: 56, region: "Güneydoğu Anadolu", blurb: "Merkez çarşı derli ve yakındır. Siirt rehberi az sayıda net ilan barındırır." },
  { name: "Sinop", plate: 57, region: "Karadeniz", blurb: "Yarımada içinde her yer yürünebilir mesafededir. Sinop sayfası kısa tutulur." },
  { name: "Sivas", plate: 58, region: "İç Anadolu", blurb: "Merkez ve üniversite kampüsü ayrı duraklardır. Sivas rehberi ilanları düzenli listeler." },
  { name: "Tekirdağ", plate: 59, region: "Marmara", blurb: "Süleymanpaşa ve Çorlu ayrı tempolardadır. Tekirdağ ilanları ilçe notuyla açılır." },
  { name: "Tokat", plate: 60, region: "Karadeniz", blurb: "Tarihi çarşı ve yeni yerleşim yakındır. Tokat sayfası sade ilan özeti sunar." },
  { name: "Trabzon", plate: 61, region: "Karadeniz", blurb: "Ortahisar ve Yomra sahil şeridinde dizilir. Trabzon rehberi ilanları güncel ızgarada gösterir." },
  { name: "Tunceli", plate: 62, region: "Doğu Anadolu", blurb: "Merkez vadi içinde küçük ve sakin ritimdedir. Tunceli ilanları az ve net tutulur." },
  { name: "Şanlıurfa", plate: 63, region: "Güneydoğu Anadolu", blurb: "Eyyübiye ve Haliliye gece ayrı hareketlenir. Şanlıurfa rehberi ilanları semte göre ayırır." },
  { name: "Uşak", plate: 64, region: "Ege", blurb: "Merkez çarşı ve organize bölge kısa mesafededir. Uşak sayfası ilanları sade listeler." },
  { name: "Van", plate: 65, region: "Doğu Anadolu", blurb: "İpekyolu ve Edremit göl hattına yakındır. Van rehberi ilanları güncel tutar." },
  { name: "Yozgat", plate: 66, region: "İç Anadolu", blurb: "Merkez yerleşimi açık ve durgundur. Yozgat ilanları kısa başlıklarla yayınlanır." },
  { name: "Zonguldak", plate: 67, region: "Karadeniz", blurb: "Kozlu ve merkez sahil yolunda sıkışır. Zonguldak rehberi ilanları net verir." },
  { name: "Aksaray", plate: 68, region: "İç Anadolu", blurb: "Ihlara hattı ile merkez ayrı duraklardır. Aksaray sayfası sade bir rehberdir." },
  { name: "Bayburt", plate: 69, region: "Karadeniz", blurb: "Şehir küçük ve her yer yakındır. Bayburt ilanları az sayıda tutulur." },
  { name: "Karaman", plate: 70, region: "İç Anadolu", blurb: "Merkez ve üniversite semti kısa mesafededir. Karaman rehberi ilanları düzenler." },
  { name: "Kırıkkale", plate: 71, region: "İç Anadolu", blurb: "Ankara yoluna yakın kompakt bir yerleşimdir. Kırıkkale sayfası kısa ilan listesi sunar." },
  { name: "Batman", plate: 72, region: "Güneydoğu Anadolu", blurb: "Merkez düz ovada açık ve geniştir. Batman rehberi ilanları güncel gösterir." },
  { name: "Şırnak", plate: 73, region: "Güneydoğu Anadolu", blurb: "Cizre ve merkez ayrı güzergahlardadır. Şırnak ilanları net ve sade tutulur." },
  { name: "Bartın", plate: 74, region: "Karadeniz", blurb: "Amasra ve merkez sahil boyunca yakındır. Bartın rehberi kısa yayınlanır." },
  { name: "Ardahan", plate: 75, region: "Doğu Anadolu", blurb: "Yüksek ovada mesafe ve hava belirleyicidir. Ardahan sayfası az ilanı listeler." },
  { name: "Iğdır", plate: 76, region: "Doğu Anadolu", blurb: "Düz ovada merkez yerleşimi açıktır. Iğdır rehberi ilanları telefonla verir." },
  { name: "Yalova", plate: 77, region: "Marmara", blurb: "Sahil şeridi ve termal oteller yakındır. Yalova ilanları sade ızgarada açılır." },
  { name: "Karabük", plate: 78, region: "Karadeniz", blurb: "Safranbolu ve merkez ayrı duraklardır. Karabük rehberi ilanları ilçe notuyla tutar." },
  { name: "Kilis", plate: 79, region: "Güneydoğu Anadolu", blurb: "Sınır kenti küçük ve yürünebilirdir. Kilis sayfası kısa ilan özeti sunar." },
  { name: "Osmaniye", plate: 80, region: "Akdeniz", blurb: "Merkez ve Kadirli kısa mesafededir. Osmaniye rehberi ilanları düzenli listeler." },
  { name: "Düzce", plate: 81, region: "Karadeniz", blurb: "Konuralp ve merkez otoyola yakındır. Düzce ilanları sade başlıklarla yayınlanır." },
];

export const cities: City[] = RAW.map((city) => ({
  ...city,
  slug: toSlug(city.name),
}));

export function cityBySlug(slug: string) {
  return cities.find((city) => city.slug === slug);
}

export function cityByEscortSlug(param: string) {
  const slug = param.replace(/-escort$/, "");
  return cityBySlug(slug);
}

export function resolveCitySlug(hint?: string | null) {
  if (!hint) return null;
  const value = hint.trim();
  if (!value) return null;
  const fromEscort = cityByEscortSlug(value);
  if (fromEscort) return fromEscort.slug;
  const fromSlug = cityBySlug(value);
  if (fromSlug) return fromSlug.slug;
  const lower = value.toLocaleLowerCase("tr-TR");
  return cities.find((city) => city.name.toLocaleLowerCase("tr-TR") === lower)?.slug
    || cityBySlug(toSlug(value))?.slug
    || null;
}

export function cityEscortSlug(city: City) {
  return `${city.slug}-escort`;
}
