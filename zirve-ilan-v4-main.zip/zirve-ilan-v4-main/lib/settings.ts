import path from "path";
import { getDomains } from "./domains";
import { readJsonFile, writeJsonFile } from "./json-file";
import { toPhoneDigits, waListingMessageText } from "./listing-types";
import { cleanBgImage, vitrinOtherDefaults, vitrinOtherFont, type VitrinOtherFont } from "./vitrin-defaults";

export type AppSettings = {
  telegramBotToken: string;
  telegramChatId: string;
  telegramDaily: boolean;
  lastTelegramAt: string | null;
  lastTelegramCronAt: string | null;
  lastTelegramPart: 1 | 2;
  ilanVerPhone: string;
  waListingMessage: string;
  gscSiteUrl: string;
  gscClientEmail: string;
  gscPrivateKey: string;
  gscVerifyMeta: string;
  favicon: string;
  shuffleListings: boolean;
  rotatePhotos: boolean;
  vipArea: boolean;
  expiryNotifyDays: number;
  lastBackupAt: string | null;
  lastExpiryNotifyAt: string | null;
  trc20Address: string;
  marketTrc20Address: string;
  themeColor: string;
  textColor: string;
  ilanVerColor: string;
  ilanVerTextColor: string;
  ilanVerNoteTitle: string;
  ilanVerNoteBody: string;
  ilanVerNoteColor: string;
  ilanVerNoteBodyColor: string;
  ilanVerNoteBg: string;
  sideLeftText: string;
  sideLeftColor: string;
  sideRightText: string;
  sideRightColor: string;
  sideFontSize: number;
  rehberDescription: string;
  sameAs: string[];
  gaMeasurementId: string;
  vitrinBg: string;
  vitrinCard: string;
  vitrinAccent: string;
  vitrinHero: string;
  vitrinText: string;
  vitrinVip: string;
  vitrinGold: string;
  vitrinYeni: string;
  vitrinTopTier: "vip" | "gold";
  vitrinIlanTitle: string;
  vitrinIlanTitleColor: string;
  vitrinIlanTitleSize: number;
  vitrinIlanNote: string;
  vitrinIlanNoteColor: string;
  vitrinIlanNoteSize: number;
  vitrinLogoText: string;
  vitrinLogoColor: string;
  vitrinBgImage: string;
  vitrinOtherTitleColor: string;
  vitrinOtherTextColor: string;
  vitrinOtherMutedColor: string;
  vitrinOtherFont: VitrinOtherFont;
  vitrinFont: VitrinOtherFont;
  vitrinProfileBg: string;
  vitrinProfileColor: string;
};

const file = path.join(process.cwd(), "data", "settings.json");

const empty: AppSettings = {
  telegramBotToken: "",
  telegramChatId: "",
  telegramDaily: false,
  lastTelegramAt: null,
  lastTelegramCronAt: null,
  lastTelegramPart: 1,
  ilanVerPhone: "",
  waListingMessage: "Merhaba, {ad} {sehir} Escort sayfanızdan yazıyorum.",
  gscSiteUrl: "",
  gscClientEmail: "",
  gscPrivateKey: "",
  gscVerifyMeta: "",
  favicon: "",
  shuffleListings: true,
  rotatePhotos: true,
  vipArea: false,
  expiryNotifyDays: 2,
  lastBackupAt: null,
  lastExpiryNotifyAt: null,
  trc20Address: "",
  marketTrc20Address: "",
  themeColor: "#ff1a1a",
  textColor: "#ffffff",
  ilanVerColor: "#000000",
  ilanVerTextColor: "#ffffff",
  ilanVerNoteTitle: "⚠ Bayan için yazmayın!",
  ilanVerNoteBody: "Bu hat yalnızca ilan verme & şikayet-öneri içindir!",
  ilanVerNoteColor: "#e879f9",
  ilanVerNoteBodyColor: "#d8b4fe",
  ilanVerNoteBg: "#12081c",
  sideLeftText: "ELDEN ÖDEME",
  sideLeftColor: "#ffffff",
  sideRightText: "GERÇEK BAYANLAR",
  sideRightColor: "#ffffff",
  sideFontSize: 20,
  rehberDescription: "Zirve Rehber’de 81 ilin güncel escort ilanları durur. Şehrini seçip ilanı aç, yazışmayı numaradan kur. Buluşma ve ödeme elden yapılır.",
  sameAs: [],
  gaMeasurementId: "",
  vitrinBg: "#140910",
  vitrinCard: "#1c1018",
  vitrinAccent: "#e0b15a",
  vitrinHero: "#6b1d4a",
  vitrinText: "#f7f1ea",
  vitrinVip: "#1a140c",
  vitrinGold: "#e0b15a",
  vitrinYeni: "#f5c518",
  vitrinTopTier: "vip",
  vitrinIlanTitle: "İLAN VER",
  vitrinIlanTitleColor: "#e0b15a",
  vitrinIlanTitleSize: 22,
  vitrinIlanNote: "Bayan İçin Yazmayın Sadece İlan Vermek İçin Yazın",
  vitrinIlanNoteColor: "#f7f1ea",
  vitrinIlanNoteSize: 11,
  vitrinLogoText: "Zirve Rehber",
  vitrinLogoColor: "#e0b15a",
  vitrinBgImage: "",
  vitrinOtherTitleColor: vitrinOtherDefaults.vitrinOtherTitleColor,
  vitrinOtherTextColor: vitrinOtherDefaults.vitrinOtherTextColor,
  vitrinOtherMutedColor: vitrinOtherDefaults.vitrinOtherMutedColor,
  vitrinOtherFont: vitrinOtherDefaults.vitrinOtherFont,
  vitrinFont: "playfair",
  vitrinProfileBg: "#0d3b2e",
  vitrinProfileColor: "#e6c36a",
};

export function getSettings(): AppSettings {
  const parsed = readJsonFile<Record<string, unknown> | null>(file, null);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return { ...empty };
  const raw = parsed;
  const { themeRed: _red, themeBlack: _black, themeWhite: _white, ...rest } = { ...empty, ...raw } as AppSettings & {
    themeRed?: string;
    themeBlack?: string;
    themeWhite?: string;
  };
  return {
    ...rest,
    ...themeColors(raw),
    ...noteFields(raw),
    ...sideLabels(raw),
    ...vitrinFields(raw),
    waListingMessage: waListingMessageText(rest.waListingMessage),
    rehberDescription: rehberDescriptionText(rest.rehberDescription),
    sameAs: cleanSameAs(rest.sameAs),
    gaMeasurementId: gaMeasurementId(rest.gaMeasurementId),
  };
}

// GA4 ölçüm kimliği. Sayfa kaynağına yazıldığı için yalnız G- biçimi kabul edilir.
export function gaMeasurementId(value: unknown) {
  const text = typeof value === "string" ? value.trim().toUpperCase() : "";
  return /^G-[A-Z0-9]{4,16}$/.test(text) ? text : "";
}

// Markanın başka sitelerdeki resmi profilleri (sosyal hesap, harita kaydı vb.). Yalnızca https.
export function cleanSameAs(value: unknown): string[] {
  const list = Array.isArray(value) ? value : typeof value === "string" ? value.split(/[\r\n,]+/) : [];
  const seen = new Set<string>();
  const urls: string[] = [];
  for (const item of list) {
    if (typeof item !== "string") continue;
    try {
      const url = new URL(item.trim());
      if (url.protocol !== "https:") continue;
      const text = url.toString();
      if (seen.has(text)) continue;
      seen.add(text);
      urls.push(text);
    } catch {
      /* geçersiz adres atlanır */
    }
    if (urls.length >= 10) break;
  }
  return urls;
}

export function vipBoardOpen() {
  const raw = readJsonFile<{ vipArea?: unknown } | null>(file, null);
  if (!raw || typeof raw !== "object") return false;
  return raw.vipArea !== false;
}

export function saveSettings(patch: Partial<AppSettings>) {
  const next = { ...getSettings(), ...patch };
  writeJsonFile(file, next);
  return next;
}

export function publicSettings() {
  const settings = getSettings();
  const token = settings.telegramBotToken || process.env.TELEGRAM_BOT_TOKEN || "";
  const chatId = settings.telegramChatId || process.env.TELEGRAM_CHAT_ID || "";
  return {
    telegramChatId: settings.telegramChatId || process.env.TELEGRAM_CHAT_ID || "",
    telegramDaily: settings.telegramDaily,
    lastTelegramAt: settings.lastTelegramAt,
    lastTelegramPart: settings.lastTelegramPart || 1,
    telegramReady: Boolean(token && chatId),
    telegramBotTokenMasked: token ? `${token.slice(0, 6)}••••` : "",
    ilanVerPhone: settings.ilanVerPhone,
    waListingMessage: settings.waListingMessage || empty.waListingMessage,
    gscSiteUrl: settings.gscSiteUrl || process.env.GSC_SITE_URL || "",
    gscClientEmail: settings.gscClientEmail || process.env.GSC_CLIENT_EMAIL || "",
    gscVerifyMeta: settings.gscVerifyMeta,
    gscReady: Boolean(
      (settings.gscSiteUrl || process.env.GSC_SITE_URL) &&
        (settings.gscClientEmail || process.env.GSC_CLIENT_EMAIL) &&
        (settings.gscPrivateKey || process.env.GSC_PRIVATE_KEY),
    ),
    gscPrivateKeyMasked: (settings.gscPrivateKey || process.env.GSC_PRIVATE_KEY || "").includes("BEGIN")
      ? "Anahtar kayıtlı"
      : "",
    favicon: settings.favicon || "/favicon.png",
    shuffleListings: settings.shuffleListings !== false,
    rotatePhotos: settings.rotatePhotos !== false,
    vipArea: settings.vipArea === true,
    expiryNotifyDays: clampDays(settings.expiryNotifyDays),
    lastBackupAt: settings.lastBackupAt,
    lastExpiryNotifyAt: settings.lastExpiryNotifyAt,
    trc20Address: settings.trc20Address || "",
    marketTrc20Address: settings.marketTrc20Address || "",
    themeColor: settings.themeColor,
    textColor: settings.textColor,
    ilanVerColor: settings.ilanVerColor,
    ilanVerTextColor: settings.ilanVerTextColor,
    ilanVerNoteTitle: settings.ilanVerNoteTitle,
    ilanVerNoteBody: settings.ilanVerNoteBody,
    ilanVerNoteColor: settings.ilanVerNoteColor,
    ilanVerNoteBodyColor: settings.ilanVerNoteBodyColor,
    ilanVerNoteBg: settings.ilanVerNoteBg,
    sideLeftText: settings.sideLeftText,
    sideLeftColor: settings.sideLeftColor,
    sideRightText: settings.sideRightText,
    sideRightColor: settings.sideRightColor,
    sideFontSize: settings.sideFontSize,
    rehberDescription: settings.rehberDescription,
    sameAs: settings.sameAs,
    gaMeasurementId: settings.gaMeasurementId || gaMeasurementId(process.env.GA_MEASUREMENT_ID),
    vitrinBg: settings.vitrinBg,
    vitrinCard: settings.vitrinCard,
    vitrinAccent: settings.vitrinAccent,
    vitrinHero: settings.vitrinHero,
    vitrinText: settings.vitrinText,
    vitrinVip: settings.vitrinVip,
    vitrinGold: settings.vitrinGold,
    vitrinYeni: settings.vitrinYeni,
    vitrinTopTier: settings.vitrinTopTier,
    vitrinIlanTitle: settings.vitrinIlanTitle,
    vitrinIlanTitleColor: settings.vitrinIlanTitleColor,
    vitrinIlanTitleSize: settings.vitrinIlanTitleSize,
    vitrinIlanNote: settings.vitrinIlanNote,
    vitrinIlanNoteColor: settings.vitrinIlanNoteColor,
    vitrinIlanNoteSize: settings.vitrinIlanNoteSize,
    vitrinLogoText: settings.vitrinLogoText,
    vitrinLogoColor: settings.vitrinLogoColor,
    vitrinBgImage: settings.vitrinBgImage,
    vitrinOtherTitleColor: settings.vitrinOtherTitleColor,
    vitrinOtherTextColor: settings.vitrinOtherTextColor,
    vitrinOtherMutedColor: settings.vitrinOtherMutedColor,
    vitrinOtherFont: settings.vitrinOtherFont,
    vitrinFont: settings.vitrinFont,
    vitrinProfileBg: settings.vitrinProfileBg,
    vitrinProfileColor: settings.vitrinProfileColor,
    domains: getDomains(),
    backupDue: !settings.lastBackupAt || Date.now() - new Date(settings.lastBackupAt).getTime() > 7 * 24 * 60 * 60 * 1000,
  };
}

function sideLabels(raw: Record<string, unknown>) {
  return {
    sideLeftText: sideLabel(raw.sideLeftText, empty.sideLeftText),
    sideLeftColor: normalizeThemeColor(raw.sideLeftColor) || empty.sideLeftColor,
    sideRightText: sideLabel(raw.sideRightText, empty.sideRightText),
    sideRightColor: normalizeThemeColor(raw.sideRightColor) || empty.sideRightColor,
    sideFontSize: sideFontSize(raw.sideFontSize),
  };
}

export function sideFontSize(value: unknown) {
  const size = Number(value);
  if (!Number.isFinite(size)) return empty.sideFontSize;
  return Math.min(40, Math.max(12, Math.round(size)));
}

export function sideLabel(value: unknown, fallback: string) {
  if (typeof value !== "string") return fallback;
  return value.replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 40);
}

function noteFields(raw: Record<string, unknown>) {
  return {
    ilanVerNoteTitle: noteLine(raw.ilanVerNoteTitle, empty.ilanVerNoteTitle, 80),
    ilanVerNoteBody: noteLine(raw.ilanVerNoteBody, empty.ilanVerNoteBody, 180),
    ilanVerNoteColor: normalizeThemeColor(raw.ilanVerNoteColor) || empty.ilanVerNoteColor,
    ilanVerNoteBodyColor: normalizeThemeColor(raw.ilanVerNoteBodyColor) || empty.ilanVerNoteBodyColor,
    ilanVerNoteBg: normalizeThemeColor(raw.ilanVerNoteBg) || empty.ilanVerNoteBg,
  };
}

export function noteLine(value: unknown, fallback: string, max: number) {
  if (typeof value !== "string") return fallback;
  const text = value.replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
  return text || fallback;
}

function vitrinFields(raw: Record<string, unknown>) {
  return {
    vitrinBg: normalizeThemeColor(raw.vitrinBg) || empty.vitrinBg,
    vitrinCard: normalizeThemeColor(raw.vitrinCard) || empty.vitrinCard,
    vitrinAccent: normalizeThemeColor(raw.vitrinAccent) || empty.vitrinAccent,
    vitrinHero: normalizeThemeColor(raw.vitrinHero) || empty.vitrinHero,
    vitrinText: normalizeThemeColor(raw.vitrinText) || empty.vitrinText,
    vitrinVip: normalizeThemeColor(raw.vitrinVip) || empty.vitrinVip,
    vitrinGold: normalizeThemeColor(raw.vitrinGold) || empty.vitrinGold,
    vitrinYeni: normalizeThemeColor(raw.vitrinYeni) || empty.vitrinYeni,
    vitrinTopTier: raw.vitrinTopTier === "gold" ? ("gold" as const) : ("vip" as const),
    vitrinIlanTitle: noteLine(raw.vitrinIlanTitle, empty.vitrinIlanTitle, 40),
    vitrinIlanTitleColor: normalizeThemeColor(raw.vitrinIlanTitleColor) || empty.vitrinIlanTitleColor,
    vitrinIlanTitleSize: pxSize(raw.vitrinIlanTitleSize, empty.vitrinIlanTitleSize, 12, 40),
    vitrinIlanNote: noteLine(raw.vitrinIlanNote, empty.vitrinIlanNote, 120),
    vitrinIlanNoteColor: normalizeThemeColor(raw.vitrinIlanNoteColor) || empty.vitrinIlanNoteColor,
    vitrinIlanNoteSize: pxSize(raw.vitrinIlanNoteSize, empty.vitrinIlanNoteSize, 9, 22),
    vitrinLogoText: noteLine(raw.vitrinLogoText, empty.vitrinLogoText, 40),
    vitrinLogoColor: normalizeThemeColor(raw.vitrinLogoColor) || empty.vitrinLogoColor,
    vitrinBgImage: cleanBgImage(raw.vitrinBgImage),
    vitrinOtherTitleColor: normalizeThemeColor(raw.vitrinOtherTitleColor) || empty.vitrinOtherTitleColor,
    vitrinOtherTextColor: normalizeThemeColor(raw.vitrinOtherTextColor) || empty.vitrinOtherTextColor,
    vitrinOtherMutedColor: normalizeThemeColor(raw.vitrinOtherMutedColor) || empty.vitrinOtherMutedColor,
    vitrinOtherFont: vitrinOtherFont(raw.vitrinOtherFont),
    vitrinFont: vitrinOtherFont(raw.vitrinFont),
    vitrinProfileBg: normalizeThemeColor(raw.vitrinProfileBg) || empty.vitrinProfileBg,
    vitrinProfileColor: normalizeThemeColor(raw.vitrinProfileColor) || empty.vitrinProfileColor,
  };
}

function pxSize(value: unknown, fallback: number, min: number, max: number) {
  const size = Math.round(Number(value));
  if (!Number.isFinite(size) || size <= 0) return fallback;
  return Math.min(max, Math.max(min, size));
}

function themeColors(raw: Record<string, unknown>) {
  return {
    themeColor: normalizeThemeColor(raw.themeColor) || normalizeThemeColor(raw.themeRed) || empty.themeColor,
    textColor: normalizeThemeColor(raw.textColor) || empty.textColor,
    ilanVerColor: normalizeThemeColor(raw.ilanVerColor) || normalizeThemeColor(raw.themeBlack) || empty.ilanVerColor,
    ilanVerTextColor: normalizeThemeColor(raw.ilanVerTextColor) || normalizeThemeColor(raw.themeWhite) || empty.ilanVerTextColor,
  };
}

export function normalizeThemeColor(value: unknown) {
  if (typeof value !== "string") return null;
  const raw = value.trim();
  if (!/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(raw)) return null;
  if (raw.length === 4) {
    const [r, g, b] = raw.slice(1).split("");
    return `#${r}${r}${g}${g}${b}${b}`.toLowerCase();
  }
  return raw.toLowerCase();
}

export function rehberDescriptionText(value: unknown) {
  const text = typeof value === "string" ? value.replace(/\s+/g, " ").trim() : "";
  return (text || empty.rehberDescription).slice(0, 320);
}

export function clampDays(value: number) {
  const days = Math.round(Number(value) || 2);
  if (days < 1) return 1;
  if (days > 14) return 14;
  return days;
}

export function ilanVerHref() {
  const digits = toPhoneDigits(getSettings().ilanVerPhone);
  if (!digits) return "#";
  return `https://wa.me/${digits}?text=${encodeURIComponent("Merhaba, ilan vermek istiyorum.")}`;
}

export function faviconHref() {
  return getSettings().favicon || "/favicon.png";
}
