"use client";

import { formatClock, remainingText } from "@/lib/listing-clock";
import { useEffect, useState } from "react";

export function DurationBar({
  startedAt,
  expiresAt,
}: {
  startedAt: string | null;
  expiresAt: string | null;
}) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(timer);
  }, []);

  if (!expiresAt) {
    return <p className="muted">Süre, ilan yayınlandığı saatte başlar.</p>;
  }

  const end = new Date(expiresAt).getTime();
  const start = startedAt ? new Date(startedAt).getTime() : end;
  const total = Math.max(end - start, 1);
  const elapsed = Math.min(Math.max(now - start, 0), total);
  const ended = now >= end;
  const percent = ended ? 100 : Math.round((elapsed / total) * 100);
  const width = ended ? "100%" : elapsed > 0 ? `max(${(elapsed / total) * 100}%, 8px)` : "0%";

  return (
    <div className="duration-bar">
      <div className="duration-meta">
        <span>{startedAt ? `Başlangıç ${formatClock(startedAt)}` : "Başlangıç yok"}</span>
        <strong>{ended ? "Süresi doldu" : `${remainingText(expiresAt, now)} kaldı`}</strong>
        <span>Bitiş {formatClock(expiresAt)}</span>
      </div>
      <div
        className={ended ? "duration-track ended" : "duration-track"}
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={percent}
        aria-label="Kalan ilan süresi"
      >
        <span style={{ width }} />
      </div>
    </div>
  );
}
