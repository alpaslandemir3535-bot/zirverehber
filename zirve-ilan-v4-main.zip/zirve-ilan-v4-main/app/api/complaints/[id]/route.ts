import { isAdmin } from "@/lib/auth";
import { markComplaintRead } from "@/lib/complaints";
import { rejectCrossOrigin } from "@/lib/http";
import { NextResponse } from "next/server";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const denied = rejectCrossOrigin(request);
  if (denied) return denied;
  if (!(await isAdmin())) return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
  const { id } = await params;
  const body = (await request.json().catch(() => ({}))) as { read?: boolean };
  const item = markComplaintRead(id, body.read !== false);
  if (!item) return NextResponse.json({ error: "Kayıt yok." }, { status: 404 });
  return NextResponse.json(item);
}
