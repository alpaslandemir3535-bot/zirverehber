import path from "path";
import { readJsonFile, writeJsonFile } from "./json-file";

const file = path.join(process.cwd(), "data", "login-bans.json");
const MAX_FAILS = 3;

type Row = { fails: number; banned: boolean };
type Store = Record<string, Row>;

function readStore(): Store {
  const raw = readJsonFile<Store>(file, {});
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
  return raw;
}

function writeStore(store: Store) {
  writeJsonFile(file, store);
}

function ipKey(ip: string) {
  return ip.trim().toLowerCase().replace(/^::ffff:/, "").slice(0, 80) || "local";
}

export function loginBanned(ip: string) {
  return Boolean(readStore()[ipKey(ip)]?.banned);
}

export function noteLoginFailure(ip: string) {
  const store = readStore();
  const id = ipKey(ip);
  const row = store[id] || { fails: 0, banned: false };
  if (row.banned) return true;
  row.fails += 1;
  if (row.fails >= MAX_FAILS) row.banned = true;
  store[id] = row;
  writeStore(store);
  return row.banned;
}

export function noteLoginSuccess(ip: string) {
  const store = readStore();
  const id = ipKey(ip);
  const row = store[id];
  if (!row || row.banned) return;
  delete store[id];
  writeStore(store);
}
