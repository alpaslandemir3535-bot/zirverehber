"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function OwnerLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    const res = await fetch("/api/auth/owner-login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username }),
    });
    const json = (await res.json().catch(() => null)) as { error?: string } | null;
    if (!res.ok) {
      setError(json?.error || "Giriş yapılamadı.");
      return;
    }
    router.push("/hesap/");
    router.refresh();
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <p className="eyebrow">Zirve</p>
        <h1>İlan sahibi girişi</h1>
        <p className="muted">Sana tanımlanan kullanıcı adı ile gir.</p>
        <form onSubmit={submit} className="form-grid one-col">
          <label>
            Kullanıcı adı
            <input value={username} onChange={(event) => setUsername(event.target.value)} autoFocus required />
          </label>
          {error ? <p className="err">{error}</p> : null}
          <button className="btn" type="submit">
            Giriş
          </button>
        </form>
      </div>
    </div>
  );
}
